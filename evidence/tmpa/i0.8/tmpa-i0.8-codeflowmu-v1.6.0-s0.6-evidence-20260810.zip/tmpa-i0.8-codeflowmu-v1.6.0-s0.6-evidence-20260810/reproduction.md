# Public Reproduction

Requirements: Node.js 22 or newer, npm, and public npm registry access. No CodeFlowMu repository checkout is required.

From the extracted evidence package root:

```text
cd public-reproducer
npm ci
npm test
```

`npm test` first verifies the seven official LF input hashes, then invokes the bundled CodeFlowMu `GovernanceReader` through the product runner. Expected final result:

```text
PASS 14 / FAIL 0 / PARTIAL 0 / NOT RUN 0
product_reader_called: true
reference_reader_called: false
input_bundle_digest: sha256:251914ee55922d20c9bd23943a4ff445bccaa5835e1fcc11b8562f3f384243fa
```

The actual clean-copy execution is recorded in `logs/10-public-reproducer-npm-ci.*`, `logs/11-public-reproducer-npm-test.*`, and `public-reproduction/result.json`.
