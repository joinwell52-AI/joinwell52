# TMPA S0.6 Product C01-C14 Matrix

Implementation: CodeFlowMu V1.6.0 at `62440a526a99d2fe55019d8bb95ad2425569fcb4`  
Input bundle: `sha256:251914ee55922d20c9bd23943a4ff445bccaa5835e1fcc11b8562f3f384243fa`  
Result: **PASS — 14 PASS / 0 FAIL / 0 PARTIAL / 0 NOT RUN**

| Criterion | Fixture | Verdict | Assertions | Failed |
|---|---|---:|---:|---:|
| C01 | Schema validation | PASS | 3 | 0 |
| C02 | Primary-carrier and single-writer immutability | PASS | 5 | 0 |
| C03 | Duplicate object identity and source provenance | PASS | 5 | 0 |
| C04 | Serial-stream continuity and asynchronous progress | PASS | 4 | 0 |
| C05 | Role authority | PASS | 5 | 0 |
| C06 | Lifecycle legality | PASS | 9 | 0 |
| C07 | Separation of duties and human approval authorization | PASS | 10 | 0 |
| C08 | Integrity tampering | PASS | 3 | 0 |
| C09 | Missing reference | PASS | 4 | 0 |
| C10 | Prohibited cycle | PASS | 4 | 0 |
| C11 | Aggregation and reconstruction determinism | PASS | 4 | 0 |
| C12 | Conflict preservation | PASS | 5 | 0 |
| C13 | Recovery | PASS | 5 | 0 |
| C14 | Terminal-history preservation | PASS | 5 | 0 |
