# TMPA I0.8 CodeFlowMu V1.6.0 S0.6 Corrected Evidence

Publication-preflight corrected package dated 2026-08-10.

- Product correction commit: `62440a526a99d2fe55019d8bb95ad2425569fcb4`
- Official TMPA input commit: `8989657e8fde6d2e55d7606ae0adacac14fec760`
- Official raw LF input hashes: 7/7 exact
- Product C01-C14: **14 PASS / 0 FAIL / 0 PARTIAL / 0 NOT RUN**
- Public reproducer: `npm ci && npm test` -> **14/14 PASS**
- Evidence boundary: author-run Demonstrated; not independent certification.
