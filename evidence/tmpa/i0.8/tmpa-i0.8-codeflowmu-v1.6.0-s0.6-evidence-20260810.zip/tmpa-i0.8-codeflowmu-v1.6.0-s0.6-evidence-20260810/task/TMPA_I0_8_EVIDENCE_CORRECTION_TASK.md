# TASK：TMPA I0.8 证据包出版前修正

当前包的产品运行结果是 `14 PASS / 0 FAIL`，功能实现不要求重做；只修以下出版阻断项并重新运行 S0.6 产品 C01–C14。

## P0-1：使用 GitHub 正式 S0.6 原始字节

当前 `locked-inputs` 是 Windows CRLF，虽然 JSON/Fixture 语义相同，但 SHA-256 与正式 Commit `8989657e8fde6d2e55d7606ae0adacac14fec760` 不一致。

重新提取时禁止换行转换，确保以下 SHA-256 完全一致：

```text
conformance-result.schema.json  11c21a8d4dc8ef1b9f9990123a6deb4870a39232574f9565d7d95ed78a808749
governance-object.schema.json    623fd1d639defa441353993a3f5c1b228889d8977f5ac199d05c23f4683d036b
lifecycle-profile.schema.json   df925fc3c515f680e2f699ef5e82aba00c299ba63675d520effb0c006e6ce9d8
reader-result.schema.json       f62aca5fb0a696bf92cd89bbf84e8c59d185d45af8f189504151c18509cc4f59
canonicalization-profile.json   937499bd27586e64ed6a57669bc8108826f4203fe0cfae380680eb6535667b62
profile.json                    b0acc000ac0373b4c710267018f07b4b5c50f6642626da10ec2dde58fcccd21f
fixtures.mjs                    54d49ddf3e7cb71c0538bcfb3003bdf9c416bd00c830f3233270ecf0f14be536
```

用这些原始 LF 输入重新执行：

```text
npm run test:tmpa:s0.6
```

重新生成 conformance result、C01–C14 Actual、input bundle digest 和全部相关摘要。不要只修改旧 JSON 中的 Hash。

## P0-2：补齐公开复现路径

产品 Commit `4964a64bc28d93a09a853c13c792f8ab03683961` 当前是本地提交，外部无法直接取得；现有 Patch 又依赖非公开母体基线，因此不能称为“可公开复现”。二选一：

1. 把该 Commit 发布到公众可访问的固定仓库/Tag；或
2. 在证据包加入自包含 `public-reproducer/`，不依赖私有仓库，执行 `npm ci && npm test` 即可重新运行产品 Reader 的 S0.6 C01–C14。

如果选择方案 2，必须包含完整依赖文件、产品 Reader、Protocol Validator、Profile、Fixtures、Runner、Package Lock 和复现脚本。Runtime/Shell 全量结果可以继续标为作者本地运行，不冒充公开复现。

## P1：修正包装信息

- `validation-report.json` 当前写 141 个 Manifest 条目，实际为 142；修正并重新生成 Manifest。
- 实际 Commit、执行和验证日期是北京时间 **2026-08-10**。最终包名使用：

```text
tmpa-i0.8-codeflowmu-v1.6.0-s0.6-evidence-20260810.zip
tmpa-i0.8-codeflowmu-v1.6.0-s0.6-evidence-20260810.zip.sha256
```

- `reproduction.md` 必须给出从公开输入到运行完成的逐条命令，不能只引用本机绝对目录。
- 文件名 ASCII、文本 UTF-8；不要使用 PowerShell 修改中文文件。

## 最终回执

只返回：新 ZIP、外部 `.sha256`、14 项汇总、公开复现命令及其实际运行结果。不要 Push TMPA 论文仓库。
