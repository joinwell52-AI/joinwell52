# TASK：TMPA Phase 4.3 — Implementation Case I0.8

## 目标

在本地 `D:\codeflowmu` 中把 CodeFlowMu 从 TMPA Core S0.5 产品基线升级为 **精确的 S0.6 产品实现与执行证据**，运行 C01–C14，并生成可交给 TMPA Publication 维护流程复核的 I0.8 锁定证据包。

当前事实：

- TMPA Core S0.6 RC 正式 Commit：`8989657e8fde6d2e55d7606ae0adacac14fec760`
- I0.7 / CodeFlowMu V1.4.1 是 S0.5 的 `14 PASS / 0 FAIL` 历史基线
- S0.6 Reference Reader 是 `14 PASS / 0 FAIL`
- S0.6 产品轨道当前是 `14 NOT RUN`

禁止把 I0.7、V1.4.1 或 Reference Reader 的 PASS 直接改标成 S0.6 产品 PASS。

## 输入

1. CodeFlowMu 本地源码：`D:\codeflowmu`
2. FCoP 本地源码：`D:\FCoP`（FCoP 是协议；`fcop` / `fcop-mcp` 只是参考实现）
3. S0.6 规范与语料库：
   - `https://github.com/joinwell52-AI/joinwell52/tree/8989657e8fde6d2e55d7606ae0adacac14fec760/research/conformance/tmpa-core-s0.6`
   - `https://github.com/joinwell52-AI/joinwell52/tree/8989657e8fde6d2e55d7606ae0adacac14fec760/docs/public/spec/tmpa/s0.6`
4. I0.7 正式历史证据包，仅用于回归对照，不覆盖或改写。

## 必做实现

### 1. S0.6 版本化输入输出

- 产品对象必须使用 `tmpa_version: S0.6`。
- 产品必须加载或等价实现四份 S0.6 Schema：governance object、lifecycle profile、reader result、conformance result。
- `created_at` 必须执行 Draft 2020-12 `date-time` 格式断言。
- 产品结果必须通过 S0.6 `conformance-result.schema.json`。

### 2. S0.6 三项新增可观察边界

- **C03 来源保留：** 字节相同的多个来源只能投影为一个节点，但节点必须保留全部 `source_ids`，顺序确定。
- **C07 人工批准：** 高风险批准必须同时满足允许的批准对象类型、有效 Assignment、允许角色、批准决定；Profile 要求时，批准人与被批准对象创建者必须相互独立。错误类型、未分配角色、自我批准都必须保持 `pending_human`。
- **C11 确定排序：** 所有规范排序必须使用 Locale 无关的 Unicode code-point 顺序，不得依赖 `localeCompare()` 或操作系统 Locale。必须覆盖 `U+E000` 与 `U+10000` 排序回归。

### 3. Canonicalization

产品必须声明并锁定以下内容：

- UTF-8；
- Unicode normalization = none；
- LF；
- Object key 使用 Unicode code-point 排序；
- 数组顺序规则；
- Digest 覆盖范围；
- `integrity.digest` 等自引用字段的排除/规范化规则。

## 测试要求

1. 把 S0.6 C01–C14 作为产品级测试执行，不得调用 Reference Reader 代替产品 Reader。
2. 每项准则都要保存：输入、预期、实际输出、命令、退出码、日志、结果摘要和 SHA-256。
3. 至少执行：
   - S0.6 外部产品 C01–C14 Fixture；
   - CodeFlowMu 内置 TMPA 测试；
   - Protocol 测试与 typecheck；
   - Runtime 全量测试与 typecheck；
   - Shell 全量测试与 typecheck；
   - 锁定 FCoP 基线测试。
4. S0.5/I0.7 回归必须继续通过，或者明确记录真实回归失败。
5. 任何测试失败、未运行或缺少强制输出，必须如实裁为 `FAIL`、`PARTIAL` 或 `NOT RUN`，禁止汇总为 PASS。

## 证据包

生成一个新目录和 ZIP，不覆盖 I0.7：

```text
tmpa-i0.8-codeflowmu-<product-version>-s0.6-evidence-20260809/
tmpa-i0.8-codeflowmu-<product-version>-s0.6-evidence-20260809.zip
tmpa-i0.8-codeflowmu-<product-version>-s0.6-evidence-20260809.zip.sha256
```

证据包至少包含：

- `README.md`
- `executive-summary.md`
- `limitations.md`
- `reproduction.md`
- `source-lock.json`
- `environment.json`
- `dependency-lockfiles.json`
- `commands.jsonl`
- `c01-c14-matrix.json` 与 `.md`
- 四份 S0.6 Schema 和 canonicalization profile 的锁定副本
- 产品 Fixture、必要源码摘录和补丁
- 原始运行日志、标准化 Actual 输出
- `manifests/SHA256SUMS`
- UTF-8、JSON/JSONL、文件名、敏感信息和 SHA-256 核验报告

文件名全部使用 ASCII；文本严格 UTF-8。不要使用 PowerShell 修改中文文件。

## 版本与边界

- 不复用 `CodeFlowMu V1.4.1` 作为 S0.6 版本；选择下一个未使用的产品版本并记录 Commit。若项目版本策略允许，建议使用 `V1.5.0`。
- 本任务可以修改 CodeFlowMu、运行测试并创建本地 Git Commit。
- **不得**自行 Push、Tag、Release，不得修改 `joinwell52-AI/joinwell52` 论文仓库。
- 不得把 FCoP 参考实现测试写成 FCoP 协议本身的产品证明。
- 结论最多为作者运行的 `Demonstrated`；不能写成独立认证或 `Independently Adopted`。

## 交付回执

完成后只需返回：

1. CodeFlowMu 新版本与 Commit；
2. C01–C14 汇总；
3. 各测试套件结果；
4. ZIP 与 `.sha256` 路径；
5. 证据包自身核验结果；
6. 修改文件清单；
7. 未解决问题与声明边界。

证据包通过复核后，再由 TMPA Publication 维护流程编写中英文 I0.8、提交 Git Commit 并发布 GitHub Pages。
