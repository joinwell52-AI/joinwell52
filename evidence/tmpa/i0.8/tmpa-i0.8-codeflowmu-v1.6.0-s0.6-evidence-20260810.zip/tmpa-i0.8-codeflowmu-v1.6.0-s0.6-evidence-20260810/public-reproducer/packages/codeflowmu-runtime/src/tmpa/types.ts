import type {
  TmpaGovernanceObject,
  TmpaCoreVersion,
  TmpaLifecycleProfile,
  TmpaReaderResult,
} from "@codeflowmu/protocol";

export interface TmpaSourceCandidate {
  source_id: string;
  path?: string;
  media_type: string;
  bytes: Uint8Array;
  extensions?: Record<string, unknown>;
}

export interface TmpaProjectedCandidate extends TmpaSourceCandidate {
  object: TmpaGovernanceObject;
}

export interface TmpaReaderOptions {
  lifecycleProfile: TmpaLifecycleProfile;
  coreVersion?: TmpaCoreVersion;
  readerId?: string;
  readerVersion?: string;
}

export interface TmpaGovernanceReader {
  read(sources: readonly TmpaSourceCandidate[]): Promise<TmpaReaderResult>;
  readSync(sources: readonly TmpaSourceCandidate[]): TmpaReaderResult;
}

export interface FcopTmpaProjectionResult {
  profile: TmpaLifecycleProfile;
  sources: TmpaProjectedCandidate[];
  source_file_count: number;
  projected_object_count: number;
}
