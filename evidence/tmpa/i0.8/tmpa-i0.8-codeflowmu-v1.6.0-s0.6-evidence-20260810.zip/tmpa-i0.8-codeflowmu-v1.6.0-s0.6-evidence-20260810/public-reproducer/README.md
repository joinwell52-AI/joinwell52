# CodeFlowMu V1.6.0 TMPA S0.6 Public Reproducer

This directory is self-contained and does not require access to the CodeFlowMu source repository.

Requirements: Node.js 22 or newer and public npm registry access.

```text
npm ci
npm test
```

Expected result: `14 PASS / 0 FAIL / 0 PARTIAL / 0 NOT RUN`.

The runner invokes the bundled CodeFlowMu `GovernanceReader` directly. It does not call the TMPA Reference Reader.
`npm test` first verifies all seven official LF input hashes before running C01-C14.
