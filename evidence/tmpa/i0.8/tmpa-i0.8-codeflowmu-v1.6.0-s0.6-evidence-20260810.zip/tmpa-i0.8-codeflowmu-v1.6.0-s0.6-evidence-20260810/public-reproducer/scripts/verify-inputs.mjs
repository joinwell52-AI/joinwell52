import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";

const expected = {
  "tmpa-conformance/s0.6/upstream/schemas/conformance-result.schema.json": "11c21a8d4dc8ef1b9f9990123a6deb4870a39232574f9565d7d95ed78a808749",
  "tmpa-conformance/s0.6/upstream/schemas/governance-object.schema.json": "623fd1d639defa441353993a3f5c1b228889d8977f5ac199d05c23f4683d036b",
  "tmpa-conformance/s0.6/upstream/schemas/lifecycle-profile.schema.json": "df925fc3c515f680e2f699ef5e82aba00c299ba63675d520effb0c006e6ce9d8",
  "tmpa-conformance/s0.6/upstream/schemas/reader-result.schema.json": "f62aca5fb0a696bf92cd89bbf84e8c59d185d45af8f189504151c18509cc4f59",
  "tmpa-conformance/s0.6/upstream/canonicalization-profile.json": "937499bd27586e64ed6a57669bc8108826f4203fe0cfae380680eb6535667b62",
  "tmpa-conformance/s0.6/upstream/profile.json": "b0acc000ac0373b4c710267018f07b4b5c50f6642626da10ec2dde58fcccd21f",
  "tmpa-conformance/s0.6/upstream/fixtures.mjs": "54d49ddf3e7cb71c0538bcfb3003bdf9c416bd00c830f3233270ecf0f14be536",
};

for (const [file, digest] of Object.entries(expected)) {
  const actual = createHash("sha256").update(readFileSync(file)).digest("hex");
  if (actual !== digest) throw new Error(`${file}: expected ${digest}, got ${actual}`);
}

process.stdout.write(`verified ${Object.keys(expected).length} canonical LF inputs\n`);
