import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import {
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { arch, platform, release } from "node:os";
import path from "node:path";

const workspace = path.resolve(import.meta.dirname, "..");
const productRoot = path.join(import.meta.dirname, "codeflowmu-i08-v160");
const fcopRoot = path.join(import.meta.dirname, "fcop-i08-da79dfef");
const packageName = "tmpa-i0.8-codeflowmu-v1.6.0-s0.6-evidence-20260809";
const outputsRoot = path.join(workspace, "outputs");
const evidenceRoot = path.join(outputsRoot, packageName);
const zipPath = path.join(outputsRoot, `${packageName}.zip`);
const zipShaPath = `${zipPath}.sha256`;

const productCommit = "4964a64bc28d93a09a853c13c792f8ab03683961";
const productBaseCommit = "1e1484a10e4bf6f0ce39ddf08d12a05cbb5ec811";
const fcopCommit = "da79dfefd99f597c9e422ce9edec22157f915a21";
const upstreamCommit = "8989657e8fde6d2e55d7606ae0adacac14fec760";

function sha256Bytes(value) {
  return createHash("sha256").update(value).digest("hex");
}

function sha256File(file) {
  return sha256Bytes(readFileSync(file));
}

function ensureParent(file) {
  mkdirSync(path.dirname(file), { recursive: true });
}

function writeText(relative, value) {
  const file = path.join(evidenceRoot, relative);
  ensureParent(file);
  writeFileSync(file, value.replace(/\r\n/g, "\n"), "utf8");
}

function writeJson(relative, value) {
  writeText(relative, `${JSON.stringify(value, null, 2)}\n`);
}

function copy(relative, source) {
  const target = path.join(evidenceRoot, relative);
  ensureParent(target);
  copyFileSync(source, target);
}

function listFiles(root) {
  const output = [];
  for (const name of readdirSync(root)) {
    const absolute = path.join(root, name);
    if (statSync(absolute).isDirectory()) output.push(...listFiles(absolute));
    else output.push(absolute);
  }
  return output.sort((a, b) => a.codePointAt(0) - b.codePointAt(0) || a.localeCompare(b, "en"));
}

function relativePosix(file) {
  return path.relative(evidenceRoot, file).replaceAll("\\", "/");
}

function run(executable, args, cwd) {
  return new Promise((resolve) => {
    const child = spawn(executable, args, {
      cwd,
      env: {
        ...process.env,
        FORCE_COLOR: "0",
        NO_COLOR: "1",
        PYTHONUTF8: "1",
        PYTHONIOENCODING: "utf-8",
      },
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const stdout = [];
    const stderr = [];
    child.stdout.on("data", (chunk) => stdout.push(chunk));
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.on("close", (exitCode, signal) => {
      resolve({
        exitCode: exitCode ?? -1,
        signal: signal ?? null,
        stdout: Buffer.concat(stdout).toString("utf8"),
        stderr: Buffer.concat(stderr).toString("utf8"),
      });
    });
  });
}

const commandRecords = [];

async function captureCommand(spec) {
  const startedAt = new Date().toISOString();
  const result = await run(spec.executable, spec.args, spec.cwd);
  const completedAt = new Date().toISOString();
  const stdoutRel = `logs/${spec.id}.stdout.log`;
  const stderrRel = `logs/${spec.id}.stderr.log`;
  writeText(stdoutRel, result.stdout);
  writeText(stderrRel, result.stderr);
  const record = {
    id: spec.id,
    purpose: spec.purpose,
    executable: spec.executable,
    args: spec.args,
    command_display: spec.display,
    working_directory: spec.cwd.replaceAll("\\", "/"),
    started_at: startedAt,
    completed_at: completedAt,
    exit_code: result.exitCode,
    signal: result.signal,
    stdout_log: stdoutRel,
    stdout_sha256: sha256File(path.join(evidenceRoot, stdoutRel)),
    stderr_log: stderrRel,
    stderr_sha256: sha256File(path.join(evidenceRoot, stderrRel)),
  };
  commandRecords.push(record);
  return { ...result, record };
}

function npmSpec(id, purpose, cwd, command) {
  return {
    id,
    purpose,
    cwd,
    executable: "cmd.exe",
    args: ["/d", "/s", "/c", command],
    display: command,
  };
}

mkdirSync(outputsRoot, { recursive: true });
if (existsSync(evidenceRoot) || existsSync(zipPath) || existsSync(zipShaPath)) {
  throw new Error(`Refusing to overwrite existing I0.8 evidence output: ${packageName}`);
}
mkdirSync(evidenceRoot, { recursive: true });

const shortSpecs = [
  npmSpec("01-s06-product-c01-c14", "Official S0.6 product C01-C14 fixture", productRoot, "npm run test:tmpa:s0.6"),
  npmSpec("02-codeflowmu-internal-tmpa", "CodeFlowMu internal TMPA and explicit S0.5 regression", productRoot, "npm run test:tmpa"),
  npmSpec("03-protocol-tests", "Protocol full tests", path.join(productRoot, "packages", "codeflowmu-protocol"), "npm test"),
  npmSpec("04-protocol-typecheck", "Protocol TypeScript typecheck", path.join(productRoot, "packages", "codeflowmu-protocol"), "npm run typecheck"),
  npmSpec("05-runtime-typecheck", "Runtime TypeScript typecheck", path.join(productRoot, "packages", "codeflowmu-runtime"), "npm run typecheck"),
  npmSpec("06-shell-typecheck", "Shell TypeScript typecheck", path.join(productRoot, "codeflowmu-shell"), "npm run typecheck"),
];
const shortResults = await Promise.all(shortSpecs.map(captureCommand));

const fullResults = await Promise.all([
  captureCommand({
    id: "07-runtime-full",
    purpose: "Runtime full test suite",
    cwd: path.join(productRoot, "packages", "codeflowmu-runtime"),
    executable: "node.exe",
    args: ["scripts/run-tsx-test.cjs", "--test-concurrency=1", "--test-reporter=spec", "src/**/__tests__/*.test.ts"],
    display: 'node scripts/run-tsx-test.cjs --test-concurrency=1 --test-reporter=spec "src/**/__tests__/*.test.ts"',
  }),
  captureCommand({
    id: "08-shell-full",
    purpose: "Shell full test suite",
    cwd: path.join(productRoot, "codeflowmu-shell"),
    executable: "node.exe",
    args: ["scripts/run-tsx-test.cjs", "--test-concurrency=1", "--test-reporter=spec", "src/__tests__/*.test.ts"],
    display: 'node scripts/run-tsx-test.cjs --test-concurrency=1 --test-reporter=spec "src/__tests__/*.test.ts"',
  }),
]);

const fcopResult = await captureCommand({
  id: "09-fcop-locked-baseline",
  purpose: "Locked FCoP reference implementation baseline",
  cwd: fcopRoot,
  executable: "D:\\FCoP\\.venv\\Scripts\\python.exe",
  args: ["-m", "pytest", "-q"],
  display: "python -m pytest -q",
});

commandRecords.sort((a, b) => a.id.localeCompare(b.id, "en"));
writeText("commands.jsonl", commandRecords.map((record) => JSON.stringify(record)).join("\n") + "\n");

const allResults = [...shortResults, ...fullResults, fcopResult];
if (allResults.some((result) => result.exitCode !== 0)) {
  writeJson("collection-failure.json", {
    failed_commands: commandRecords.filter((record) => record.exit_code !== 0),
  });
  throw new Error("One or more evidence commands failed; partial evidence directory retained.");
}

const resultById = Object.fromEntries(allResults.map((result) => [result.record.id, result]));
const mandatoryOutputChecks = [
  ["01-s06-product-c01-c14", /"PASS": 14/, "S0.6 product runner must report 14 PASS"],
  ["02-codeflowmu-internal-tmpa", /ℹ tests 23[\s\S]*ℹ pass 23[\s\S]*ℹ fail 0/, "Internal TMPA must report 23/23"],
  ["03-protocol-tests", /is a valid skill[\s\S]*OK \(expected fail\)/, "Protocol valid and expected-invalid fixtures must run"],
  ["07-runtime-full", /ℹ tests 1486[\s\S]*ℹ pass 1485[\s\S]*ℹ fail 0[\s\S]*ℹ skipped 1/, "Runtime full must report 1485 pass and 1 skip"],
  ["08-shell-full", /ℹ tests 777[\s\S]*ℹ pass 777[\s\S]*ℹ fail 0[\s\S]*ℹ skipped 0/, "Shell full must report 777/777"],
  ["09-fcop-locked-baseline", /1210 passed, 2 skipped/, "FCoP locked baseline must report 1210 pass and 2 skip"],
];
const outputCheckFailures = mandatoryOutputChecks
  .filter(([id, pattern]) => !pattern.test(`${resultById[id].stdout}\n${resultById[id].stderr}`))
  .map(([id, , requirement]) => ({ command_id: id, requirement }));
if (outputCheckFailures.length) {
  writeJson("collection-failure.json", { output_check_failures: outputCheckFailures });
  throw new Error("One or more mandatory output checks failed; partial evidence directory retained.");
}

const generatedArtifacts = path.join(productRoot, "tmpa-conformance", "s0.6", "artifacts");
cpSync(generatedArtifacts, path.join(evidenceRoot, "actual", "s0.6-product"), { recursive: true });

const productSummary = JSON.parse(readFileSync(path.join(generatedArtifacts, "summary.json"), "utf8"));
const conformanceResult = JSON.parse(readFileSync(path.join(generatedArtifacts, "conformance-result.json"), "utf8"));
const productCommand = commandRecords.find((record) => record.id === "01-s06-product-c01-c14");

for (const criterion of conformanceResult.criteria) {
  const recordFile = path.join(generatedArtifacts, "criteria", `${criterion.id}.json`);
  const record = JSON.parse(readFileSync(recordFile, "utf8"));
  const base = `criteria/${criterion.id}`;
  writeJson(`${base}/input.json`, {
    criterion: criterion.id,
    fixture_name: record.actual.fixture_name,
    invocations: record.actual.input_invocations,
  });
  writeJson(`${base}/expected.json`, {
    criterion: criterion.id,
    assertions: record.manifest.assertions,
  });
  writeJson(`${base}/actual.json`, record.actual);
  writeJson(`${base}/execution.json`, {
    criterion: criterion.id,
    command_id: productCommand.id,
    command: productCommand.command_display,
    working_directory: productCommand.working_directory,
    exit_code: productCommand.exit_code,
    stdout_log: productCommand.stdout_log,
    stdout_sha256: productCommand.stdout_sha256,
    stderr_log: productCommand.stderr_log,
    stderr_sha256: productCommand.stderr_sha256,
    product_reader_entrypoint: record.manifest.product_reader_entrypoint,
    reference_reader_called: false,
  });
  writeJson(`${base}/summary.json`, {
    criterion: criterion.id,
    verdict: record.verdict,
    manifest_digest: record.manifest_digest,
    result_digest: record.result_digest,
    input_file_sha256: sha256File(path.join(evidenceRoot, `${base}/input.json`)),
    expected_file_sha256: sha256File(path.join(evidenceRoot, `${base}/expected.json`)),
    actual_file_sha256: sha256File(path.join(evidenceRoot, `${base}/actual.json`)),
  });
}

const matrix = conformanceResult.criteria.map((criterion) => {
  const record = JSON.parse(readFileSync(path.join(generatedArtifacts, "criteria", `${criterion.id}.json`), "utf8"));
  return {
    criterion: criterion.id,
    name: record.actual.fixture_name,
    verdict: criterion.verdict,
    run_state: criterion.run_state,
    mandatory_assertions: record.actual.assertions.filter((item) => item.mandatory).length,
    failed_assertions: record.actual.assertions.filter((item) => item.status !== "passed").length,
    manifest_digest: criterion.manifest_digest,
    result_digest: criterion.result_digest,
    evidence_directory: `criteria/${criterion.id}`,
  };
});
writeJson("c01-c14-matrix.json", {
  core_version: "S0.6",
  implementation: { id: "codeflowmu", version: "V1.6.0", commit: productCommit },
  claim_boundary: "Author-run Demonstrated evidence; not independent certification.",
  aggregate_verdict: conformanceResult.aggregate_verdict,
  counts: productSummary.counts,
  criteria: matrix,
});
writeText(
  "c01-c14-matrix.md",
  `# TMPA S0.6 Product C01-C14 Matrix\n\n` +
    `Implementation: CodeFlowMu V1.6.0 at \`${productCommit}\`  \n` +
    `Result: **${conformanceResult.aggregate_verdict} — 14 PASS / 0 FAIL / 0 PARTIAL / 0 NOT RUN**  \n` +
    `Boundary: author-run Demonstrated evidence; not independent certification.\n\n` +
    `| Criterion | Fixture | Verdict | Assertions | Failed | Evidence |\n|---|---|---:|---:|---:|---|\n` +
    matrix.map((row) => `| ${row.criterion} | ${row.name} | ${row.verdict} | ${row.mandatory_assertions} | ${row.failed_assertions} | \`${row.evidence_directory}/\` |`).join("\n") +
    "\n",
);

const upstreamBase = path.join(productRoot, "tmpa-conformance", "s0.6", "upstream");
cpSync(path.join(upstreamBase, "schemas"), path.join(evidenceRoot, "locked-inputs", "schemas"), { recursive: true });
copy("locked-inputs/canonicalization-profile.json", path.join(upstreamBase, "canonicalization-profile.json"));
copy("locked-inputs/lifecycle-profile.json", path.join(upstreamBase, "profile.json"));
copy("locked-inputs/official-fixtures.mjs", path.join(upstreamBase, "fixtures.mjs"));
copy("locked-inputs/product-fixtures.mjs", path.join(productRoot, "tmpa-conformance", "s0.6", "product-fixtures.mjs"));

const sourceFiles = [
  "packages/codeflowmu-runtime/src/tmpa/GovernanceReader.ts",
  "packages/codeflowmu-runtime/src/tmpa/canonical.ts",
  "packages/codeflowmu-runtime/src/tmpa/profile.ts",
  "packages/codeflowmu-runtime/src/tmpa/FcopSourceAdapter.ts",
  "packages/codeflowmu-runtime/src/tmpa/SourceRevisionStore.ts",
  "packages/codeflowmu-runtime/src/tmpa/__tests__/GovernanceReader.test.ts",
  "packages/codeflowmu-protocol/src/validator.ts",
  "tmpa-conformance/s0.6/product-runner.ts",
];
for (const relative of sourceFiles) copy(`source/${relative}`, path.join(productRoot, relative));

const patchResult = await run("git.exe", ["show", "--format=fuller", "--binary", productCommit], productRoot);
writeText("source/codeflowmu-v1.6.0.patch", patchResult.stdout);

const lockCandidates = [
  ["codeflowmu/package-lock.json", path.join(productRoot, "package-lock.json")],
  ["codeflowmu/runtime-package-lock.json", path.join(productRoot, "packages", "codeflowmu-runtime", "package-lock.json")],
  ["codeflowmu/protocol-package-lock.json", path.join(productRoot, "packages", "codeflowmu-protocol", "package-lock.json")],
  ["codeflowmu/shell-package-lock.json", path.join(productRoot, "codeflowmu-shell", "package-lock.json")],
  ["fcop/uv.lock", path.join(fcopRoot, "uv.lock")],
  ["fcop/pyproject.toml", path.join(fcopRoot, "pyproject.toml")],
];
const dependencyLocks = [];
for (const [relative, source] of lockCandidates) {
  if (!existsSync(source)) continue;
  copy(`dependency-locks/${relative}`, source);
  dependencyLocks.push({ path: `dependency-locks/${relative}`, sha256: sha256File(source), bytes: statSync(source).size });
}
writeJson("dependency-lockfiles.json", { files: dependencyLocks });

const gitStatus = await run("git.exe", ["status", "--porcelain", "--untracked-files=no"], productRoot);
writeJson("source-lock.json", {
  codeflowmu: {
    version: "V1.6.0",
    commit: productCommit,
    base_commit: productBaseCommit,
    branch: "tmpa-i0.8-s0.6-v1.6.0",
    tracked_worktree_clean_at_collection: gitStatus.stdout.trim() === "",
    local_commit_only: true,
    pushed: false,
    tagged: false,
    released: false,
  },
  tmpa_core_s0_6: {
    repository: "joinwell52-AI/joinwell52",
    commit: upstreamCommit,
    input_bundle_digest: productSummary.input_bundle_digest,
    locked_hashes: productSummary.input_bundle,
  },
  fcop_reference_implementation: {
    commit: fcopCommit,
    role: "locked dependency baseline only; not protocol proof",
  },
  historical_baseline: {
    implementation_case: "I0.7",
    product_version: "V1.4.1",
    core_version: "S0.5",
    use: "regression comparison only; not relabeled as S0.6 evidence",
  },
});

const versionQueries = await Promise.all([
  run("node.exe", ["--version"], productRoot),
  run("cmd.exe", ["/d", "/s", "/c", "npm --version"], productRoot),
  run("git.exe", ["--version"], productRoot),
  run("D:\\FCoP\\.venv\\Scripts\\python.exe", ["--version"], fcopRoot),
]);
writeJson("environment.json", {
  collected_at: new Date().toISOString(),
  platform: platform(),
  os_release: release(),
  architecture: arch(),
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  node: versionQueries[0].stdout.trim(),
  npm: versionQueries[1].stdout.trim(),
  git: versionQueries[2].stdout.trim(),
  python: (versionQueries[3].stdout || versionQueries[3].stderr).trim(),
  product_worktree: productRoot.replaceAll("\\", "/"),
  fcop_worktree: fcopRoot.replaceAll("\\", "/"),
  log_encoding: "UTF-8 decoded stdout/stderr captured directly by Node.js",
});

const suiteResults = [
  { suite: "S0.6 product C01-C14", result: "14 passed, 0 failed, 0 partial, 0 not run", command_id: "01-s06-product-c01-c14" },
  { suite: "CodeFlowMu internal TMPA", result: "23 passed, 0 failed, 0 skipped", command_id: "02-codeflowmu-internal-tmpa" },
  { suite: "Protocol tests", result: "5 valid fixtures and 3 expected-invalid fixtures passed", command_id: "03-protocol-tests" },
  { suite: "Protocol typecheck", result: "passed", command_id: "04-protocol-typecheck" },
  { suite: "Runtime typecheck", result: "passed", command_id: "05-runtime-typecheck" },
  { suite: "Shell typecheck", result: "passed", command_id: "06-shell-typecheck" },
  { suite: "Runtime full", result: "1485 passed, 0 failed, 1 skipped", command_id: "07-runtime-full" },
  { suite: "Shell full", result: "777 passed, 0 failed, 0 skipped", command_id: "08-shell-full" },
  { suite: "FCoP locked baseline", result: "1210 passed, 0 failed, 2 skipped", command_id: "09-fcop-locked-baseline" },
];
writeJson("suite-results.json", { all_required_commands_exit_zero: true, suites: suiteResults });

writeText("README.md", `# TMPA I0.8 CodeFlowMu V1.6.0 S0.6 Evidence\n\nThis is a locked, author-run engineering evidence package for CodeFlowMu V1.6.0 implementing TMPA Core S0.6.\n\n- Product commit: \`${productCommit}\`\n- TMPA S0.6 input commit: \`${upstreamCommit}\`\n- C01-C14: **14 PASS / 0 FAIL / 0 PARTIAL / 0 NOT RUN**\n- Evidence level: **Demonstrated** (author-run)\n- Reference Reader called by product runner: **false**\n\nStart with \`executive-summary.md\`, then use \`reproduction.md\` and \`commands.jsonl\`. Each criterion has input, expected, actual, execution, and summary records under \`criteria/Cxx/\`.\n`);

writeText("executive-summary.md", `# Executive Summary\n\nCodeFlowMu V1.6.0 at commit \`${productCommit}\` produced a schema-valid TMPA S0.6 Conformance Result with 14/14 criteria passing. The product runner called CodeFlowMu's synchronous GovernanceReader entrypoint and did not call the Reference Reader.\n\nThe implementation adds the S0.6 source-retention boundary for C03, complete high-risk approval constraints for C07, and locale-independent Unicode code-point ordering for C11, including U+E000 versus U+10000 regression coverage. The canonicalization contract locks UTF-8, no Unicode normalization, LF, recursive code-point object-key ordering, array order preservation, digest coverage, and integrity-field exclusions.\n\nAll required product suites and typechecks exited zero. The locked FCoP reference implementation baseline also passed, but that baseline is not represented as proof of the FCoP protocol itself.\n`);

writeText("limitations.md", `# Limitations and Claim Boundary\n\n1. This package is author-run **Demonstrated** evidence. It is not independent certification and does not establish independent adoption.\n2. CodeFlowMu commit \`${productCommit}\` is a local commit. It was not pushed, tagged, or released by this task.\n3. The public I0.7/V1.4.1 result remains the historical S0.5 baseline. It has not been relabeled or overwritten.\n4. FCoP test results describe the locked reference implementation commit \`${fcopCommit}\`; they do not prove the abstract FCoP protocol.\n5. Runtime and Shell skipped counts are preserved. FCoP's two skips are preserved with their reasons in the raw log.\n6. The package does not modify the TMPA publication repository. Publication, bilingual I0.8 authoring, commit, and deployment remain a separate maintainer workflow.\n`);

writeText("reproduction.md", `# Reproduction\n\n## Locked sources\n\n- CodeFlowMu: \`${productCommit}\` (parent \`${productBaseCommit}\`)\n- TMPA S0.6 corpus: \`${upstreamCommit}\`\n- FCoP reference implementation: \`${fcopCommit}\`\n\n## Commands\n\nRun the commands in \`commands.jsonl\` from their recorded working directories. The principal product command is:\n\n\`\`\`text\nnpm run test:tmpa:s0.6\n\`\`\`\n\nIt invokes \`tmpa-conformance/s0.6/product-runner.ts\`, which calls \`GovernanceReader.readSync\`. Full Runtime and Shell tests deliberately use \`--test-concurrency=1\` for deterministic Windows filesystem behavior.\n\nVerify the directory using \`manifests/SHA256SUMS\` and \`validation/validation-report.json\`; verify the ZIP using the adjacent \`.zip.sha256\` file.\n`);

copy("task/TMPA_PHASE_4_3_I0_8_TASK.md", "D:\\downloads\\TMPA_PHASE_4_3_I0_8_TASK.md");
copy("scripts/build-i08-evidence.mjs", import.meta.filename);

function validateEvidence() {
  const textExtensions = new Set([".md", ".json", ".jsonl", ".txt", ".log", ".mjs", ".ts", ".toml", ".patch"]);
  const filesBeforeManifest = listFiles(evidenceRoot).filter((file) => !relativePosix(file).startsWith("manifests/"));
  const utf8Errors = [];
  const jsonErrors = [];
  const jsonlErrors = [];
  const filenameErrors = [];
  const secretHits = [];
  const decoder = new TextDecoder("utf-8", { fatal: true });
  const secretPatterns = [
    /ghp_[A-Za-z0-9]{20,}/g,
    /github_pat_[A-Za-z0-9_]{20,}/g,
    /sk-[A-Za-z0-9]{20,}/g,
    /AIza[0-9A-Za-z_-]{20,}/g,
    /AKIA[0-9A-Z]{16}/g,
    /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
  ];
  for (const file of filesBeforeManifest) {
    const relative = relativePosix(file);
    if (!/^[\x20-\x7E]+$/.test(relative)) filenameErrors.push(relative);
    const extension = path.extname(file).toLowerCase();
    if (!textExtensions.has(extension)) continue;
    let text;
    try {
      text = decoder.decode(readFileSync(file));
    } catch (error) {
      utf8Errors.push({ path: relative, error: String(error) });
      continue;
    }
    if (text.includes("\uFFFD")) {
      utf8Errors.push({ path: relative, error: "Contains Unicode replacement character U+FFFD" });
    }
    if (extension === ".json") {
      try { JSON.parse(text); } catch (error) { jsonErrors.push({ path: relative, error: String(error) }); }
    }
    if (extension === ".jsonl") {
      text.split(/\n/).forEach((line, index) => {
        if (!line.trim()) return;
        try { JSON.parse(line); } catch (error) { jsonlErrors.push({ path: relative, line: index + 1, error: String(error) }); }
      });
    }
    for (const pattern of secretPatterns) {
      const matches = [...text.matchAll(pattern)];
      if (matches.length) secretHits.push({ path: relative, pattern: String(pattern), count: matches.length });
    }
  }
  const validation = {
    validated_at: new Date().toISOString(),
    file_count_before_manifests: filesBeforeManifest.length,
    utf8: { status: utf8Errors.length ? "FAIL" : "PASS", errors: utf8Errors },
    json: { status: jsonErrors.length ? "FAIL" : "PASS", errors: jsonErrors },
    jsonl: { status: jsonlErrors.length ? "FAIL" : "PASS", errors: jsonlErrors },
    ascii_filenames: { status: filenameErrors.length ? "FAIL" : "PASS", errors: filenameErrors },
    sensitive_information_scan: { status: secretHits.length ? "FAIL" : "PASS", hits: secretHits },
  };
  writeJson("validation/content-validation.json", validation);
  return validation;
}

const contentValidation = validateEvidence();
const contentPassed = Object.values(contentValidation)
  .filter((value) => value && typeof value === "object" && "status" in value)
  .every((value) => value.status === "PASS");
if (!contentPassed) throw new Error("Evidence content validation failed.");

const manifestCandidates = listFiles(evidenceRoot).filter((file) => !relativePosix(file).startsWith("manifests/"));
const manifestLines = manifestCandidates.map((file) => `${sha256File(file)}  ${relativePosix(file)}`);
writeText("manifests/SHA256SUMS", manifestLines.join("\n") + "\n");

const verifyErrors = [];
for (const line of manifestLines) {
  const [expected, relative] = line.split("  ");
  const actual = sha256File(path.join(evidenceRoot, ...relative.split("/")));
  if (expected !== actual) verifyErrors.push({ path: relative, expected, actual });
}
const validationReport = {
  validated_at: new Date().toISOString(),
  package: packageName,
  aggregate_status: verifyErrors.length ? "FAIL" : "PASS",
  required_command_exit_codes: Object.fromEntries(commandRecords.map((record) => [record.id, record.exit_code])),
  c01_c14: productSummary.counts,
  conformance_result_schema_validated_by_product_runner: true,
  product_reader_called: true,
  reference_reader_called: false,
  content_validation: contentValidation,
  sha256_manifest: {
    status: verifyErrors.length ? "FAIL" : "PASS",
    entries: manifestLines.length,
    errors: verifyErrors,
  },
};
writeJson("validation/validation-report.json", validationReport);
if (validationReport.aggregate_status !== "PASS") throw new Error("SHA-256 validation failed.");

const finalManifestFiles = listFiles(evidenceRoot).filter((file) => relativePosix(file) !== "manifests/SHA256SUMS");
const finalLines = finalManifestFiles.map((file) => `${sha256File(file)}  ${relativePosix(file)}`);
writeText("manifests/SHA256SUMS", finalLines.join("\n") + "\n");

const zipScript = [
  "import pathlib, zipfile",
  `root = pathlib.Path(${JSON.stringify(evidenceRoot)})`,
  `zip_path = pathlib.Path(${JSON.stringify(zipPath)})`,
  "with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:",
  "    for p in sorted(root.rglob('*')):",
  "        if p.is_file():",
  "            z.write(p, pathlib.Path(root.name) / p.relative_to(root))",
].join("\n");
const zipResult = await run("D:\\FCoP\\.venv\\Scripts\\python.exe", ["-c", zipScript], workspace);
if (zipResult.exitCode !== 0) throw new Error(`ZIP creation failed: ${zipResult.stderr}`);
const zipDigest = sha256File(zipPath);
writeFileSync(zipShaPath, `${zipDigest}  ${path.basename(zipPath)}\n`, "ascii");

const zipCheckScript = [
  "import pathlib, zipfile",
  `p = pathlib.Path(${JSON.stringify(zipPath)})`,
  "with zipfile.ZipFile(p) as z:",
  "    bad = z.testzip()",
  "    print('ZIP_OK' if bad is None else f'ZIP_BAD:{bad}')",
  "    print(f'ZIP_ENTRIES={len(z.infolist())}')",
].join("\n");
const zipCheck = await run("D:\\FCoP\\.venv\\Scripts\\python.exe", ["-c", zipCheckScript], workspace);
if (zipCheck.exitCode !== 0 || !zipCheck.stdout.includes("ZIP_OK")) throw new Error(`ZIP verification failed: ${zipCheck.stdout}${zipCheck.stderr}`);

process.stdout.write(JSON.stringify({
  evidence_directory: evidenceRoot,
  zip: zipPath,
  zip_sha256_file: zipShaPath,
  zip_sha256: zipDigest,
  zip_check: zipCheck.stdout.trim(),
  file_count: listFiles(evidenceRoot).length,
  c01_c14: productSummary.counts,
  commands_all_exit_zero: commandRecords.every((record) => record.exit_code === 0),
}, null, 2) + "\n");
