#!/usr/bin/env node
/**
 * Formal CLI entry for WP-14 switchboard state migration.
 * Usage:
 *   node --import tsx packages/codeflowmu-runtime/scripts/migrate-switchboard-state.mts [persistDir]
 *   npm --prefix packages/codeflowmu-runtime exec -- tsx scripts/migrate-switchboard-state.mts
 */

import { resolve } from "node:path";
import { migrateSwitchboardState } from "../src/switchboard/recovery/MigrateSwitchboardState.ts";

const persistDir = resolve(
  process.argv[2] ??
    resolve(process.cwd(), ".codeflowmu", "state"),
);
const dryRun = process.argv.includes("--dry-run");

const result = await migrateSwitchboardState({ persistDir, dryRun });
console.log(JSON.stringify(result, null, 2));
if (result.gaps.some((g) => g.code === "layout.newer_than_runtime")) {
  process.exitCode = 2;
}
