import { strict as assert } from "node:assert";
import { describe, it } from "node:test";
import {
  functionCallOrderMismatch,
  resolveOrderedFunctionCalls,
} from "../geminiFunctionCallsOrder.ts";

describe("geminiFunctionCallsOrder", () => {
  it("prefers model parts order over stream functionCalls", () => {
    const modelParts = [
      { functionCall: { name: "fcop_check", id: "b", args: {} } },
      { functionCall: { name: "write_report", id: "a", args: {} } },
    ];
    const streamCalls = [
      { name: "write_report", id: "a", args: {} },
      { name: "fcop_check", id: "b", args: {} },
    ];
    const ordered = resolveOrderedFunctionCalls(modelParts, streamCalls);
    assert.equal(ordered.length, 2);
    assert.equal(ordered[0]!.name, "fcop_check");
    assert.equal(ordered[1]!.name, "write_report");
    assert.equal(functionCallOrderMismatch(modelParts, streamCalls), true);
  });

  it("falls back to stream calls when parts have no functionCall", () => {
    const streamCalls = [{ name: "read_file", args: { path: "a.ts" } }];
    const ordered = resolveOrderedFunctionCalls([{ text: "hi" }], streamCalls);
    assert.equal(ordered.length, 1);
    assert.equal(ordered[0]!.name, "read_file");
  });
});
