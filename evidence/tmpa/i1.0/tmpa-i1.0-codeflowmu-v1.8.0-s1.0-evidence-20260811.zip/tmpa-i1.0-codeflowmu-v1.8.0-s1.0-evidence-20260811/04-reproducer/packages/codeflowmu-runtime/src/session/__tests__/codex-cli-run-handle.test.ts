import assert from "node:assert/strict";
import test from "node:test";

import { CodexCliRunHandle } from "../CodexCliRunHandle.ts";

test("Codex JSONL maps observable reasoning and tool lifecycle without fabricating thinking", async () => {
  const handle = new CodexCliRunHandle({
    sessionId: "session-test",
    agentId: "PM-01",
    provider: "openai-chatgpt-subscription",
    model: "gpt-5.6-sol",
  });
  const events: string[] = [];
  handle.onEvent((event) => events.push(event.event_type));

  handle.acceptEventForTest({
    type: "item.completed",
    item: { id: "reason-1", type: "reasoning", text: "observable summary" },
  });
  handle.acceptEventForTest({
    type: "item.started",
    item: { id: "tool-1", type: "mcp_tool_call", name: "list_tasks" },
  });
  handle.acceptEventForTest({
    type: "item.completed",
    item: { id: "tool-1", type: "mcp_tool_call", status: "completed" },
  });
  handle.acceptEventForTest({
    type: "item.completed",
    item: { id: "msg-1", type: "agent_message", text: "done" },
  });
  handle.acceptEventForTest({ type: "turn.completed", usage: { input_tokens: 1 } });

  const run = await handle.whenSettled();
  assert.equal(run.status, "finished");
  assert.equal(run.tool_calls_count, 1);
  assert.equal(events.filter((type) => type === "sdk.tool_call").length, 1);
  assert.equal(events.filter((type) => type === "sdk.tool_result").length, 1);
  assert.ok(events.includes("sdk.status"));
  assert.ok(events.includes("sdk.assistant"));
  assert.ok(!events.includes("sdk.thinking"));
});
