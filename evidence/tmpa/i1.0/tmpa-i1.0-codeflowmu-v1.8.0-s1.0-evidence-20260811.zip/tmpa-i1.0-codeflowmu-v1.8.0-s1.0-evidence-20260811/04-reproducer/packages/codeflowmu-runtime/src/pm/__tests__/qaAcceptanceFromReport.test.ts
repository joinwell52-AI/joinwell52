import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { evaluateQaReportAcceptance } from "../qaAcceptanceFromReport.ts";

describe("qaAcceptanceFromReport", () => {
  it("keeps QA business FAIL separate from whether QA completed its work", () => {
    const result = evaluateQaReportAcceptance({
      sender: "QA",
      recipient: "PM",
      status: "fail",
      body: "## 结论\n\n**FAIL**：产品不满足验收标准。",
    });
    assert.equal(result?.verdict, "fail");
    assert.equal(result?.blocksReview, false);
  });

  it("keeps an actually blocked QA execution open", () => {
    const result = evaluateQaReportAcceptance({
      sender: "QA",
      recipient: "PM",
      status: "blocked",
      body: "依赖环境不可用，尚未完成检查。",
    });
    assert.equal(result?.verdict, "blocked");
    assert.equal(result?.blocksReview, true);
  });
});
