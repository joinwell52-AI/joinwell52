import assert from "node:assert/strict";
import { it } from "node:test";

import { appendAuxiliaryGoogleToolDeclarations } from "../GoogleGenAiAdapter.ts";

it("exposes web research tools to every agent role in default fcop_minimal mode", () => {
  for (const agentId of ["PM", "DEV", "QA", "OPS", "EVAL", "TM", "ARCHITECT", "UI"]) {
    const tools: Array<{ name: string; description: string; parameters: unknown }> = [];
    appendAuxiliaryGoogleToolDeclarations({
      mode: "fcop_minimal",
      googleTools: tools,
      agentId,
      pmSelfReportOnly: false,
      pmDevColdDispatch: false,
      taskDispatchForWorkspace: false,
      selectedToolNames: [],
    });
    const names = tools.map((tool) => tool.name);
    assert.equal(names.includes("web_search"), true, `${agentId} lacks web_search`);
    assert.equal(names.includes("web_extract"), true, `${agentId} lacks web_extract`);
    assert.equal(names.includes("web_research"), true, `${agentId} lacks web_research`);
    assert.equal(names.includes("skill_search"), true, `${agentId} lacks skill_search`);
    assert.equal(names.includes("skill_learn"), true, `${agentId} lacks skill_learn`);
    assert.equal(names.includes("skill_publish"), agentId === "PM", `${agentId} skill_publish exposure mismatch`);
    assert.equal(names.includes("read_file"), false);
    assert.equal(names.includes("write_file"), false);
  }
});

it("keeps skill_publish out of workspace_read mode", () => {
  const tools: Array<{ name: string; description: string; parameters: unknown }> = [];
  appendAuxiliaryGoogleToolDeclarations({
    mode: "workspace_read",
    googleTools: tools,
    agentId: "PM",
    pmSelfReportOnly: false,
    pmDevColdDispatch: false,
    taskDispatchForWorkspace: false,
    selectedToolNames: [],
  });
  assert.equal(tools.some((tool) => tool.name === "skill_search"), true);
  assert.equal(tools.some((tool) => tool.name === "skill_learn"), true);
  assert.equal(tools.some((tool) => tool.name === "skill_publish"), false);
});
