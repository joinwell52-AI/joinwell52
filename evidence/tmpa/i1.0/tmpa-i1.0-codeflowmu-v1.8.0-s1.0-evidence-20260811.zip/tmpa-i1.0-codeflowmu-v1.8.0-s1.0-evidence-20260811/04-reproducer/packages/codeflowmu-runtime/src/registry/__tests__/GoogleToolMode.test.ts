import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  FCOP_MINIMAL_CORE_TOOLS,
  filterGoogleToolsByMode,
  isGoogleDispatchAllowed,
  resolveGoogleToolMode,
  WORKSPACE_READ_TOOLS,
} from "../GoogleToolMode.ts";

describe("GoogleToolMode", () => {
  it("resolveGoogleToolMode prefers CODEFLOW_GOOGLE_TOOL_MODE", () => {
    const env = {
      CODEFLOW_GOOGLE_TOOL_MODE: "workspace_read",
      CODEFLOW_GEMINI_TOOL_MODE: "full",
    };
    assert.equal(resolveGoogleToolMode(env as NodeJS.ProcessEnv), "workspace_read");
  });

  it("resolveGoogleToolMode falls back to legacy gemini mode", () => {
    const env = { CODEFLOW_GEMINI_TOOL_MODE: "trim" };
    assert.equal(resolveGoogleToolMode(env as NodeJS.ProcessEnv), "trim");
  });

  it("resolveGoogleToolMode defaults invalid google mode to fcop_minimal", () => {
    const env = { CODEFLOW_GOOGLE_TOOL_MODE: "not-a-mode" };
    assert.equal(resolveGoogleToolMode(env as NodeJS.ProcessEnv), "fcop_minimal");
  });

  it("filterGoogleToolsByMode fcop_minimal exposes core + vision only", () => {
    const allowed = [
      ...FCOP_MINIMAL_CORE_TOOLS,
      "write_task",
      "vision.inspect_attachment",
      "read_file",
      "fcop_audit",
    ];
    const selected = filterGoogleToolsByMode({
      mode: "fcop_minimal",
      agentId: "DEV-01",
      allowedTools: allowed,
      promptText: "实现功能",
    });
    assert.deepEqual(
      selected.sort(),
      [...FCOP_MINIMAL_CORE_TOOLS, "vision.inspect_attachment"].sort(),
    );
    assert.equal(selected.includes("write_task"), false);
    assert.equal(selected.includes("read_file"), false);
  });

  it("filterGoogleToolsByMode workspace_read adds read tools", () => {
    const selected = filterGoogleToolsByMode({
      mode: "workspace_read",
      agentId: "DEV-01",
      allowedTools: [
        ...FCOP_MINIMAL_CORE_TOOLS,
        ...WORKSPACE_READ_TOOLS,
        "vision.inspect_attachment",
      ],
    });
    for (const tool of WORKSPACE_READ_TOOLS) {
      assert.equal(selected.includes(tool), true);
    }
  });

  it("isGoogleDispatchAllowed blocks DEV write_task dispatch", () => {
    assert.equal(
      isGoogleDispatchAllowed({ agentId: "DEV-01", promptText: "派单" }),
      false,
    );
  });

  it("isGoogleDispatchAllowed allows PM cold-path reject prompt", () => {
    const prompt =
      "ADMIN 已拒绝，请写下游 TASK 返工（cold path / 冷路径）";
    assert.equal(
      isGoogleDispatchAllowed({ agentId: "PM-01", promptText: prompt }),
      true,
    );
  });
});
