/**
 * Google Gemini runtime layers — CodeFlowMu tool runtime on bare Gemini API.
 *
 * Cursor channel = Cursor SDK native toolbox + FCoP MCP filter.
 * Google channel = this stack: schema + stream + tool results + dedupe + queue + FCoP file semantics.
 */

import { resolveGeminiToolSelectionMode } from "./geminiToolSelection.ts";
import { shouldUseFcopOneShot } from "./FcopMcpOneShot.ts";

export type GoogleGeminiRuntimeLayer =
  | "schema"
  | "stream"
  | "tool_result"
  | "dedupe"
  | "queue"
  | "fcop_semantics";

export interface GoogleGeminiRuntimeLayerInfo {
  id: GoogleGeminiRuntimeLayer;
  module: string;
  responsibility: string;
}

/** Six layers the Google adapter must coordinate (not a bare API wrapper). */
export const GOOGLE_GEMINI_RUNTIME_LAYERS: readonly GoogleGeminiRuntimeLayerInfo[] = [
  {
    id: "schema",
    module: "FcopMcpOneShot / stdio MCP tools/list + geminiToolSelection + geminiWorkspaceTools",
    responsibility:
      "Expose function declarations: FCoP one-shot static schemas or live MCP inputSchema; workspace read/grep/list/write; profile/trim/full selection.",
  },
  {
    id: "stream",
    module: "geminiContentStream + GoogleGenAiAdapter send loop",
    responsibility:
      "generateContentStream with thinking/assistant deltas; optional googleSearch/codeExecution via env.",
  },
  {
    id: "tool_result",
    module: "geminiChatHistory + GoogleGenAiAdapter tool loop",
    responsibility:
      "Execute FCoP one-shot/stdio MCP or workspace tools; classify outcomes; feed functionResponse back into chat history; consecutive read-only tools may batch via geminiToolParallel (CODEFLOW_GEMINI_PARALLEL_READONLY).",
  },
  {
    id: "dedupe",
    module: "geminiToolDedupe",
    responsibility:
      "Per-round + global dedupe for mutating FCoP calls; read_file/grep_files retries; patrol summarize hints on reuse.",
  },
  {
    id: "queue",
    module: "GoogleGenAiAdapter.enqueueGoogleGenerate",
    responsibility:
      "Serialize Gemini generate calls with CODEFLOW_GOOGLE_REQUEST_GAP_MS spacing (rate-limit safety).",
  },
  {
    id: "fcop_semantics",
    module: "geminiWorkspaceTools + fcop_invoke_once.py + googleAdapterAcceptance prompts",
    responsibility:
      "TASK path fallback under _lifecycle/; write_task/write_report body without YAML; leader hot/cold path tool sets.",
  },
] as const;

export function describeGoogleGeminiRuntime(): string {
  const mode = resolveGeminiToolSelectionMode();
  const oneShot = shouldUseFcopOneShot();
  const layers = GOOGLE_GEMINI_RUNTIME_LAYERS.map((l) => l.id).join(", ");
  return (
    `Google tool runtime [${layers}] · tool_mode=${mode} · fcop=${oneShot ? "one-shot" : "stdio-mcp"}`
  );
}
