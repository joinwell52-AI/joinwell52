import assert from "node:assert/strict";
import { describe, it } from "node:test";

import {
  GOOGLE_GEMINI_RUNTIME_LAYERS,
  describeGoogleGeminiRuntime,
} from "../googleGeminiRuntime.ts";

describe("googleGeminiRuntime", () => {
  it("defines six runtime layers in fixed order", () => {
    assert.deepEqual(
      GOOGLE_GEMINI_RUNTIME_LAYERS.map((l) => l.id),
      ["schema", "stream", "tool_result", "dedupe", "queue", "fcop_semantics"],
    );
    for (const layer of GOOGLE_GEMINI_RUNTIME_LAYERS) {
      assert.ok(layer.module.length > 0);
      assert.ok(layer.responsibility.length > 0);
    }
  });

  it("schema layer mentions workspace grep", () => {
    const schema = GOOGLE_GEMINI_RUNTIME_LAYERS.find((l) => l.id === "schema");
    assert.ok(schema);
    assert.match(schema!.responsibility, /grep/i);
  });

  it("dedupe layer mentions grep_files retries", () => {
    const dedupe = GOOGLE_GEMINI_RUNTIME_LAYERS.find((l) => l.id === "dedupe");
    assert.ok(dedupe);
    assert.match(dedupe!.responsibility, /grep_files/);
  });

  it("describeGoogleGeminiRuntime includes layers and tool mode", () => {
    const line = describeGoogleGeminiRuntime();
    assert.match(line, /^Google tool runtime \[/);
    assert.match(line, /schema/);
    assert.match(line, /fcop_semantics/);
    assert.match(line, /tool_mode=(profile|trim|full)/);
    assert.match(line, /fcop=(one-shot|stdio-mcp)/);
  });
});
