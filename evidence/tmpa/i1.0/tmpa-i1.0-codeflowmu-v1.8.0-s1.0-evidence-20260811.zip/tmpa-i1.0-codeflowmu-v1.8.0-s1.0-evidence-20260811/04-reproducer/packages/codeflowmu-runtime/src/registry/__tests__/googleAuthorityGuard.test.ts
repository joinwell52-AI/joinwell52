import { strict as assert } from "node:assert";
import { describe, it } from "node:test";

import {
  checkGoogleToolAuthority,
  resolveRoleFromAgentId,
} from "../googleAuthorityGuard.ts";

describe("googleAuthorityGuard", () => {
  it("maps leader agent ids to PM role", () => {
    assert.equal(resolveRoleFromAgentId("PM-01"), "PM");
    assert.equal(resolveRoleFromAgentId("PLANNER-2"), "PM");
  });

  it("denies DEV write_task", () => {
    const result = checkGoogleToolAuthority({
      agentId: "DEV-01",
      toolName: "write_task",
    });
    assert.equal(result.allowed, false);
    if (!result.allowed) {
      assert.equal(result.error.code, "AUTHORITY_DENIED");
      assert.equal(result.error.role, "DEV");
      assert.equal(result.error.toolName, "write_task");
    }
  });

  it("allows PM write_task", () => {
    const result = checkGoogleToolAuthority({
      agentId: "PM-01",
      toolName: "write_task",
    });
    assert.equal(result.allowed, true);
  });

  it("allows DEV write_report but not create_task", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "DEV-01",
        toolName: "write_report",
      }).allowed,
      true,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "DEV-01",
        toolName: "create_task",
      }).allowed,
      false,
    );
  });

  it("allows QA write_review but denies write_task", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "QA-01",
        toolName: "write_review",
      }).allowed,
      true,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "QA-01",
        toolName: "write_task",
      }).allowed,
      false,
    );
  });

  it("allows DEV claim_task (executor lifecycle)", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "DEV-01",
        toolName: "claim_task",
      }).allowed,
      true,
    );
  });

  it("allows QA vision.inspect_attachment", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "QA-01",
        toolName: "vision.inspect_attachment",
      }).allowed,
      true,
    );
  });

  it("allows DEV vision.inspect_attachment", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "DEV-01",
        toolName: "vision.inspect_attachment",
      }).allowed,
      true,
    );
  });

  it("denies DEV write_file (workspace write not in executor allow set)", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "DEV-01",
        toolName: "write_file",
      }).allowed,
      false,
    );
  });

  it("allows every agent to discover and learn skills", () => {
    for (const agentId of ["PM-01", "DEV-01", "QA-01", "OPS-01", "EVAL-01"]) {
      assert.equal(checkGoogleToolAuthority({ agentId, toolName: "skill_search" }).allowed, true);
      assert.equal(checkGoogleToolAuthority({ agentId, toolName: "skill_learn" }).allowed, true);
    }
  });

  it("allows only PM leaders to publish skills", () => {
    assert.equal(checkGoogleToolAuthority({ agentId: "PM-01", toolName: "skill_publish" }).allowed, true);
    assert.equal(checkGoogleToolAuthority({ agentId: "DEV-01", toolName: "skill_publish" }).allowed, false);
    assert.equal(checkGoogleToolAuthority({ agentId: "QA-01", toolName: "skill_publish" }).allowed, false);
  });

  it("allows ADMIN governance and dispatch tools", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "ADMIN",
        toolName: "approve_task",
      }).allowed,
      true,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "ADMIN",
        toolName: "write_task",
      }).allowed,
      true,
    );
  });

  it("allows EVAL observer read/write tools but denies lifecycle and audit", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "list_tasks",
      }).allowed,
      true,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "write_report",
      }).allowed,
      true,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "claim_task",
      }).allowed,
      false,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "fcop_audit",
      }).allowed,
      false,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "fcop_report",
      }).allowed,
      false,
    );
  });

  it("EVAL write_task only allows recipient PM or ADMIN", () => {
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "write_task",
        args: { recipient: "PM" },
      }).allowed,
      true,
    );
    assert.equal(
      checkGoogleToolAuthority({
        agentId: "EVAL-01",
        toolName: "write_task",
        args: { recipient: "ADMIN" },
      }).allowed,
      true,
    );
    const denied = checkGoogleToolAuthority({
      agentId: "EVAL-01",
      toolName: "write_task",
      args: { recipient: "DEV" },
    });
    assert.equal(denied.allowed, false);
    if (!denied.allowed) {
      assert.equal(denied.error.role, "EVAL");
      assert.equal(denied.error.toolName, "write_task");
    }
  });
});
