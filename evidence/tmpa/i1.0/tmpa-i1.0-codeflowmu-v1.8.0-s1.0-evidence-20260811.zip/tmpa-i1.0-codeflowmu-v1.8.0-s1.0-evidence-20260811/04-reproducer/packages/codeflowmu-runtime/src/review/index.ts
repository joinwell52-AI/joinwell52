/**
 * Public surface of the review subsystem (Sprint S4).
 *
 * Importers MAY pull from `@codeflowmu/runtime/review` (when path-mapped)
 * or `@codeflowmu/runtime` (top-level barrel — see `src/index.ts`).
 * Either way, only the symbols re-exported here are part of the package's
 * stable v0.1 contract.
 */

export {
  DefaultReviewPolicy,
  ReviewEngine,
  defaultMakeReviewId,
  parseVerdict,
  type ReviewEngineLogger,
  type ReviewEngineOptions,
  type ReviewPolicy,
  type TaskReference,
} from "./ReviewEngine.ts";

export {
  NeedsHumanGate,
  UnsupportedHumanPushSinkError,
  type HumanApprovedSpec,
  type HumanPushRequest,
  type NeedsHumanGateLogger,
  type NeedsHumanGateOptions,
} from "./NeedsHumanGate.ts";

export {
  ReviewWriter,
  renderReviewMarkdown,
  type HumanApproval,
  type ReviewDecision,
  type ReviewSubjectType,
  type ReviewVerdict,
  type ReviewWriterOptions,
} from "./ReviewWriter.ts";

export {
  ReviewWriteError,
  ReviewerNotFoundError,
  VerdictParseError,
} from "../registry/errors.ts";

export {
  resolveReviewEvidence,
  type ReviewEvidenceResolveInput,
  type ReviewEvidenceTimeWindow,
  type EvidenceSummary,
  type EvidenceSummarySession,
  type EvidenceSummaryCommand,
  type EvidenceSummaryDataQuery,
} from "./ReviewEvidenceResolver.ts";

export {
  resolveExecutionProvenance,
  type ExecutionBindingTuple,
  type ExecutionProvenanceSourceName,
  type ExecutionProvenanceSource,
  type ExecutionProvenanceConflict,
  type ExecutionProvenanceResult,
  type ResolveExecutionProvenanceInput,
} from "./ExecutionProvenanceResolver.ts";

export {
  detectReportClaims,
  evaluateReviewFactGate,
  resolveReportedOutcome,
  type FactCheckVerdict,
  type ReviewFactState,
  type FactCheckReasonCode,
  type ReportClaims,
  type FactCheckResult,
  type ExecutionEvidenceState,
  type ReportedOutcome,
  type PmFactDecision,
} from "./ReviewFactGate.ts";

export {
  FACT_SOURCE_ROOT_REL,
  FACT_SOURCE_SOURCES_REL,
  FACT_SOURCE_STANDARDS_REL,
  FACT_SOURCE_ADAPTER_IDS,
  FACT_VALIDATOR_IDS,
  inspectFactSourceRegistry,
  evaluateBoundThirdPartyFacts,
  type FactSourceDefinition,
  type FactStandardDefinition,
  type FactStandardValidator,
  type FactSourceRegistrySnapshot,
  type ThirdPartyFactCheckResult,
  type ThirdPartySourceState,
} from "./FactSourceRegistry.ts";

export {
  inspectUtf8Text,
  inspectUtf8File,
  decodeUtf8Strict,
  type TextEncodingCheck,
  type TextEncodingState,
} from "./TextEncodingGate.ts";

export {
  compileAcceptanceContract,
  evaluateAcceptanceContract,
  type AcceptanceContract,
  type AcceptanceContractItem,
  type AcceptanceContractEvaluation,
  type AcceptanceEvidenceType,
  type EvidenceEnvelope,
} from "./AcceptanceContract.ts";

export {
  FactCheckDecisionService,
  FactCheckDecisionError,
  type FactCheckDecisionAction,
  type FactCheckDecisionRecord,
} from "./FactCheckDecisionService.ts";

export {
  writeFactCheckReview,
  type WriteFactCheckReviewInput,
} from "./writeFactCheckReview.ts";

export {
  overruleReviewGate,
  type OverruleReviewGateInput,
  type OverruleReviewGateResult,
} from "./overruleReviewGate.ts";

export {
  extractCitedEvidencePaths,
  loadCitedEvidenceFiles,
  type CitedEvidenceFile,
} from "./citedEvidenceFiles.ts";

export {
  resolveReviewLinkedTaskId,
  type ResolveReviewLinkedTaskIdOptions,
} from "./resolveReviewLinkedTaskId.ts";

export {
  humanApprovalApprovedAt,
  isReviewPendingHuman,
  reviewMatchesScope,
} from "./reviewHumanApproval.ts";

export {
  buildReviewGateApprovalCard,
  collectReviewGateRedFlags,
  evaluateReviewGateAutoPass,
  REVIEW_GATE_RED_FLAG_LABELS,
  type ReviewGateApprovalCard,
  type ReviewGateAutoPassResult,
  type ReviewGateBuildInput,
  type ReviewGateRedFlag,
  type ReviewGateRisk,
} from "./reviewGateApprovalCard.ts";

export {
  loadReviewDecisionPolicy,
  saveReviewDecisionPolicy,
  enabledTeamRules,
  renderReviewDecisionPolicyPromptBlock,
  policyFilePath,
  type ReviewDecisionPolicy,
  type PolicyRule,
  type PolicyRuleAction,
  type LoadReviewDecisionPolicyOpts,
} from "./ReviewDecisionPolicyLoader.ts";
