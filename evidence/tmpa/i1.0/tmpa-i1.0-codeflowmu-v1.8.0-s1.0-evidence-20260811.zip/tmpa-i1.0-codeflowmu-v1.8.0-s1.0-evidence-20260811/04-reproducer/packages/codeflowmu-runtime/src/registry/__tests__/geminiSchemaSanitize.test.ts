import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { sanitizeSchemaForGemini } from "../geminiSchemaSanitize.ts";

describe("sanitizeSchemaForGemini", () => {
  it("strips $schema and additionalProperties recursively", () => {
    const input = {
      $schema: "http://json-schema.org/draft-07/schema#",
      type: "object",
      additionalProperties: false,
      properties: {
        task_id: {
          type: "string",
          additionalProperties: true,
        },
      },
    };
    const out = sanitizeSchemaForGemini(input) as Record<string, unknown>;
    assert.equal(out.$schema, undefined);
    assert.equal(out.additionalProperties, undefined);
    assert.equal(out.type, "OBJECT");
    const props = out.properties as Record<string, Record<string, unknown>>;
    assert.equal(props.task_id!.type, "STRING");
    assert.equal(props.task_id!.additionalProperties, undefined);
  });

  it("uppercases nested array item types", () => {
    const input = {
      type: "array",
      items: { type: "string" },
    };
    const out = sanitizeSchemaForGemini(input) as Record<string, unknown>;
    assert.equal(out.type, "ARRAY");
    assert.deepEqual(out.items, { type: "STRING" });
  });
});
