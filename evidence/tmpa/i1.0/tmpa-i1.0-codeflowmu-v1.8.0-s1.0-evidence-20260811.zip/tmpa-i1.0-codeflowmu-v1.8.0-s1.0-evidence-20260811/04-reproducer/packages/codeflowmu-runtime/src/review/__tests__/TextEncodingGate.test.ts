import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { decodeUtf8Strict, inspectUtf8Text } from "../TextEncodingGate.ts";

describe("TextEncodingGate", () => {
  it("accepts clean UTF-8 Chinese governance text", () => {
    const result = inspectUtf8Text("执行结果：事实证据已核对，等待 PM 验收。\n");
    assert.equal(result.state, "verified");
    assert.equal(result.code, "ENCODING_UTF8");
  });

  it("rejects question-mark mojibake even when the file is valid UTF-8 bytes", () => {
    const result = inspectUtf8Text("## ??\n????????????????\n");
    assert.equal(result.state, "invalid");
    assert.equal(result.code, "ENCODING_INVALID");
    assert.ok(result.findings.includes("question_mark_run"));
  });

  it("rejects byte sequences that are not strict UTF-8", () => {
    const result = decodeUtf8Strict(new Uint8Array([0xc3, 0x28]));
    assert.equal(result.check.state, "invalid");
    assert.ok(result.check.findings.includes("strict_utf8_decode_failed"));
  });
});
