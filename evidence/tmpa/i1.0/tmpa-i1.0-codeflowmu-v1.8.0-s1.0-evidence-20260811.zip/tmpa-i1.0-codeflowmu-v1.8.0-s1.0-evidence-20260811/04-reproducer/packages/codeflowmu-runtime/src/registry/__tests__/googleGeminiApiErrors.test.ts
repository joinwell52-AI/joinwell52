import { strict as assert } from "node:assert";
import { describe, it } from "node:test";

import {
  classifyGeminiApiError,
  formatGeminiModelNotFoundMessage,
  isGeminiModelNotFoundError,
} from "../googleGeminiApiErrors.ts";

describe("googleGeminiApiErrors", () => {
  it("classifies 404 model not found as MODEL_NOT_FOUND", () => {
    const err = new Error("models/gemini-bad is not found for API version");
    (err as { status?: number }).status = 404;
    const c = classifyGeminiApiError(err);
    assert.equal(c.kind, "MODEL_NOT_FOUND");
    assert.equal(c.retryable, false);
    assert.equal(isGeminiModelNotFoundError(err), true);
  });

  it("classifies 503 as TRANSIENT", () => {
    const err = new Error("Service unavailable");
    (err as { status?: number }).status = 503;
    const c = classifyGeminiApiError(err);
    assert.equal(c.kind, "TRANSIENT");
    assert.equal(c.retryable, true);
    assert.equal(isGeminiModelNotFoundError(err), false);
  });

  it("classifies 429 as TRANSIENT", () => {
    const err = new Error("Rate limit exhausted");
    const c = classifyGeminiApiError(err);
    assert.equal(c.kind, "TRANSIENT");
    assert.equal(isGeminiModelNotFoundError(err), false);
  });

  it("formatGeminiModelNotFoundMessage includes model id", () => {
    const msg = formatGeminiModelNotFoundMessage(
      new Error("404 not found"),
      "gemini-missing",
    );
    assert.match(msg, /MODEL_NOT_FOUND/);
    assert.match(msg, /gemini-missing/);
  });
});
