import { describe, it } from "node:test";
import assert from "node:assert/strict";

import {
  extractTaskIdPrefixFromFilepath,
  guardWriteReportTaskId,
  normalizeWriteReportTaskIdPrefix,
  resolveExplicitSessionPinnedTaskId,
  resolveSessionPinnedTaskId,
  WRITE_REPORT_TASK_ID_AUTOFILL_TAG,
} from "../geminiWriteReportTaskIdGuard.ts";

describe("geminiWriteReportTaskIdGuard", () => {
  const pinned = "TASK-20260607-029";

  it("normalizeWriteReportTaskIdPrefix extracts prefix from full filename", () => {
    assert.equal(
      normalizeWriteReportTaskIdPrefix("TASK-20260607-029-ADMIN-to-PM"),
      pinned,
    );
  });

  it("autofills missing task_id from pinned session", () => {
    const result = guardWriteReportTaskId(
      { reporter: "PM", recipient: "ADMIN", body: "done", status: "done" },
      pinned,
    );
    assert.equal(result.action, "repair");
    if (result.action !== "repair") return;
    assert.equal(result.args.task_id, pinned);
    assert.equal(result.repairTag, WRITE_REPORT_TASK_ID_AUTOFILL_TAG);
  });

  it("passes when task_id suffix matches pinned prefix", () => {
    const result = guardWriteReportTaskId(
      {
        task_id: "TASK-20260607-029-PM-to-ADMIN",
        reporter: "PM",
        recipient: "ADMIN",
        body: "final",
        status: "done",
      },
      pinned,
    );
    assert.equal(result.action, "pass");
  });

  it("rejects hallucinated task_id with TASK_ID_MISMATCH", () => {
    const result = guardWriteReportTaskId(
      {
        task_id: "TASK-SMOKETEST-001",
        reporter: "PM",
        recipient: "ADMIN",
        body: "done",
        status: "done",
      },
      pinned,
    );
    assert.equal(result.action, "reject");
    if (result.action !== "reject") return;
    assert.equal(result.code, "TASK_ID_MISMATCH");
    assert.equal(result.providedTaskId, "TASK-SMOKETEST-001");
    assert.equal(result.pinnedTaskId, pinned);
  });

  it("resolveExplicitSessionPinnedTaskId: 不从 prompt 推断 task_id", () => {
    const r = resolveExplicitSessionPinnedTaskId({
      taskFilepath: "fcop/_lifecycle/active/TASK-20260607-029-ADMIN-to-PM.md",
    });
    assert.equal(r.pinnedTaskId, pinned);
    assert.equal(r.source, "spec_taskFilepath");

    const noSpec = resolveExplicitSessionPinnedTaskId({});
    assert.equal(noSpec.pinnedTaskId, null);
    assert.equal(noSpec.source, "none");

    const withPromptOnly = resolveSessionPinnedTaskId({
      promptText: "TASK-20260101-001",
    });
    assert.equal(withPromptOnly.source, "prompt_text");
    const explicitOnly = resolveExplicitSessionPinnedTaskId({});
    assert.equal(explicitOnly.pinnedTaskId, null);
  });

  it("passes through when no pinned task in session", () => {
    const args = { reporter: "PM", body: "x" };
    const result = guardWriteReportTaskId(args, null);
    assert.equal(result.action, "pass");
    assert.deepEqual(result.args, args);
  });

  it("resolveSessionPinnedTaskId: spec.pinnedTaskId 优先", () => {
    const r = resolveSessionPinnedTaskId({
      pinnedTaskId: pinned,
      taskFilepath: "fcop/_lifecycle/active/TASK-20260607-029-ADMIN-to-PM.md",
      frontmatterTaskId: "TASK-20260607-029",
      promptText: "TASK-20260101-001",
    });
    assert.equal(r.pinnedTaskId, pinned);
    assert.equal(r.source, "spec_pinnedTaskId");
  });

  it("resolveSessionPinnedTaskId: 无 pinned 时从 taskFilepath 解析", () => {
    const r = resolveSessionPinnedTaskId({
      taskFilepath: "fcop/_lifecycle/active/TASK-20260607-029-ADMIN-to-PM.md",
      promptText: "无 TASK 前缀的 PM 提示",
    });
    assert.equal(r.pinnedTaskId, pinned);
    assert.equal(r.source, "spec_taskFilepath");
  });

  it("resolveSessionPinnedTaskId: frontmatter 兜底", () => {
    const r = resolveSessionPinnedTaskId({
      frontmatterTaskId: "TASK-20260607-029-ADMIN-to-PM",
      promptText: "plain prompt",
    });
    assert.equal(r.pinnedTaskId, pinned);
    assert.equal(r.source, "spec_frontmatterTaskId");
  });

  it("extractTaskIdPrefixFromFilepath 解析真实 active 路径", () => {
    assert.equal(
      extractTaskIdPrefixFromFilepath(
        "fcop/_lifecycle/active/TASK-20260607-029-ADMIN-to-PM.md",
      ),
      pinned,
    );
    assert.equal(
      extractTaskIdPrefixFromFilepath(
        "D:\\codeflowmu\\fcop\\_lifecycle\\active\\TASK-20260607-029-ADMIN-to-PM.md",
      ),
      pinned,
    );
  });
});
