/**
 * 单次 send 会话内 write_report 物理执行防刷（dedupe 键失效时的最后一道闸）。
 */

export function tryReserveWriteReportExecute(
  reservedKeys: Set<string>,
  dedupeKey: string,
): boolean {
  if (reservedKeys.has(dedupeKey)) return false;
  reservedKeys.add(dedupeKey);
  return true;
}

export function releaseWriteReportReserve(
  reservedKeys: Set<string>,
  dedupeKey: string,
): void {
  reservedKeys.delete(dedupeKey);
}

export const WRITE_REPORT_DEDUPE_REUSE_MESSAGE =
  "FCoP 强控：本会话已对相同 write_report 落盘，禁止重复执行。请基于当前 ledger 继续派发或写 status=done 汇总。";
