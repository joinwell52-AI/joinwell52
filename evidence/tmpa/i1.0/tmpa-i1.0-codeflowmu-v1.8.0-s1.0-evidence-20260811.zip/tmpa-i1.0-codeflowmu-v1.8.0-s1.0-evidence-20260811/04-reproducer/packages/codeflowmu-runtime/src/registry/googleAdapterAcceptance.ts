/**
 * Google 工具运行时（GoogleGenAiAdapter 全链路）验收文案 — PM 派单 / 执行者 playbook / Adapter 注入共用。
 * 「Google 工具箱」≠ 外部 Google Cloud；≠ 仅 read_file 几个路径。
 */

export const GOOGLE_ADAPTER_SCOPE_ZH = [
  "**「Google 工具箱」定义**：CodeFlowMu **GoogleGenAiAdapter 工具运行时**（Gemini schema → one-shot MCP 归一化 → tool dedupe → tool result 回灌 → stream 事件 → ledger references/parent 一致），**不是**外部 Google Cloud 产品，也**不是**仅 `read_file` 若干路径。",
].join("\n");

/** PM Cold Path 返工子任务 body 必含块（Markdown 列表，可直接拼进 write_task body）。 */
export const PM_REWORK_ADAPTER_BODY_CHECKLIST_ZH = [
  "## Google 工具运行时验收（Adapter 六层）",
  "",
  GOOGLE_ADAPTER_SCOPE_ZH,
  "",
  "- **`references` MCP 参数必填**（`thread_key` 继承父任务；body 仅 Markdown，禁止 YAML/frontmatter）",
  "- 验收须逐项附**证据**（命令/工具名 + 输出摘要），禁止空泛 blocked：",
  "  1. **Schema**：`write_task` 含 `references` + `thread_key`",
  "  2. **One-shot 归一化**：body「父任务引用：TASK-…」→ frontmatter `references`（查 `_lifecycle` 磁盘）",
  "  3. **Dedupe**：同 `recipient`+`references` 不重复新建 TASK",
  "  4. **Tool result 回灌**：`write_report`/`write_task` 无 Gemini 400 / malformed function call",
  "  5. **Stream**：journal 可见 `sdk.tool_call` / `sdk.tool_result`",
  "  6. **Ledger**：子任务 frontmatter `references`/`parent` 与 PM 派单一致",
  "",
  "### 分角色交付",
  "- **DEV**：改 `packages/codeflowmu-runtime/src/registry/*`、`scripts/fcop_invoke_once.py`；附单测命令与通过摘要",
  "- **QA**：跑 `frontmatter.test.ts`、`geminiToolDedupe.test.ts`、`test_fcop_write_task_normalize.py`；对照六层逐项记录",
  "- **OPS**：`read_file` → `skills/ops-runtime-health/SKILL.md`；附 runtime health 表 + adapter 观测（one-shot / journal 工具事件）",
].join("\n");

/** 执行者 playbook 追加段（DEV/QA/OPS）。 */
export const EXECUTOR_ADAPTER_BLOCKED_RULE_ZH = [
  "## Google 工具运行时 · blocked 规则",
  GOOGLE_ADAPTER_SCOPE_ZH,
  "- **禁止** 以「Google 工具箱不可用 / 无 shell / 无权限」为由空泛 `status=blocked`。",
  "- 若 blocked：**必须**列出已调 MCP/workspace tool 名、**错误原文**、缺失能力；并说明已尝试的 adapter 验收层（见上六层）。",
  "- 环境类任务：先用 `read_file` / `write_report` / `write_task`（按角色）；失败时正文贴 tool 返回，而非臆断。",
].join("\n");

export const EXECUTOR_ADAPTER_BLOCKED_RULE_EN = [
  "## Google tool runtime · blocked rules",
  "Google toolbox = GoogleGenAiAdapter chain (schema, one-shot normalize, dedupe, tool-result replay, stream events, ledger refs) — NOT external Google Cloud, NOT read_file-only checks.",
  "Do NOT blocked with vague 'toolbox unavailable'. If blocked: list tool names tried, verbatim errors, missing capability, and which adapter layer failed.",
].join("\n");
