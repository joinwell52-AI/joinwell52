/** TMPA Core S0.5/S0.6/S1.0 public contracts used by the CodeFlowMu projection and reader. */

export type TmpaCoreVersion = "S0.5" | "S0.6" | "S1.0";

export type TmpaJudgment = "valid" | "invalid" | "undetermined";

export type TmpaViewState =
  | "authoritative"
  | "rejected"
  | "quarantined"
  | "partial"
  | "disputed"
  | "pending_human";

export type TmpaAuthenticationState =
  | "authenticated"
  | "unauthenticated"
  | "not_applicable";

export interface TmpaReference {
  relation: string;
  target: string;
}

export interface TmpaClaim {
  id: string;
  predicate: string;
  subject: string;
  evidence: string[];
}

export interface TmpaRisk {
  level: "low" | "medium" | "high" | "irreversible";
  requires_human_approval: boolean;
}

export interface TmpaIntegrity {
  canonicalization: string;
  hash_algorithm: string;
  digest: string;
  signature_algorithm?: string | null;
  key_id?: string | null;
  signature?: string | null;
}

export interface TmpaStream {
  id: string;
  sequence: number;
}

export interface TmpaLifecycleTransition {
  from: string;
  action: string;
  to: string;
}

export interface TmpaGovernanceObject {
  tmpa_version: TmpaCoreVersion;
  id: string;
  type: string;
  governed_work: {
    id: string;
    primary_carrier_id: string;
    parent_id?: string;
    thread_id?: string;
  };
  stream: TmpaStream;
  creator: string;
  role: string;
  created_at: string;
  lifecycle: {
    profile: string;
    state: string;
    transition?: TmpaLifecycleTransition;
  };
  references: TmpaReference[];
  claims?: TmpaClaim[];
  risk?: TmpaRisk;
  content: {
    media_type: string;
    body: unknown;
  };
  integrity: TmpaIntegrity;
  extensions?: Record<string, unknown>;
}

export interface TmpaLifecycleTransitionRule extends TmpaLifecycleTransition {
  allowed_roles: string[];
  required_relations: string[];
  preconditions?: string[];
  separation_of_duties?: string[];
}

export interface TmpaAcceptanceProfile {
  states_requiring_acceptance: string[];
  acceptance_relations: string[];
  allowed_roles: string[];
  requires_independent_actor: boolean;
  archive_requires_acceptance: boolean;
}

export interface TmpaWorkGraphProfile {
  completion_claim_predicates: string[];
  response_relations: string[];
  child_terminal_states: string[];
}

export interface TmpaRiskPolicy {
  human_approval_levels: Array<"low" | "medium" | "high" | "irreversible">;
  approval_relations: string[];
  approval_roles: string[];
  approval_object_types?: string[];
  requires_independent_actor?: boolean;
}

export interface TmpaFailureModel {
  failure_types: string[];
  recovery_actions: string[];
}

export interface TmpaReviewConflictResolutionProfile {
  action: string;
  allowed_roles: string[];
  resolution_relation: string;
  selection_field: string;
}

export interface TmpaLifecycleProfile {
  id: string;
  version: string;
  states: string[];
  initial_state: string;
  terminal_states: string[];
  actions: string[];
  transitions: TmpaLifecycleTransitionRule[];
  recovery_rules?: string[];
  acceptance: TmpaAcceptanceProfile;
  work_graph: TmpaWorkGraphProfile;
  risk_policy: TmpaRiskPolicy;
  failure_model: TmpaFailureModel;
  extensions?: {
    document_types?: string[];
    assignments?: Array<{
      identity: string;
      role: string;
      actions: string[];
    }>;
    ordering_relations?: string[];
    acyclic_relations?: string[];
    review_conflict_resolution?: TmpaReviewConflictResolutionProfile;
    [key: string]: unknown;
  };
}

export interface TmpaVersionedInput {
  id: string;
  version: string;
  digest: string;
}

export type TmpaIssueCode =
  | "SCHEMA_INVALID"
  | "UNKNOWN_TYPE"
  | "INTEGRITY_MISMATCH"
  | "SIGNATURE_UNVERIFIED"
  | "DUPLICATE_ID_CONFLICT"
  | "PRIMARY_CARRIER_CONFLICT"
  | "STREAM_DUPLICATE_SEQUENCE"
  | "STREAM_GAP"
  | "AUTHORITY_UNDETERMINED"
  | "AUTHORITY_DENIED"
  | "SOD_VIOLATION"
  | "LIFECYCLE_UNDETERMINED"
  | "ILLEGAL_TRANSITION"
  | "MISSING_REFERENCE"
  | "PROHIBITED_CYCLE"
  | "UNRESOLVED_CONFLICT"
  | "CLAIM_EVIDENCE_MISSING"
  | "ACCEPTANCE_UNDETERMINED"
  | "HUMAN_APPROVAL_REQUIRED"
  | "CHILD_WORK_OPEN"
  | "RECIPROCITY_MISSING"
  | "STATE_EVIDENCE_CONFLICT";

export type TmpaIssueSeverity = "critical" | "error" | "warning" | "info";

export interface TmpaIssue {
  issue_id: string;
  code: TmpaIssueCode;
  severity: TmpaIssueSeverity;
  source_id: string;
  source_object_id?: string;
  object_id: string;
  relation?: string;
  target_id?: string;
  message?: string;
}

export interface TmpaReaderNode {
  id: string;
  source_object_id: string;
  source_ids?: string[];
  canonical_digest?: string;
  governed_work_id?: string;
  primary_carrier_id?: string;
  parent_work_id?: string;
  thread_id?: string;
  type?: string;
  stream_id?: string;
  stream_sequence?: number;
  role?: string;
  creator?: string;
  judgment: TmpaJudgment;
  view_state?: TmpaViewState;
}

export interface TmpaReaderEdge {
  id: string;
  source_object_id: string;
  source_id: string;
  relation: string;
  target_id: string;
  ordering?: boolean;
}

export interface TmpaReaderResult {
  core_version: TmpaCoreVersion;
  output_version: "1";
  profile: {
    conformance_profile: TmpaVersionedInput;
    object_schema: TmpaVersionedInput;
    type_registry: TmpaVersionedInput;
    lifecycle_registry: TmpaVersionedInput;
    role_registry: TmpaVersionedInput;
    relation_registry: TmpaVersionedInput;
    integrity_profile: TmpaVersionedInput;
    canonicalization_profile: TmpaVersionedInput;
  };
  reader: { id: string; version: string };
  source_set_digest: string;
  judgment: TmpaJudgment;
  view_state: TmpaViewState;
  authentication_state?: TmpaAuthenticationState;
  nodes: TmpaReaderNode[];
  edges: TmpaReaderEdge[];
  issues: TmpaIssue[];
  extensions?: Record<string, unknown>;
}

export type TmpaConformanceVerdict = "PASS" | "FAIL" | "PARTIAL" | "NOT RUN";

export type TmpaCriterionId =
  | "C01"
  | "C02"
  | "C03"
  | "C04"
  | "C05"
  | "C06"
  | "C07"
  | "C08"
  | "C09"
  | "C10"
  | "C11"
  | "C12"
  | "C13"
  | "C14";

export interface TmpaConformanceCriterion {
  id: TmpaCriterionId;
  verdict: TmpaConformanceVerdict;
  run_state: "completed" | "error";
  manifest_digest: string;
  result_digest: string;
}

export interface TmpaConformanceResult {
  core_version: TmpaCoreVersion;
  implementation: { id: string; version: string };
  input_bundle_digest: string;
  criteria: TmpaConformanceCriterion[];
  aggregate_verdict: TmpaConformanceVerdict;
  evidence_level: "specified" | "implemented" | "demonstrated" | "independently_adopted";
}
