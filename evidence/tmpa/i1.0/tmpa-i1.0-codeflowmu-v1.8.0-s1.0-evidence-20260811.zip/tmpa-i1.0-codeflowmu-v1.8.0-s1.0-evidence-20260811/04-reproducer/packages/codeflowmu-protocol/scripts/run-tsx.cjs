#!/usr/bin/env node

const { spawnSync } = require("node:child_process");

const windowsUserInfoCompat =
  process.platform === "win32"
    ? ["--import", "data:text/javascript,process.geteuid=()=>1"]
    : [];
const inheritedNodeOptions = String(process.env.NODE_OPTIONS ?? "").trim();
const childNodeOptions =
  process.platform === "win32"
    ? [
        inheritedNodeOptions,
        "--import=data:text/javascript,process.geteuid=()=>1",
      ]
        .filter(Boolean)
        .join(" ")
    : inheritedNodeOptions;
const result = spawnSync(
  process.execPath,
  [...windowsUserInfoCompat, "--import", "tsx", ...process.argv.slice(2)],
  {
    cwd: process.cwd(),
    env: childNodeOptions
      ? { ...process.env, NODE_OPTIONS: childNodeOptions }
      : process.env,
    stdio: "inherit",
    windowsHide: true,
  },
);
if (result.error) {
  process.stderr.write(`${result.error.message}\n`);
  process.exit(1);
}
process.exit(result.status ?? 1);
