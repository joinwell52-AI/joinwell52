# WP-13 多 Agent 事实复核证据包

本目录是可独立审阅的出版证据包，记录 WP-13 中一次“子执行给出完成意味声明，但事实证据尚不充分；PM 复核后不予放行；DEV 补齐真实交付；角色分离 QA 验证通过”的完整链路。

## 核心结论

- 治理控制结果成功：PM 没有把工具层 `completed/success` 等同于业务完成，而是核对文件、Git、REPORT 与测试事实。
- 工具通道与退出状态可观察性仍构成独立工程缺口：内部命令缺少可确认退出状态时，Runtime 不能把调用完成投影成工作完成。
- 本案例中的 QA 是“角色分离 QA 验证”，不是外部第三方独立验证。
- 轨道机负责承载状态、依赖、证据引用和通知；最终业务裁决由 Agent 根据任务合同与事实证据完成。
- 本包证明 DEV 已完成并取得角色分离 QA PASS；快照时 TASK-019/020 仍为 `review / pending`，不证明 PM 最终批准或终态关闭。

## 建议阅读顺序

1. `report.md`：完整案例报告与结论。
2. `business-overview.png`：业务流程总览。
3. `task-019.md`、`task-020.md`、`product-brief.md`、`schedule-lifecycle-note.md`：任务合同、计划提前与快照生命周期边界。
4. `subexecution-task-completed-raw.jsonl`：子执行完整原始事件，是关键直接证据。
5. `subexecution-result-readable.json`：原始事件结果字段的可读投影。
6. `session-transcript.txt`、`runtime-events-wp13-excerpt.jsonl`：会话与 Runtime 时间线。
7. `dev-report-037.md`、`qa-report-038.md`、`qa-evidence/`：纠正后的 DEV/QA 交付证据。
8. `commit-609571.patch`、`commit-609571-manifest.txt`：代码事实。
9. `checksums.sha256`：包内文件完整性校验。

## 文件清单

| 文件 | 类型 | 说明 |
|---|---|---|
| `report.md` | 报告 | 案例主报告 |
| `business-overview.png` | 图片 | 业务流程图 |
| `pm-fact-check.png` | 图片 | PM 磁盘事实复核截图 |
| `task-019.md` | 原始治理文件 | WP-13 DEV 任务 |
| `task-020.md` | 原始治理文件 | WP-13 QA 任务 |
| `product-brief.md` | 原始治理文件 | 长任务 Product Brief |
| `schedule-lifecycle-note.md` | 边界说明 | 计划与实际日期、改期依据缺口、快照终态限制 |
| `dev-report-037.md` | 原始治理文件 | DEV 正式回执 |
| `qa-report-038.md` | 原始治理文件 | QA 正式回执 |
| `session-transcript.txt` | 会话证据 | 关键会话摘录 |
| `subexecution-task-completed-raw.jsonl` | 原始 Runtime 证据 | 完整 `task completed` 事件 |
| `subexecution-result-readable.json` | 派生阅读件 | 原始事件 `result.value` 的格式化投影 |
| `runtime-events-wp13-excerpt.jsonl` | 原始 Runtime 证据 | 按本案标识符抽取的原始事件行 |
| `qa-evidence/test-data.json` | 原始 QA 证据 | 测试数据 |
| `qa-evidence/test-cases.json` | 原始 QA 证据 | 测试用例 |
| `qa-evidence/command-results.json` | 原始 QA 证据 | 命令结果 |
| `qa-evidence/qa-full-check.json` | 原始 QA 证据 | QA 全量检查结果 |
| `qa-evidence/result-summary.json` | 原始 QA 证据 | QA 结果摘要 |
| `commit-609571.patch` | Git 证据 | 完整 commit 补丁 |
| `commit-609571-manifest.txt` | Git 证据 | commit 元数据与文件 Manifest |
| `provenance.md` | 来源说明 | 拷贝、抽取与派生规则 |
| `checksums.sha256` | 完整性证据 | SHA-256 清单 |

## 关键原始证据如何读

`subexecution-task-completed-raw.jsonl` 是单条、未经改写的 Runtime 原始 JSONL 事件；其 `payload.raw.name=task`、`payload.raw.status=completed`。它直接保留了：

- `spawnError`；
- “no exit status”；
- “Test results summary: Unconfirmed in this session.”；
- “Commit SHA: Not available here (no shell/read output).”；
- “Shell output was not returned in this session...”及完整子执行总结。

因此，上述判断不再只是 PM 或报告作者的派生描述。`subexecution-result-readable.json` 是从该原始事件的 `payload.raw.result.value` 字段格式化得到的阅读辅助件，不能替代原始 JSONL。

## 跨平台与编码

- ZIP 内所有条目名称均使用 ASCII，避免 Windows/GBK 与 Linux 解压器之间的中文文件名乱码。
- Markdown、JSON、JSONL 和文本内容统一按 UTF-8 发布。
- 正式压缩包名称：`wp13-multi-agent-fact-check-publication-evidence-v3.zip`。

## 边界

本包证明的是这一具体事件中的多 Agent 事实复核闭环成功，不表示工具通道不存在缺陷，也不表示所有任务都已具备同等质量的证据合同。EVAL 可作为旁路观察参考，但不直接驱动 lifecycle 或替代 PM/ADMIN 裁决。

`qa-report-038.md` 是历史原始回执，正文沿用了“独立验收”表述；为保持证据原貌，本包未改写该源文件。出版报告统一采用更准确的“角色分离 QA 验证”：QA 与 DEV 角色分离，但并非外部第三方审计。

`dev-report-037.md` 与 `qa-report-038.md` 的 `runtime_bound: False` 原样保留：它们不是 Runtime 认证证据。`checksums.sha256` 与内容同包且未签名，只能验证包内一致性，不能独立证明来源真实性。`pm-fact-check.png` 是恢复后保存的历史消息截图，不是故障时刻的同步文件状态。
