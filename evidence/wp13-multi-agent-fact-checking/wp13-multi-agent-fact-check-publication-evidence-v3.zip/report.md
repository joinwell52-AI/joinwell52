# WP-13 多 Agent 事实复核成功拦截无证据完成声明事件报告

> 记录性质：外部只读观察报告；不属于 FCoP `TASK / REPORT / ISSUE / REVIEW`，不驱动生命周期。
>
> 观察对象：`TASK-20260805-019`（WP-13 DEV）及其 QA 派生任务 `TASK-20260805-020`
>
> 观察时间：2026-08-05 12:59—13:11（Asia/Shanghai）

## Executive Summary

- **治理控制结果成功，但工具通道与退出状态可观察性仍构成独立工程缺口。** 一个执行分支给出了带有“完成”意味的总结，但没有可确认的命令退出状态、测试结果、提交 SHA 或正式 DEV REPORT。PM 没有采信语言声明，而是检查磁盘、Git 和账本事实，判断 WP-13 尚未真实完成。
- **轨道机正确退居“轨道”，没有代替 Agent 作业务裁决。** Runtime 负责保持原任务、记录工具事件、避免重复派单和提供可观察状态；“证据是否足以证明任务完成”由 PM 依据任务合同自主判断。
- **原任务得到纠正并形成可复核的 DEV + QA 证据链。** DEV 在工具恢复后补齐代码、测试和正式回执，形成 commit `609571ddb22d1fbb2bfb5e54692c07beeef4cf23`；随后由角色分离的 QA 复核，27/27 测试通过、typecheck 0、diff check 0，并给出 QA PASS。证据快照截止时，DEV/QA 两个 TASK 仍为 `review / pending`，因此本包不宣称 PM 已最终批准或任务已终态关闭。
- **案例为多 Agent 治理价值提供了工程证据。** 防幻觉不是让程序用固定正则替代业务判断，而是让不同角色在同一事实链上相互校验：执行者提出完成声明，PM 核实证据并决定是否放行，角色分离的 QA 验证交付结果。这里的“角色分离”不等于外部第三方审计。

## 核心结论：轨道机只提供轨道，Agent 才负责裁决

本次事件明确了 CodeFlowMu 的职责边界：

| 层级 | 应负责 | 不应负责 |
|---|---|---|
| 轨道机 / Runtime | 身份与角色边界、任务生命周期、依赖释放、路由、重试、去重、事件留痕、证据可达性检查 | 理解所有业务场景、替 PM 判定“交付是否满足任务目标”、凭关键词生成最终业务裁决 |
| DEV | 在任务范围内自主执行、如实报告结果与证据；不确定时明确“不确定” | 把无退出状态、无测试结果、无提交的过程描述当成完成事实 |
| PM | 读取任务合同，核对磁盘、Git、REPORT 和依赖事实，自主决定继续、返工、派 QA 或收口 | 盲信 Agent 自述；把生命周期 `done` 等同于业务验收通过 |
| QA | 按任务类型与验收合同独立选择证据清单并验证 | 套用与任务无关的固定证据模板，或仅复述 DEV 结论 |

因此，本案例不应被归类为“轨道机没有自动判断成功”。相反，它证明：**轨道机没有越位裁决，PM 的智能事实复核成功阻止了未经证实的完成声明进入正式交付链。**

## 从无证据声明到角色分离 QA 验证的完整链路

| 时间 | 角色 / 系统 | 发生的事实 | 证据状态 | 治理结果 |
|---|---|---|---|---|
| 12:59 | PM | 派发 WP-13 `TASK-20260805-019` 并唤醒 DEV | 正式 TASK 存在 | 任务进入执行轨道 |
| 13:01—13:03 | DEV | 已产生部分代码；随后 Edit/Shell/Read 多次停留在 `running`，没有可靠退出状态 | 仅有部分产物；测试、提交、REPORT 未形成 | 尚不能证明完成 |
| 13:03—13:06 | DEV 子执行分支 | 尝试完成剩余工作；Shell 明确返回 `no exit status`，却生成了带“完成”意味的总结，同时承认测试未确认、SHA 不可得 | 声明与事实不闭合 | 完成声明不具备放行条件 |
| 13:08 | PM | 自主检查磁盘与 Git：`TASK-019` 仍 active、无 DEV REPORT、测试文件缺失、HEAD 仍是 WP-12；判断“不能当真完成” | 反证完整 | **成功拦截**；不派 QA、不新建重复任务 |
| 13:07—13:08 | DEV | 主会话工具恢复，补齐实现与测试，形成真实提交 `609571dd…`，写正式 `REPORT-037` | 代码、测试、commit、REPORT 齐全 | 原任务得到真实完成 |
| 13:09 | PM | 在证据齐全后派发 QA `TASK-20260805-020` | DEV 交付可审计 | 进入角色分离 QA 验证 |
| 13:11 | QA | 以不同角色执行 27 项测试、typecheck、diff check，并核对未启用 Active/未改真投递路径 | 27/27 PASS；typecheck 0；diff 0 | `REPORT-038` 判定 PASS |

## PM 拦截的依据不是“感觉”，而是可验证的反证

PM 没有尝试理解所有工具异常类型，也没有把某个正则命中当作裁决。PM 只回答一个业务问题：**当前事实是否足以证明 WP-13 已完成？**

当时四项关键条件均不成立：

| 完成所需事实 | PM 复核时的实际状态 | 判定 |
|---|---|---|
| 正式 DEV REPORT | 不存在 | 未满足 |
| 对应 WP-13 commit | HEAD 仍为 WP-12 `9fe5391a` | 未满足 |
| 任务要求的测试文件 | `activity-buffer.test.ts`、`observation.test.ts` 尚未落盘 | 未满足 |
| 可确认的测试与命令结果 | 子执行分支反复出现 `no exit status`，并明确承认结果未确认 | 未满足 |

这四项来自任务合同和实际工作产物，不是通用固定清单。换一种任务类型，PM/QA 应从该任务的目标、风险与验收条款中生成另一份证据清单。

## 纠正后的事实链完整且可复核

DEV 最终正式回执 `REPORT-20260805-037-DEV-to-PM.md` 给出了以下可验证事实：

- commit：`609571ddb22d1fbb2bfb5e54692c07beeef4cf23`
- 变更：12 个 WP-13 文件，`1230 insertions / 452 deletions`
- observation：3/3 PASS
- activity-buffer + project-graph：10/10 PASS
- root-fault + log-center：14/14 PASS
- runtime typecheck：exit 0
- 安全边界：未启用生产 Active，未改 TaskDispatcher 真投递路径，未 push

QA 随后没有照抄 DEV 报告，而是在隔离证据目录执行角色分离复核：

- 测试总计：27/27 PASS
- typecheck：0
- `git diff --check`：0
- `requires_browser=false`：本任务属于 switchboard/shell 契约与观察快照，不强加浏览器证据
- commit 范围检查：未包含 TaskDispatcher；`production_active` 保持 false

这一步证明拦截不是“把任务卡住”，而是把未经证实的完成声明转换成了可复核的真实交付。

## 这个案例沉淀出的正确防幻觉机制

### 1. 证据清单必须来自任务合同，而不是全局固定模板

Runtime 可以检查证据对象是否存在、是否可读取、是否与任务关联，但不能预先穷举所有任务需要什么证据。正确顺序是：

1. PM 从任务目标、风险和验收条件生成本任务的证据合同；
2. DEV 按合同提供交付证据；
3. Runtime 校验引用是否真实存在、关系是否闭合、状态是否一致；
4. QA 以分离角色根据任务类型执行验证；
5. PM 综合 TASK、DEV REPORT、QA REPORT 与异常信息作业务裁决。

### 2. “工具调用成功”不等于“业务完成”

子执行工具返回 completed/success，只能证明调用生命周期结束；若内部命令没有退出状态，就不能证明文件已写、测试已跑或提交已生成。完成判定必须回到外部事实：文件、commit、命令结果、正式 REPORT 和角色分离 QA 验证。

### 3. 轨道机应提供可观察的事实，不应输出业务真相

轨道机适合输出：`task active`、`REPORT missing`、`commit reference unreachable`、`dependency unmet`、`duplicate dispatch suppressed`。它可以建议“证据不足，请 PM 复核”，但不应直接裁定“任务失败”或擅自生成返工内容。

### 4. 返工必须由 Agent 基于缺失事实决定

本次 PM 选择继续同一个 `TASK-019`，而不是让 Runtime 自动复制任务。这样保留了原任务语义、避免重复执行，并让 DEV 在工具恢复后完成同一交付链。若缺失证据意味着产品实现本身错误，再由 PM/QA决定是否生成返工任务。

## 产品化建议

1. **固化“证据不足 → PM 复核”的建议态。** Runtime 发现无 REPORT、引用不可达、命令状态未知时，只记录 `evidence_incomplete` 并通知 PM，不自动作业务 reject。
2. **允许任务携带类型化证据合同。** 例如代码任务可声明 commit、测试、typecheck、边界检查；UI 任务可声明浏览器、交互和截图；文档任务可声明结构、引用和渲染检查。合同由 PM/任务规划生成，Runtime 只做结构校验。
3. **区分三种“成功”。** 工具调用成功、执行任务完成、业务验收通过必须使用不同状态，界面不得混写。
4. **保留同任务纠正优先。** 工具异常恢复后优先续跑原 task；只有 PM 判断 scope 或执行路径确需变化时才新建返工任务。
5. **把本案例纳入回归测试。** 构造“子执行返回 success，但命令无退出状态、无 commit、无 REPORT”的场景，期望：Runtime 留痕并提示；PM 复核后不放行；原任务续办；DEV 真实回执后才派 QA。
6. **EVAL 只作为观察参考。** EVAL 可发现遗漏、异常模式与证据缺口，但不驱动 lifecycle、不自动 approve/reject；PM/ADMIN 可把它作为裁决输入之一。

## 后续应验证的问题

- 任务证据合同由 Product Brief、TASK 还是 PM 在派发时生成，哪个对象拥有最终版本？
- Runtime 如何稳定表达 `unknown`，避免把“无退出状态”折叠成 success 或 failure？
- PM 复核结论是否需要一个轻量、不可变、但不增加人工负担的证据引用结构？
- 同一任务恢复与新建返工任务的边界，是否能由 PM 明确的语义操作表达，而不是 Runtime 猜测？

## 边界与说明

- 本报告不把工具通道异常归因于权限系统；日志只证明部分调用没有返回可确认的退出状态。
- 子执行分支的总结包含自我保留说明，因此更准确的描述是“未经证据支持的完成意味声明”，不是恶意造假。
- 后续存在的 ReportWatcher 旧 PM→ADMIN 报告重扫问题与本案例的多 Agent 拦截链无关，应该单独追踪。
- 本报告证明的是这一具体事件的控制闭环成功，不代表所有任务都已具备同等质量的证据合同。
- Product Brief 把 WP-13 规划在 2026-08-13，实际执行发生在 2026-08-05，属于相对原计划的提前执行；本包没有收录单独的重新排期或批准文件，不能据此证明已完成正式改期审批。详见 `schedule-lifecycle-note.md`。
- 快照截止时 `TASK-20260805-019` 与 `TASK-20260805-020` 均为 `state: review`、`review_status: pending`。本包只证明 DEV 交付完成并取得角色分离 QA PASS，不证明 PM 最终批准、归档或终态关闭。
- `dev-report-037.md` 与 `qa-report-038.md` 均保留 `runtime_bound: False`；它们是正式角色回执和作者生成工程证据，但不是 Runtime 认证证据。
- `checksums.sha256` 与被校验文件位于同一未签名包内，只能证明包内文件的一致性，不能独立证明发布者身份、来源真实性或时间戳真实性。
- `pm-fact-check.png` 是工具恢复后保存的历史消息截图，用于呈现 PM 的复核过程；它不是故障发生时刻的同步文件系统快照。

## 证据索引

| 证据 | 用途 |
|---|---|
| `task-019.md` | PM→DEV 的 WP-13 正式任务合同 |
| `task-020.md` | PM→QA 的角色分离验证任务合同 |
| `product-brief.md` | 根任务 Product Brief；提供 WP-13 在长任务中的目标与验收语境 |
| `schedule-lifecycle-note.md` | 计划日期、实际执行日期、改期依据缺口及快照生命周期边界 |
| `session-transcript.txt` | 从工具异常、子执行声明、PM 复核到 DEV 恢复的会话摘录 |
| `subexecution-task-completed-raw.jsonl` | 子执行 `task completed` 的完整原始 Runtime 事件；四项关键判断的首要直接证据 |
| `subexecution-result-readable.json` | 上述原始事件中 `payload.raw.result.value` 的可读投影，便于审阅，不替代原始事件 |
| `runtime-events-wp13-excerpt.jsonl` | 与 TASK-019/020、REPORT-037/038、会话和 commit 关联的 Runtime 原始事件节选 |
| `dev-report-037.md` | DEV 真实交付、测试、commit 与边界声明 |
| `qa-report-038.md` | 角色分离 QA 的 27/27、typecheck 0、diff 0 验收 |
| `qa-evidence/*.json` | QA 五个原始结构化结果文件 |
| `commit-609571.patch` | commit `609571ddb22d1fbb2bfb5e54692c07beeef4cf23` 的完整邮件格式补丁 |
| `commit-609571-manifest.txt` | 同一 commit 的元数据、文件清单、行数统计与 diff stat |
| `pm-fact-check.png` | PM 在放行前核对磁盘、Git、REPORT 与任务状态的业务截图 |
| `business-overview.png` | 面向业务读者的案例流程图 |

其中，`no exit status`、`spawnError`、测试未确认和 SHA 不可得，不再仅依赖派生说明：它们均可在 `subexecution-task-completed-raw.jsonl` 的完整原始事件中直接复核。`subexecution-result-readable.json` 只用于降低阅读成本；发生差异时，以原始 JSONL 为准。

![PM 对无证据完成声明进行磁盘事实复核](pm-fact-check.png)
