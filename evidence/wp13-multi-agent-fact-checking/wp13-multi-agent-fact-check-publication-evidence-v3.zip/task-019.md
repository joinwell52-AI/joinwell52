---
protocol: fcop
version: 1
sender: PM
recipient: DEV
task_id: TASK-20260805-019
priority: P1
thread_key: submission-submission-20260804-001
parent: TASK-20260804-001
references: "['TASK-20260804-001', 'TASK-20260805-018']"
depends_on: "[]"
state: review
created_at: 2026-08-05T12:59:27+08:00
writer: codeflowmu-one-shot-fallback
lifecycle_path: fcop/_lifecycle/review
transitions:
  - at: 2026-08-05T12:59:31+08:00
    from: inbox
    to: active
    by: CodeFlowMu
    action: runtime_dispatch
  - at: 2026-08-05T13:08:40+08:00
    from: active
    to: review
    by: DEV
    action: submit_review
    report: REPORT-20260805-037-DEV-to-PM
dispatch_attempt_id: attempt-69a62c45-bd3a-489e-a185-fef7ec767c66
execution_lease_id: lease-28197022-d4fe-4915-ae62-543a3106b49b
dispatch_agent_id: DEV-01
display_status: waiting_pm_review
pm_attention_reason: 事实核查需人工裁定：正式验收合同不完整或证据存在多种合理解释，需要 PM 裁决；acceptance criteria exist but required_evidence_types/validator are not explicit；建议：acceptance criteria exist but required_evidence_types/validator are not explicit
pm_attention_report_id: REPORT-20260805-037-DEV-to-PM
lifecycle_projection: review
review_status: pending
submitted_at: 2026-08-05T05:08:40.024Z
---

# DEV实施 WP-13 观察和兼容

# DEV实施 WP-13 观察和兼容

## 背景
parent=`TASK-20260804-001`。Brief **WP-13**。前置 WP-12 已收口：DEV `TASK-017`/`REPORT-035` + QA `TASK-018`/`REPORT-036` **PASS**。

硬约束：禁止启用生产 Active；禁止改真投递路径；lifecycle 桶名 ≠ 业务通过态；Desktop 与 PWA 同树同序。

## 目标产出
1. 保持旧观察面（RuntimeEvent、Panel、PWA、Mobile、旧 REST、实时 SSE）
2. 补充可读字段：Host/Binding/Run/Delivery/instance_id/runtime role/registry-data-fcop root/writer lock/Gateway/隔离告警
3. 统一 ProjectGraph；业务五态；等待 ADMIN 可指向真实 Gate
4. 字段表 + API 样例（或截图路径）+ 独立 commit

## 测试要求
Desktop 与 PWA 同树同序；lifecycle 桶名 ≠ 业务通过态；字段可读；typecheck 绿

## 回执
`REPORT-*-DEV-to-PM.md` · 字段表/API 样例 + commit SHA

## 验收与依赖
- 验收人：QA（本包完成后由 PM 派）
- depends_on：TASK-20260805-018

---

## state_history (auto-appended by runtime)

- **2026-08-05T12:59:31+08:00** | by `runtime` | `inbox` → `dispatched` session_id=session-9-msfmayqe
- **2026-08-05T12:59:31+08:00** | by `runtime` | `dispatched` → `running` session_id=session-9-msfmayqe
- **2026-08-05T13:08:49+08:00** | by `runtime` | `dispatched` → `ended` status=completed
