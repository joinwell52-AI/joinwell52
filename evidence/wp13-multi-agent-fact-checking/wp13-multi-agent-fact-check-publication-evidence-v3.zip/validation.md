# 出版包验证记录

验证日期：2026-08-05（Asia/Shanghai）

## 结构化证据解析

| 检查 | 结果 |
|---|---|
| ZIP 结构 | 24 个文件；条目名全部为 ASCII |
| SHA-256 | 23/23 通过（不含校验清单自身） |
| 文本编码 | 严格 UTF-8 解码 0 失败 |
| QA 五个原始 JSON | 5/5 可解析 |
| 子执行可读投影 JSON | 1/1 可解析 |
| WP-13 Runtime 事件节选 | 300 行，0 行解析失败 |
| 子执行完整原始事件 | 1 行，0 行解析失败 |
| 原始子执行结果 vs 可读投影 | 语义一致 |

## 关键原文命中

在 `subexecution-task-completed-raw.jsonl` 中直接检索：

| 原文 | 命中数 |
|---|---:|
| `spawnError` | 24 |
| `no exit status` | 24 |
| `Unconfirmed in this session` | 1 |
| `Not available here` | 1 |
| `Shell output was not returned in this session` | 1 |

这些命中证明“退出状态不可得、测试未确认、SHA 不可得”有 Runtime 原始事件支撑，不只是会话摘要或报告作者的推断。

## Git 证据

- 目标 commit：`609571ddb22d1fbb2bfb5e54692c07beeef4cf23`
- `commit-609571.patch` 已通过 `git apply --numstat` 解析。
- 补丁包含 12 个文件，覆盖 shell 活动缓冲/投影测试与 runtime observation/Panel bridge 相关文件。
- `commit-609571-manifest.txt` 保存 commit 元数据、name-status、numstat 与 stat。

## 术语和边界复核

- 出版报告采用“角色分离 QA 验证”，不宣称外部第三方独立验证。
- 结论采用“治理控制结果成功，但工具通道与退出状态可观察性仍构成独立工程缺口”。
- 原始 QA 回执中的历史措辞保持不变，并在 README 中注明。
- EVAL 仅作观察参考，不作为 lifecycle 的自动裁决器。
- Product Brief 计划日期与实际执行日期的差异已在 `schedule-lifecycle-note.md` 中披露；未发现或收录独立改期批准文件。
- 快照终点的 TASK-019/020 均为 `review / pending`，因此报告没有宣称 PM 最终批准或终态关闭。
- DEV/QA 回执的 `runtime_bound: False` 已保留并明确解释为“非 Runtime 认证证据”。
- 同包未签名 SHA-256 仅用于包内一致性校验；PM 截图仅作为恢复后保存的历史消息画面。
