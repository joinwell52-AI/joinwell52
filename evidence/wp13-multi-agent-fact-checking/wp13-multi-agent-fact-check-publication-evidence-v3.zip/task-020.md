---
protocol: fcop
version: 1
sender: PM
recipient: QA
task_id: TASK-20260805-020
priority: P1
thread_key: submission-submission-20260804-001
parent: TASK-20260804-001
references: "['TASK-20260804-001', 'TASK-20260805-019']"
depends_on: "['TASK-20260805-019']"
state: review
created_at: 2026-08-05T13:09:31+08:00
writer: codeflowmu-one-shot-fallback
lifecycle_path: fcop/_lifecycle/review
transitions:
  - at: 2026-08-05T13:09:40+08:00
    from: inbox
    to: active
    by: CodeFlowMu
    action: runtime_dispatch
  - at: 2026-08-05T13:11:31+08:00
    from: active
    to: review
    by: QA
    action: submit_review
    report: REPORT-20260805-038-QA-to-PM
dispatch_attempt_id: attempt-b15545c1-0365-4187-b3d2-81f2515849b6
execution_lease_id: lease-c6a9fda1-1060-4495-a2d0-35d34915c5a1
dispatch_agent_id: QA-01
display_status: waiting_pm_review
pm_attention_reason: 事实核查需人工裁定：正式验收合同不完整或证据存在多种合理解释，需要 PM 裁决；acceptance criteria exist but required_evidence_types/validator are not explicit；建议：acceptance criteria exist but required_evidence_types/validator are not explicit
pm_attention_report_id: REPORT-20260805-038-QA-to-PM
lifecycle_projection: review
review_status: pending
submitted_at: 2026-08-05T05:11:31.382Z
---

# QA验收 WP-13 观察和兼容

# QA验收 WP-13 观察和兼容

## 背景
parent=`TASK-20260804-001`。验收 Brief **WP-13**。DEV `TASK-20260805-019` / `REPORT-20260805-037` status=done。

ADMIN 闸门：核验 DEV 回执 → 正式派本 QA → **PASS 后**收口 WP-13 再派 WP-14；禁止跳过 QA；禁止启用生产 Active。

## 验收重点
1. 旧观察面保留（Panel/REST/SSE）；ActivityBuffer ≠ 投递队列
2. Host/Binding/Run/Delivery/instance_id/runtime role/roots/writer lock/Gateway/隔离告警字段可读
3. ProjectGraph 业务五态；lifecycle 桶名 ≠ 业务通过态；等待 ADMIN 可指向真实 Gate
4. Desktop 与 PWA 同树同序（同输入同序）
5. 未 Active；未改真投递；单测全绿 + typecheck 0；独立 commit

## DEV 证据
- REPORT：`REPORT-20260805-037-DEV-to-PM.md`
- commit：`609571ddb22d1fbb2bfb5e54692c07beeef4cf23`
- 单测：observation 3/3 + activity/project-graph 10/10 + 回归 14/14；typecheck 0

## 隔离证据目录
`workspace/core-refactor-plan/qa-evidence/TASK-20260805-020/`

## 回执
`REPORT-*-QA-to-PM.md` · PASS→done；失败→blocked/FAIL

## 验收与依赖
- 验收人：PM
- depends_on：TASK-20260805-019

---

## state_history (auto-appended by runtime)

- **2026-08-05T13:09:41+08:00** | by `runtime` | `inbox` → `dispatched` session_id=session-e-msfmo0ye
- **2026-08-05T13:09:41+08:00** | by `runtime` | `dispatched` → `running` session_id=session-e-msfmo0ye
- **2026-08-05T13:11:38+08:00** | by `runtime` | `dispatched` → `ended` status=completed
