---
protocol: fcop
version: 1.0
source_task_id: TASK-20260805-019
task_id: TASK-20260805-019
sender: DEV
reporter: DEV
recipient: PM
status: done
revision: 1
rework_round: 0
submission_attempt: 1
content_hash: 2db1d05ee5d181d19d3c25e4334d06ec9f54f77aa7521b17fb8a2aa4cce31aa8
created_at: "2026-08-05T13:08:37+08:00"
writer: codeflowmu-validated-lifecycle-writer
runtime_bound: False
source: external_fcop_one_shot
thread_key: submission-submission-20260804-001
references: "['TASK-20260805-019']"
---

## 结论

done — WP-13 观察与兼容已落地：`ActivityBuffer` 取代同名混淆的活动环缓冲（`DoorbellBuffer` 兼容别名保留）；补充 Host/Binding/Run/Delivery 等可读观察快照与 switchboard 事件目录；统一 ProjectGraph 业务五态（待执行/进行中/等待QA/等待ADMIN/完成），lifecycle 桶名不得冒充业务态；Desktop/PWA 同输入同序。**未**启用生产 Active；**未**改真投递路径。

## 详情

### 产出路径

| 模块 | 路径 |
|---|---|
| ActivityBuffer | `codeflowmu-shell/src/activity-buffer.ts` |
| DoorbellBuffer shim | `codeflowmu-shell/src/doorbell-buffer.ts`（兼容 re-export） |
| Observation 快照/映射 | `packages/codeflowmu-runtime/src/switchboard/observation/**` |
| Panel 事件目录增量 | `packages/codeflowmu-runtime/src/panel/PanelEventBridge.ts` |
| ProjectGraph 业务五态 | `codeflowmu-shell/src/project-graph-projection.ts` |

### 字段表（观察快照 API 样例）

| field | 含义 | source |
|---|---|---|
| instance_id | Runtime 实例标识 | snapshot.instanceId |
| runtime_role | 运行角色 | snapshot.runtimeRole |
| registry_root / data_root / fcop_root | 根路径 | snapshot.* |
| writer_lock | 写锁 | snapshot.writerLock |
| gateway.status | Gateway | snapshot.gateway |
| isolation_alerts | 隔离告警 | snapshot.isolationAlerts |
| workers[].host_id | 当前 Host | WorkerBinding |
| workers[].binding_id | Binding | WorkerBinding |
| workers[].host_session_ok | Session 是否正常 | binding.state===ready |
| workers[].continuity_mode | 同 Session / 文件接手 | RunRecord |
| workers[].pending_doorbells | pending 数 | DoorbellMailbox |
| workers[].failed_doorbells | failed 数 | DoorbellMailbox |
| workers[].delivery_unknown_runs | delivery_unknown | RunStore |
| production_active_enabled | 恒 false | 硬约束 |

业务五态：`todo/doing/waiting_qa/waiting_admin/done` → 中文「待执行/进行中/等待QA/等待ADMIN/完成」。`waiting_admin` 在有 Gate/approval 时携带 `waiting_admin_target.{gate_id,approval_id}`。

API 样例外形：`ObservationSnapshot` schema=`codeflowmu.observation-snapshot/v1`；旧 `/api/v2/doorbell/*` REST **保留**（读的是 ActivityBuffer，不是投递 Mailbox）。

### 验证

| 检查 | 结果 |
|---|---|
| observation.test.ts | **3/3 PASS** |
| activity-buffer + project-graph tests | **10/10 PASS**（含 WP-13 三项 + 原有） |
| root-fault / log-center 回归 | **14/14 PASS**（shim 兼容） |
| `npm run typecheck`（runtime） | exit 0 |
| 生产 Active | **未启用** |

### Commit

- SHA：`609571ddb22d1fbb2bfb5e54692c07beeef4cf23`
- message：`refactor(core): WP-13 preserve panel activity and enrich evidence`
- 分支：`codex/work-inheritance-core-dev`（**未 push**）

## 影响范围

- shell：ActivityBuffer 重命名 + ProjectGraph 业务态标注
- runtime：observation 模块 + PanelEventBridge 事件目录增量
- 旧 Panel/REST/SSE 路径保留；ActivityBuffer ≠ 投递队列

## 跳过检查

- 未做全量 Playwright/浏览器截图（无运行中 Panel；以单测 + 字段表/API 样例为证据）
- 未接线生产 Active / TaskDispatcher 真投递
