# 证据来源与生成说明

## 原始来源

| 包内文件 | 原始来源 |
|---|---|
| `task-019.md` | `D:\codeflowmu-core-dev\fcop\_lifecycle\review\TASK-20260805-019-PM-to-DEV.md` |
| `task-020.md` | `D:\codeflowmu-core-dev\fcop\_lifecycle\review\TASK-20260805-020-PM-to-QA.md` |
| `product-brief.md` | `D:\codeflowmu-core-dev\fcop\internal\product-briefs\PRODUCT-BRIEF-TASK-20260804-001.md` |
| `dev-report-037.md` | 本案例目录保存的 `source-REPORT-20260805-037-DEV-to-PM.md` |
| `qa-report-038.md` | 本案例目录保存的 `source-REPORT-20260805-038-QA-to-PM.md` |
| `session-transcript.txt` | 本案例目录保存的 `source-session-transcript.txt` |
| `qa-evidence/*.json` | `D:\codeflowmu-core-dev\workspace\core-refactor-plan\qa-evidence\TASK-20260805-020\` |
| `pm-fact-check.png` | 本案例目录在工具恢复后保存的 PM 历史消息截图；不是故障时刻的同步文件系统快照 |
| `business-overview.png` | 本案例报告的业务流程图 |

## Runtime 原始事件抽取

源文件：`D:\codeflowmu-core-dev\fcop\logs\runtime\runtime-events-20260805.jsonl`。

- `runtime-events-wp13-excerpt.jsonl`：逐行保留源 JSONL 中命中以下任一标识符的完整原始行：`session-9-msfmayqe`、`TASK-20260805-019`、`TASK-20260805-020`、`REPORT-20260805-037`、`REPORT-20260805-038`、完整 commit SHA。
- `subexecution-task-completed-raw.jsonl`：从同一源文件精确选取 `session_id=session-9-msfmayqe`、工具名为 `task`、状态为 `completed` 的完整原始事件行。
- `subexecution-result-readable.json`：读取上述原始事件的 `payload.raw.result.value` 后进行 JSON 格式化，仅为阅读辅助件。

原始 JSONL 行未经语义改写。若阅读辅助件与原始事件存在差异，以 `subexecution-task-completed-raw.jsonl` 为准。

## Git 证据生成

目标 commit：`609571ddb22d1fbb2bfb5e54692c07beeef4cf23`。

- `commit-609571.patch`：由目标仓库对该 commit 执行单提交 `git format-patch` 生成。
- `commit-609571-manifest.txt`：由 `git show` 导出 commit 元数据、name-status、numstat 与 stat。

## 完整性与编码

- `checksums.sha256` 在最终打包前对包内其余文件重新计算。
- 校验清单与被校验文件同处一个未签名 ZIP，只能检出包内文件是否发生变化，不能独立证明发布者身份、来源真实性或可信时间戳。
- ZIP 条目名称只使用 ASCII；文本内容使用 UTF-8，从而避免 Linux 解压中文文件名乱码。
- 原始 TASK/REPORT/Brief、Runtime JSONL、QA JSON 和 commit patch 均按证据原貌保存；历史源文件里的旧术语不做追溯改写，语义纠正写在 `report.md` 与 `README.md`。
- 本出版包不修改 FCoP lifecycle、TASK、REPORT、ISSUE 或 REVIEW，仅复制和整理既有证据。
- `dev-report-037.md` 与 `qa-report-038.md` 的 `runtime_bound: False` 保持原貌；二者不作为 Runtime 认证证据。
