---
task_id: TASK-20260804-001
root_task_id: TASK-20260804-001
thread_key: submission-submission-20260804-001
planning_level: 3
pm: PM-01
status: ready_for_review
artifact_status: ready_for_review
validation_status: passed
planning_gate_status: not_submitted
dispatch_scope: closed
revision: 1
created_at: 2026-08-04T05:30:08.347Z
updated_at: 2026-08-04T05:30:08.347Z
session_id: session-3-mse7hwp5
body_digest: sha256:a3332ea12647156d0bbc4fba2ca44684654f5c2f25cd4f343ea1d055b1483f30
operation_digest: sha256:3f7d27f01dead3488ef4c585eca841454c768279f767671011d10782e417e484
previous_digest: null
source_digest: sha256:dd45f8f0246d951ca00e710d4b6c41cfd5a96059b1440072cb917ee7f36946d0
validation_digest: sha256:f8a38fd6a69740496f3e68ca3eb2f017d0fdf163f701aadc912b2fb56f07d0c6
planning_method: long_horizon
source: pm.write_planning_artifact
---

# Product Brief · CodeFlowMu Core 工作继承底座改造（TASK-20260804-001 · r1 · 待 Planning Gate）

> 主任务：`TASK-20260804-001` · thread：`submission-submission-20260804-001` · Level 3
> 同一路径：`fcop/internal/product-briefs/PRODUCT-BRIEF-TASK-20260804-001.md`（禁止另建 Brief）
> **自包含声明**：本文完整承载规划正文；不依赖任何已被覆盖的历史 revision 正文，不引用「见本 Brief 正文」类外链
> 状态：ready_for_review · 新主任务执行线；历史 TASK-20260803-001 / TASK-20260731-001 仅作证据索引，不继承完成态；待 ADMIN Planning Gate 批准后方可派 WP-00
> **时区**：Asia/Shanghai
> **T0（M0 锚点）**: `2026-08-04T13:28:47+08:00` Asia/Shanghai; D1=2026-08-04 .. D10=2026-08-13; ADMIN wait excluded from AI days
> **AI 日口径**：仅计有效开发/测试执行时间；**ADMIN 等待（Planning / Gate B / Gate C / 整机重启等）不计 AI 日**
> 日历（规划假设；以批准时刻重标定）：若 2026-08-04 批准则 **D1=2026-08-04** … **D10=2026-08-13**codex/work-icodex/work-inheritance-core-dev`

## 产品目标

在不改变 ADMIN/PM/DEV/QA/OPS/EVAL 既有使用方式、FCoP 文件流、Panel/PWA 主路径、Cursor Agent 能力、开源构建启动方式与旧 TASK/REPORT 兼容性的前提下，将内部执行路径从 `TaskDispatcher → SessionManager → 全局 AgentSdkAdapter → Cursor` 迁移为 `TaskDispatcher → Doorbell → HostSwitchboard → Worker Binding → CursorHostAdapter → Host Session → Run → Cursor`。

成功一句话：用户继续原样使用 CodeFlowMu 与 Cursor；内部已由可恢复、可插拔、可 Shadow→Active 的文件原生 Host Switchboard 底座运行；`D:\codeflowmu` / `D:\codeflowmu-core-dev` / `D:\codeflowmu-core-candidate` 无任务、Agent、Session、Gateway、写锁冲突。

## 目标用户

| 角色 | 诉求 |
|---|---|
| ADMIN | 投递长期任务；审批 Planning / 条件 Gate B / Gate C；必要时整机重启 |
| PM | 规划、分 WP 派单、Gate 汇总、进度与恢复可读 |
| DEV | 在 core-dev 按 WP 实现，每 WP 独立 commit |
| QA | 独立核验契约、隔离、无双投递、恢复与业务/lifecycle 语义分离 |
| OPS | candidate 干净部署、18768 冒烟、锁与隔离 |
| EVAL | 观察实验指标，不阻断主线 |

## 问题与价值

### 代码基线事实

| 模块 | 磁盘事实 | 产品阻碍 |
|---|---|---|
| `packages/codeflowmu-runtime/src/registry/AgentSdkAdapter.ts` | 同文件承载 AgentSdkAdapter + CursorSdkAdapter + InMemory | Host 契约与 Cursor 实现未分离 |
| `codeflowmu-shell/src/sdk-factory.ts` | Cursor 中心工厂 | Host 插入点被占 |
| `packages/codeflowmu-runtime/src/registry/AgentRegistry.ts` | `register()` 直接 SDK.create | Worker 登记 ≠ Host Session 生命周期 |
| `packages/codeflowmu-runtime/src/session/SessionManager.ts` | 经 Adapter 直接 send | Session 与单次 Run 未分离 |
| `packages/codeflowmu-runtime/src/scheduler/TaskDispatcher.ts` | 直接 wake/session | 投递未经过 Switchboard |
| `packages/codeflowmu-runtime/src/types/state.ts` | `RuntimeBindingMode = local\|cloud` | 不是 WorkerBindingRevision 语义 |
| `codeflowmu-shell/src/doorbell-buffer.ts` | Panel 事件环缓冲 | 禁止当作 per-Worker 投递 Mailbox |
| `D:\codeflowmu-core-candidate` | 当前目录不干净（含历史 .codeflowmu/.git/fcop 等） | 进入 18768 前必须按白名单从固定 SHA **完整重建**部署目录并验证**独立配置**（instance/data/registry/lock/Gateway=false） |

价值：可插拔多 Host 登记；Worker 独立于 Host；Session 可 warm/cold 继承；至少一次投递 + `delivery_unknown` 不盲重发；off/shadow/active；旧 Runtime 事件与 Panel 实时流兼容；自举隔离可验证。

## 功能范围

Host 契约与文件 Store；Registry/兼容 Adapter；CursorHostAdapter 收口（本轮唯一正式 Host）；Shadow 与（条件批准后）Active；Admission/Doorbell/HostSwitchboard；Session/Run 分离；Worker 与 Binding 分离；hot/warm/cold 继承；观察字段与 ProjectGraph；三目录隔离与 Gate 证据；研究 JSONL（只追加）。

## 明确不做什么

不开发 Agent OS；不改 FCoP 核心规范；不加中心 DB/消息 Broker；Doorbell 非 RPC；不把角色流程硬编码进通用 Core；不正式接入 Codex/Claude/Copilot/Google Host；不重做 Panel；不删旧 API；不迁移/重写旧 TASK/REPORT；不做 WP-15；不 远端推送/PR/标签/发布；不把 doorbell-buffer 当投递队列；不写稳定副本未验收代码；**不使用本地 git 本地标签 作为基线/Gate 标记**。

## 信息架构

| 节点 | 语义 |
|---|---|
| ROOT TASK | `TASK-20260804-001`，parent 空 |
| 枝干 | 仅正式 `parent`；thread_key/references 不形成父子 |
| WP/Gate 分组 | 组织节点，不是 TASK parent |
| 叶子 | REPORT / ISSUE / REVIEW / Approval / Runtime Event |
| 业务看板 | 待执行 / 进行中 / 等待QA / 等待ADMIN / 完成 |
| lifecycle 桶 | 仅详情与物理态，不等于业务通过 |

Desktop 与 PWA 必须读同一 Ledger/ProjectGraph。

## 用户流程

ADMIN 投递 → PM Brief+M0 → Planning Gate → 分批 WP（DEV→QA±OPS）→ Gate A 自动 →（条件 Gate B）→ Active 核心 → Gate C。恢复只认磁盘事实。

## 交互规则

Planning 批准前禁止派 DEV/QA/OPS；Shadow 禁止向 Cursor 二次真投递；外部投递唯一入口经 Doorbell→Switchboard；`delivery_unknown` 不得盲重发高风险工作；「等待 ADMIN」必须可追踪审批对象；业务状态 ≠ `_lifecycle` 桶名。

## 视觉与响应式

不重做视觉语言；运营密集可读优先；补充观察字段不得错义；Desktop=PWA；禁止营销式改版。

## 技术候选方案比较

| 选项 | 结论 |
|---|---|
| 加深全局 Adapter | 否 |
| 引入 DB/Broker | 否 |
| 复用 doorbell-buffer 当队列 | 否 |
| Host Switchboard + 文件 Store + Cursor 收口 + Legacy wrap | **选用** |
| 本轮齐上多 Host | 否 |

迁移节奏：off → shadow → active（Active 须 Gate B 或等价授权命中后）。

## 数据方案

| 数据 | 权威位置 |
|---|---|
| 正式账本 | `D:\codeflowmu-core-dev\fcop\` |
| Store | 项目内文件原子写（Mailbox/Binding/Run/Claim） |
| 恢复产物 | `docs/core-refactor-runtime/`（或任务书指定等价路径） |
| 实验 | `research-evidence/` JSONL 只追加 |
| 18766 程序根 | `D:\codeflowmu` |
| 18768 | 仅 `D:\codeflowmu-core-candidate` 干净快照 |

## 测试数据

基线包；Shadow 对齐包；隔离矩阵；恢复重复实验；整机重启×1（须 ADMIN）；Gate C 全量 + 18 E2E。完整实验数据方案见 **§5.4**。

## QA验收方法

QA 独立重跑，不复用 DEV 口头结论；契约层无 Cursor 专有字段泄漏；无双投递；CLEAN-INIT-MANIFEST↔磁盘；「等待 ADMIN」可指向具体 Gate；lifecycle 桶名不得当作业务通过。

## 风险与依赖

见 §6 风险登记表。依赖：外部三份基线文档绝对路径可读；18766 在线且 Current Project=core-dev；candidate 重建能力。

## DEV/QA/OPS交付计划

见 §2 逐 WP 展开。**总预算 7～10 AI日**；本版点估合计 **7.00～8.05 AI日**。返工计入各 WP「最大返工次数」；若累计将突破 D10，则 D7 体检后向 ADMIN 申请平移日历，禁止用并行掩盖串行依赖。

## 验收标准

- [ ] 用户行为与旧文件/Panel 主路径兼容
- [ ] Cursor 经新底座（Active 经批准）
- [ ] Host 契约无 Cursor 专有污染；Worker/Host/Session/Run 边界可测
- [ ] 文件可恢复；cold 不靠隐藏思考
- [ ] 隔离与无双投递证据齐；candidate 干净可部署
- [ ] Gate A/B/C 证据完整；无未授权远程发布
- [ ] 实验包可离线检查

---

## 1. 总体规划

| 项 | 事实 |
|---|---|
| 18766 | **在线**；host=`D:\codeflowmu`；project=`D:\codeflowmu-core-dev`；**Gateway 已启用并在线** |
| 分支 | `codex/work-icodex/work-icodex/work-inheritance-core-dev` @ `d6b98b27…` |
| 18768 | 默认关；仅 candidate 按固定源 SHA 重建并验证独立配置后冒烟；**Gateway 必须 = false** |
| candidate | Git 基线干净；启动前仍须按固定来源 SHA **重建**并验证独立 instance/data/registry/lock/Gateway=false |
| T0 | `2026-08-04T13:28:47+08:00` Asia/Shanghai |
| r6 content | 2026-08-03 |
| Planning Gate | **历史 r6 曾批准 WP-00（旧线）** |
| approve T0 | 待 ADMIN 批准 |
| 预算校对 | 逐 WP 合计 7.00～8.05 ⊆ 7～10；ADMIN 等待不计 AI 日 |

模式：off → shadow → active。**D7（2026-08-10）健康检查**（见 §4.5）。**D10 最终处置**（见 §4.6）。延期重排规则见 §4.7。

### 1.1 相对前版的保留与修复

| 项 | 处置 |
|---|---|
| r5 完整 WP/Gate/风险/恢复正文 | **全部保留** |
| r4 预算 7.00～8.05、D1～D10 串行、仅 commit SHA | **保留** |
| 拓扑：18766 Gateway | **更正为已启用并在线**；仅 18768 强制 Gateway=false |
| candidate | Git 干净仍须按源 SHA 重建+独立配置校验 |
| T0/时区/ADMIN 等待不计 AI 日/D7/D10/延期规则 | **本 r6 补齐** |
| 实验数据方案 / 恢复保全 / 立即停步清单 | **本 r6 补齐** |
| 本地 tag / 未经保全直接 checkout | **禁止** |

## 2. WP任务树（逐项展开 · 自包含）

所有正式子任务默认 `parent=TASK-20260804-001`（修复挂缺陷 DEV；回归挂修复）。Planning 批准前**不创建**。

### 2.1 并行与串行

| 规则 | 范围 | 原因 |
|---|---|---|
| 必须串行 | 00→01→02→03→GateA→04→05→06→(B?)→07→08→09→10→11→12→13→14→GateC | 代码与语义依赖链 |
| 必须串行 | 每个 WP 内 DEV → QA | QA depends_on DEV done REPORT |
| 可并行 | WP-00 内 DEV 采基线 ∥ OPS **只读**确认未写稳定副本 | OPS 零写、不占 DEV 关键路径 |
| 可并行 | EVAL 观察 ∥ 主链 | 不阻断 |
| 禁止 | 同日并行开工缩短串行链；Active∥Shadow 真 send；双 Runtime 同 FCoP 根 | 掩盖依赖 / 双投递 / 锁冲突 |
| 同日串行 | D8：07→08；D9：09→10→11；D10：12→13→14 | 半日先后，当日合计约 ≤1.0 AI日 |

### 2.2 预算汇总表

| WP | AI日（低～高） | 独占/衔接槽位 |
|---|---|---|
| WP-00 | 0.75～0.85 AI日 | D1 全日（2026-08-04） |
| WP-01 | 0.55～0.65 AI日 | D2 全日（2026-08-05） |
| WP-02 | 0.75～0.85 AI日 | D3 全日（2026-08-06） |
| WP-03 | 0.50～0.55 AI日 | D4 上午→完成后当日提交 Gate A（2026-08-07） |
| WP-04 | 0.65～0.75 AI日 | D5 全日独占（2026-08-08）——不与 WP-05 重叠 |
| WP-05 | 0.45～0.50 AI日 | D6 全日独占（2026-08-09）——待 WP-04 完成后开始 |
| WP-06 | 0.75～0.85 AI日 | D7 全日（2026-08-10）；同日末健康检查；若命中 trigger 则提交 Gate B |
| WP-07 | 0.30～0.40 AI日 | D8 上午（2026-08-11）——完成后才开始 WP-08 |
| WP-08 | 0.55～0.60 AI日 | D8 下午（2026-08-11）——严格接在 WP-07 之后；D8 合计 0.85～1.00 |
| WP-09 | 0.30～0.35 AI日 | D9 上午（2026-08-12） |
| WP-10 | 0.25～0.30 AI日 | D9 中段（2026-08-12）——接 WP-09 后 |
| WP-11 | 0.35～0.40 AI日 | D9 下午（2026-08-12）——接 WP-10 后；D9 合计 0.90～1.05（按 ≤1.05 管控，超额顺延、禁止并行） |
| WP-12 | 0.20～0.25 AI日 | D10 上午前段（2026-08-13） |
| WP-13 | 0.20～0.25 AI日 | D10 上午后段（2026-08-13）——接 WP-12 后 |
| WP-14 | 0.45～0.50 AI日 | D10 下午（2026-08-13）——接 WP-13 后提交 Gate C |
| **合计** | **7.00～8.05** | 必须 ⊆ 7～10 |

### 2.3 逐 WP 详表

#### WP-00 · 保存基线

- **recipient（主执行）**：DEV；协作 OPS
- **验收角色**：PM 审 + QA 核验可重复；OPS 确认未改 D:\codeflowmu
- **parent**：`TASK-20260804-001`
- **前置依赖**：Planning Gate 批准
- **排期槽位**：D1 全日（2026-08-04）
- **预计 AI 有效时间**：0.75～0.85 AI日
- **Token/调用预算**：约 50～65 万 token / ≤30 次工具调用
- **最大返工次数**：2
- **计划起止日期**：2026-08-04 → 2026-08-04（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：当前 HEAD、工作树、必读三文档绝对路径、18766 状态、协议/runtime/shell 测试入口、开源校验脚本
- **输出**：基线包：HEAD SHA、工作树快照说明、测试+typecheck+开源校验结果、真实四角色链路样本（Agent/Session/Run/TASK/REPORT/Panel/日志）、已知失败清单、回滚点固定 commit SHA（写入 REPORT，不打本地 tag）
- **测试要求**：既有 suite 全绿或基线记录失败；typecheck；开源校验；禁止改稳定副本 D:\codeflowmu；Core Dev 无无关改动
- **REPORT/证据内容**：基线 SHA、命令与退出码、链路 ID 表、失败登记、回滚点 commit SHA、未修无关问题声明
- **失败处置**：证据不全→DEV 补采；误改稳定副本→立即回滚并 ISSUE
- **回滚路径**：先按 §7 完成未提交工作/账本/实验数据**保全**，再 `git checkout <BASELINE-SHA>`；禁止未保全直接 checkout；重跑基线命令

#### WP-01 · 平台无关契约

- **recipient（主执行）**：DEV
- **验收角色**：QA；PM 确认未改生产路径
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-00 done
- **排期槽位**：D2 全日（2026-08-05）
- **预计 AI 有效时间**：0.55～0.65 AI日
- **Token/调用预算**：约 40～55 万 token / ≤30 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-05 → 2026-08-05（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-00 基线；任务书契约清单；AgentSdkAdapter.ts 现状
- **输出**：HostCapabilities、HostDescriptor、HostSessionRef、HostFailure、HostEventEnvelope、HostRun、WorkerBindingRevision、DoorbellMessage、RunRecord、ContextProjection、AgentHostAdapter；通用契约无 Cursor 专有字段；旧 Adapter 兼容；生产路径不变
- **测试要求**：契约单测；静态扫描无 Cursor 字段；既有生产路径冒烟对照基线
- **REPORT/证据内容**：新增类型/文件清单、无 Cursor 字段证据、兼容证明、commit SHA
- **失败处置**：出现 Cursor 字段→必修；破坏兼容→回滚本 WP commit
- **回滚路径**：revert WP-01 commit；保留基线 SHA

#### WP-02 · 文件原生状态层

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-01 done
- **排期槽位**：D3 全日（2026-08-06）
- **预计 AI 有效时间**：0.75～0.85 AI日
- **Token/调用预算**：约 50～70 万 token / ≤35 次
- **最大返工次数**：3
- **计划起止日期**：2026-08-06 → 2026-08-06（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-01 契约；AtomicFile 需求
- **输出**：AtomicFile、WorkerBindingStore、DoorbellMailbox、RunStore、HostClaimStore、SwitchboardVersionStore；原子写、去重、崩溃恢复；每 Worker 独立 Mailbox；可读 JSON/Markdown 状态
- **测试要求**：原子写/崩溃恢复单测；禁止 DB/Broker/全局 queue.json 作为真相；多 Worker Mailbox 隔离测
- **REPORT/证据内容**：Store API、测试矩阵、崩溃注入结果、commit SHA
- **失败处置**：半写入/丢数据→返工；引入 DB→拒绝合并并回滚
- **回滚路径**：revert WP-02；清理实验 Store 目录

#### WP-03 · Host Registry和兼容Adapter

- **recipient（主执行）**：DEV
- **验收角色**：QA；随后 PM 做 Gate A 自动判定
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-02 done
- **排期槽位**：D4 上午→完成后当日提交 Gate A（2026-08-07）
- **预计 AI 有效时间**：0.50～0.55 AI日
- **Token/调用预算**：约 35～50 万 token / ≤28 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-07 → 2026-08-07（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-01/02；旧 AgentSdkAdapter
- **输出**：AgentHostRegistry、LegacySdkHostAdapter、InMemoryHostAdapter、能力声明、多 Host 登记能力、旧 Adapter 兼容包装
- **测试要求**：多 Host 登记单测；Legacy 包装行为对照；typecheck；git diff --check
- **REPORT/证据内容**：Registry API、兼容矩阵、commit SHA、Gate A 预检清单
- **失败处置**：兼容破→返工；缺证据→不进 Gate A
- **回滚路径**：revert WP-03；保持 off

#### WP-04 · Cursor专有逻辑收口

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：Gate A pass
- **排期槽位**：D5 全日独占（2026-08-08）——不与 WP-05 重叠
- **预计 AI 有效时间**：0.65～0.75 AI日
- **Token/调用预算**：约 45～65 万 token / ≤32 次
- **最大返工次数**：3
- **计划起止日期**：2026-08-08 → 2026-08-08（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：Gate A 证据包；现有 Cursor 适配代码
- **输出**：hosts/cursor/CursorHostAdapter.ts、CursorHostEventMapper.ts、CursorHostFailureClassifier.ts；先兼容包装再逐项迁移；旧导入保留；不同时修改通用契约
- **测试要求**：Cursor 行为对照基线；导入兼容；契约层仍无 Cursor 字段
- **REPORT/证据内容**：文件迁移图、行为对照表、commit SHA
- **失败处置**：行为回归→返工；契约污染→回滚并修边界
- **回滚路径**：revert WP-04；走 Legacy 包装

#### WP-05 · Shadow Worker Binding

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-04 done
- **排期槽位**：D6 全日独占（2026-08-09）——待 WP-04 完成后开始
- **预计 AI 有效时间**：0.45～0.50 AI日
- **Token/调用预算**：约 30～45 万 token / ≤22 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-09 → 2026-08-09（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-04；WorkerBinding 契约
- **输出**：WorkerIdentityService、WorkerBindingService、Agent→Worker 映射、Shadow Binding 文件、允许 unbound、登记与开 Session 分离；真实执行路径不变
- **测试要求**：Binding 文件可读；unbound；Shadow 不产生真实二次 send
- **REPORT/证据内容**：Binding 样例、分离证据、commit SHA
- **失败处置**：误改真实路径→立即回滚 off
- **回滚路径**：回滚 Shadow Binding 相关 commit；切 off

#### WP-06 · Shadow Doorbell/Run/Event

- **recipient（主执行）**：DEV；协作 OPS
- **验收角色**：QA + OPS；PM 判定是否命中 Gate B trigger
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-05 done
- **排期槽位**：D7 全日（2026-08-10）；同日末健康检查；若命中 trigger 则提交 Gate B
- **预计 AI 有效时间**：0.75～0.85 AI日
- **Token/调用预算**：约 55～75 万 token / ≤40 次
- **最大返工次数**：3
- **计划起止日期**：2026-08-10 → 2026-08-10（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-05；旧执行路径；candidate 重建需求
- **输出**：Shadow 记录 Doorbell/Run/Session/Event/deliveryAttemptId/Evidence；证明无二次 send；Doorbell 数=真实派发数；对齐；Runtime 重启不坏；off 可回滚；OPS：按固定源 SHA 重建 candidate、验证独立配置与 Gateway=false 后 18768 冒烟（不触发 Active）
- **测试要求**：无双投递；对齐矩阵；Runtime 重启；18766/18768 隔离矩阵；**18766 Gateway 保持在线启用**；**18768 Gateway=false**；Writer Lock；candidate 独立配置校验
- **REPORT/证据内容**：对齐表、隔离证据、candidate 源 commit SHA、本 WP commit SHA、Gate B 预检（若触发）
- **失败处置**：双投递→紧急 stop+回滚；隔离失败→禁止继续 18768
- **回滚路径**：切 off；停 18768；保留证据

#### WP-07 · Admission Policy

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-06 done；若 Gate B 已触发则须 ADMIN approve_active
- **排期槽位**：D8 上午（2026-08-11）——完成后才开始 WP-08
- **预计 AI 有效时间**：0.30～0.40 AI日
- **Token/调用预算**：约 25～40 万 token / ≤18 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-11 → 2026-08-11（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：旧 gate；开发团队投递条件
- **输出**：WorkAdmissionPolicy、LegacyOpenDevTeamAdmissionPolicy、新旧对照测试
- **测试要求**：policy 单测；旧 gate 对照
- **REPORT/证据内容**：policy 清单、对照结果、commit SHA
- **失败处置**：误拦/误放→返工
- **回滚路径**：revert WP-07；恢复旧 gate 路径

#### WP-08 · HostSwitchboard正式接管

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-07 done
- **排期槽位**：D8 下午（2026-08-11）——严格接在 WP-07 之后；D8 合计 0.85～1.00
- **预计 AI 有效时间**：0.55～0.60 AI日
- **Token/调用预算**：约 45～60 万 token / ≤35 次
- **最大返工次数**：3
- **计划起止日期**：2026-08-11 → 2026-08-11（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：Registry/Binding/Mailbox；TaskDispatcher
- **输出**：正式 Doorbell 唯一生成入口；TaskDispatcher 不再直接启动平台 Session；HostSwitchboard 按 Binding 选 Host；Run/事件经兼容桥回传；处理 delivery_unknown；高风险不盲重发；emergency stop；绝不双投递
- **测试要求**：双投递对抗；delivery_unknown 语义；emergency stop；单角色 E2E 冒烟
- **REPORT/证据内容**：架构切换证据、对抗测试结果、commit SHA
- **失败处置**：双投递→紧急回滚 Shadow/off
- **回滚路径**：切回旧 Dispatcher 路径或 Shadow

#### WP-09 · Host Session与Run分离

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-08 done
- **排期槽位**：D9 上午（2026-08-12）
- **预计 AI 有效时间**：0.30～0.35 AI日
- **Token/调用预算**：约 25～35 万 token / ≤18 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-12 → 2026-08-12（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-08；旧 SessionRecord
- **输出**：一个 Host Session 可承载多个 Run；Run 有独立状态与证据；旧 SessionRecord 兼容；占用标记与 claim 有效
- **测试要求**：多 Run；claim 不互抢；兼容读写
- **REPORT/证据内容**：模型图、测试结果、commit SHA
- **失败处置**：claim 竞态→返工
- **回滚路径**：revert WP-09

#### WP-10 · Worker登记与Host Binding分离

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-09 done
- **排期槽位**：D9 中段（2026-08-12）——接 WP-09 后
- **预计 AI 有效时间**：0.25～0.30 AI日
- **Token/调用预算**：约 20～30 万 token / ≤15 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-12 → 2026-08-12（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：WP-05/09 产物
- **输出**：Worker 先登记后绑定；Binding 可修订；保留旧 register() 兼容；平台身份 ≠ Worker 身份
- **测试要求**：登记/绑定/修订；兼容 register
- **REPORT/证据内容**：生命周期图、commit SHA
- **失败处置**：身份混淆→返工
- **回滚路径**：revert WP-10

#### WP-11 · 工作继承

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-10 done
- **排期槽位**：D9 下午（2026-08-12）——接 WP-10 后；D9 合计 0.90～1.05（按 ≤1.05 管控，超额顺延、禁止并行）
- **预计 AI 有效时间**：0.35～0.40 AI日
- **Token/调用预算**：约 30～45 万 token / ≤25 次
- **最大返工次数**：3
- **计划起止日期**：2026-08-12 → 2026-08-12（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：TASK/REPORT/Evidence 文件事实；Session 丢失场景
- **输出**：WorkFactReader、ContextProjectionBuilder、RecoveryPlanner；hot/warm/cold；接手材料只来自真实文件；不读取隐藏思考
- **测试要求**：三类恢复剧本；材料充分性断言
- **REPORT/证据内容**：恢复剧本结果、commit SHA
- **失败处置**：cold 不可接手→返工
- **回滚路径**：revert WP-11；沿用人工接手清单

#### WP-12 · Mailbox成为队列真相

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-11 done
- **排期槽位**：D10 上午前段（2026-08-13）
- **预计 AI 有效时间**：0.20～0.25 AI日
- **Token/调用预算**：约 20～30 万 token / ≤15 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-13 → 2026-08-13（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：DoorbellMailbox；旧 queue JSON
- **输出**：每 Worker 独立 Mailbox 为队列真相；旧 queue 变为兼容投影；旧 API 仍可读写；去重；FIFO；Worker 忙时排队；多 Worker 并行
- **测试要求**：FIFO/去重/并行；禁止把 doorbell-buffer 当投递队列
- **REPORT/证据内容**：队列语义测试、commit SHA
- **失败处置**：全局 queue 真相回潮→拒绝合并
- **回滚路径**：revert WP-12

#### WP-13 · 观察和兼容

- **recipient（主执行）**：DEV
- **验收角色**：QA
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-12 done
- **排期槽位**：D10 上午后段（2026-08-13）——接 WP-12 后
- **预计 AI 有效时间**：0.20～0.25 AI日
- **Token/调用预算**：约 20～30 万 token / ≤15 次
- **最大返工次数**：2
- **计划起止日期**：2026-08-13 → 2026-08-13（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：RuntimeEvent、Panel、PWA、Mobile、旧 REST、实时 SSE；ProjectGraph 需求
- **输出**：保持旧观察面；补充 Host/Binding/Run/Delivery/instance_id/runtime role/registry-data-fcop root/writer lock/Gateway/隔离告警；统一 ProjectGraph；业务五态；等待 ADMIN 可指向真实 Gate
- **测试要求**：Desktop 与 PWA 同树同序；lifecycle 桶名 ≠ 业务通过态；字段可读
- **REPORT/证据内容**：字段表、API 样例或截图路径、commit SHA
- **失败处置**：状态漂移→返工
- **回滚路径**：revert WP-13 观察增量

#### WP-14 · 恢复、迁移和完整回归

- **recipient（主执行）**：DEV；协作 OPS
- **验收角色**：QA + OPS；PM 汇总 Gate C
- **parent**：`TASK-20260804-001`
- **前置依赖**：WP-13 done
- **排期槽位**：D10 下午（2026-08-13）——接 WP-13 后提交 Gate C
- **预计 AI 有效时间**：0.45～0.50 AI日
- **Token/调用预算**：约 40～60 万 token / ≤35 次
- **最大返工次数**：3
- **计划起止日期**：2026-08-13 → 2026-08-13（同日多 WP 时按槽位先后，不得重叠开工）
- **输入**：全 WP 产物；候选封板需求
- **输出**：启动恢复、旧状态兼容、迁移工具、健康检查、诊断、真实 Cursor E2E、开源构建与启动、回滚演练、Session/进程/Shell/整机连续性验证、异常 parent 拒绝逻辑、候选发布清单（不执行远程发布）
- **测试要求**：全量回归；任务书 18 E2E；Session/进程/Shell/整机（整机须 ADMIN）；隔离；无双投递
- **REPORT/证据内容**：RC commit SHA、部署清单、已知问题、回滚手册、E2E 矩阵、Gate C 证据包
- **失败处置**：关键失败→返工指定 WP；禁止宣称完成
- **回滚路径**：回滚到上一 Gate 固定 commit SHA；保持 18766 稳定

## 3. 依赖矩阵

| 类型 | 规则 |
|---|---|
| 代码 | 见 §2.1 串行链；不得跳 Gate A 进 Shadow 真实验 |
| 角色 | DEV `status=done` REPORT 后 QA 才可执行（depends_on） |
| 环境 | 三目录绑定；18768 仅 candidate；禁止双 Runtime 写同一 FCoP 根 |
| 投递 | Active 真路径与 Shadow 真投递互斥 |
| 审批 | Planning / 命中的 Gate B / Gate C / 整机重启 → ADMIN |

## 4. 日程与 Gate（绝对日期 · 完整契约）

| 日 | 日期 | 内容（串行） | 当日 AI 预算（高） |
|---|---|---|---|
| Planning 再验 | 2026-08-03 | r6 Brief + 更新 M0；**ADMIN 等待（不计 AI 日）** | — |
| D1 | 2026-08-04 | WP-00 | 0.85 |
| D2 | 2026-08-05 | WP-01 | 0.65 |
| D3 | 2026-08-06 | WP-02 | 0.85 |
| D4 | 2026-08-07 | WP-03 → **Gate A 提交**（无 ADMIN 等待） | 0.55 |
| D5 | 2026-08-08 | WP-04（独占） | 0.75 |
| D6 | 2026-08-09 | WP-05（独占） | 0.50 |
| D7 | 2026-08-10 | WP-06；**D7 健康检查**；条件 **Gate B** | 0.85 |
| D8 | 2026-08-11 | 上午 WP-07 → 下午 WP-08 | 1.00 |
| D9 | 2026-08-12 | WP-09 → WP-10 → WP-11 | 1.05（超额顺延） |
| D10 | 2026-08-13 | WP-12 → WP-13 → WP-14 → **Gate C**；见 §4.6 最终处置 | 1.00 |

### 4.1 Planning Gate

| 项 | 内容 |
|---|---|
| 进入条件 | Product Brief `status=ready`；M0 `in_progress`；blocking 空 |
| 退出条件 | ADMIN 五选一：批准 WP-00 / 改规划 / 暂停 / 重规划 / 终止 |
| 证据 | Brief 路径 + revision、M0 REPORT |
| 失败处置 | 改规划/重规划→改 Brief；终止→停派发 |
| 提交时间 | 2026-08-03（本轮） |
| ADMIN 等待 | **是** |

### 4.2 Gate A：底座结构自动检查点

| 项 | 内容 |
|---|---|
| gate_id | GATE-A-FOUNDATION-CHECKPOINT |
| 进入条件 | WP-00～03 全部完成；各 WP DEV REPORT 与 QA PASS 齐全；各 WP 独立本地 commit SHA |
| 退出条件 | pass→自动进入 WP-04；fail→仅对缺失/失败项 DEV 返工 + QA 回归 |
| 证据 | WP-00～03 TASK/REPORT 索引；QA 结果；commit SHA 清单；新旧测试对比；typecheck；git diff --check；架构 diff；通用契约无 Cursor 字段；生产路径未变；风险/GAP |
| 失败处置 | 不进 Active；不影响 18766；不 push/tag/release |
| 提交时间 | 2026-08-07 |
| ADMIN 等待 | **否**（PM 判定 + QA 核验） |

### 4.3 Gate B：首次 Active 接管条件审批

| 项 | 内容 |
|---|---|
| gate_id | GATE-B-ACTIVE-TAKEOVER |
| trigger | 准备首次 Active 投递；或改变真实投递路径；或停止/影响 18766；或共享 Gateway/Writer Lock/Registry/稳定数据 |
| 进入条件 | 命中 trigger；且 WP-04～06 完成；Shadow 验证通过；candidate 源 SHA 冻结；隔离通过；Active 切换与回滚方案就绪 |
| 退出条件 | approve_active / reject_active / request_rework |
| 证据 | WP-04～06 索引；QA；candidate SHA；端口/Instance/Gateway/Data Root/Registry/Lock 隔离；Shadow 无双投递；Active 预览；回滚步骤与恢复时间 |
| 失败/默认 | 未批保持 Shadow；不改真路径；不影响 18766 |
| 提交时间 | 仅触发时，目标 ≤2026-08-10 |
| ADMIN 等待 | **是**（仅 trigger 命中时）；未命中则不生成、不等待 |

### 4.4 Gate C：最终验收

| 项 | 内容 |
|---|---|
| gate_id | GATE-C-FINAL-ACCEPTANCE |
| 进入条件 | WP-07～14 全部结束；子 TASK 均有 REPORT 或明确 blocked/aborted；DEV/QA/OPS/EVAL 证据汇总；candidate SHA 冻结；隔离完成；Session/Runtime/Shell/整机恢复验证完成；回滚演练完成；实验与证据索引完成；无未授权远程发布 |
| 退出条件 | accept / return_for_rework / terminate |
| 证据 | 最终 PM REPORT；全部 WP TASK/REPORT/REVIEW/ISSUE 索引；全量测试与 E2E；重启恢复；隔离与无双投递；最终 commit SHA 清单；风险/GAP/遗留/回滚报告；若曾触发 Gate B 则含其决定记录 |
| 失败/默认 | 主任务保持 open；不得宣称完成；不得远程发布 |
| 提交时间 | 2026-08-13 |
| ADMIN 等待 | **是**（不计 AI 日） |

### 4.5 D7 健康检查（2026-08-10）

| 检查项 | 通过标准 | 失败处置 |
|---|---|---|
| 预算消耗 | 累计已用 AI 日 ≤ 计划曲线；返工次数未爆各 WP 上限导致必破 D10 | 写健康检查纪要；触发 §4.7 延期重排申请 |
| 证据完整 | WP-00～06（已完成者）REPORT/SHA/测试索引可读 | 停派下一高风险 WP；先补证据 |
| 隔离/拓扑 | 18766 Gateway 在线启用；candidate/18768 未误开或已按规范关闭；无双根写入 | 立即停步并按 §9 请求 ADMIN |
| 风险 | R1～R13 无未处置 P0 | 升级 ADMIN |
| 输出 | `HEALTH-CHECK-D7` 纪要挂本 ROOT（REPORT 或 ISSUE 附件路径） | — |

### 4.6 D10 最终处置（2026-08-13）

1. 完成 WP-12→13→14 串行收尾与 Gate C 证据包。
2. 提交 Gate C；进入 **ADMIN 等待**（不计 AI 日）。
3. ADMIN `accept` → 主任务进入业务完成流程（仍不擅自 archive）。
4. ADMIN `return_for_rework` → 仅派指定返工；重排日历走 §4.7。
5. ADMIN `terminate` → 停止后续派发；保全全部证据后按 ADMIN 决定结束。
6. 若 D10 当日未能交 Gate C：当日 18:00 Asia/Shanghai 前必须提交阻塞汇总 + §4.7 重排提案，**禁止**静默延期。

### 4.7 延期与重排规则

| 触发 | 动作 |
|---|---|
| 任一 WP 返工将导致后续串行必破 D10 | D7 或当下立即冻结下一非必要派单；PM 提出新 D1'～D10'（仍保持 7～10 AI 日总预算或明示超预算需 ADMIN 批） |
| ADMIN 等待超过 48h（日历） | 不计入 AI 日；日历里程碑整体平移同等日历日；Brief/M0 更新 T0 与绝对日期 |
| 整机重启窗口 | 重启当日不计 AI 日；恢复验证通过后从中断 WP 续跑 |
| 禁止 | 用并行掩盖串行；擅自压缩验收；未经 ADMIN 扩大总 AI 日上限 |

## 5. 测试与实验计划（含连续性）

### 5.1 逐 WP 测试类型

| WP | 单元 | 集成 | 隔离 | 恢复 | 回归 |
|---|---|---|---|---|---|
| 00 | suite 基线记录 | 四角色链路样本 | 确认未写稳定副本 | — | 对照日后回归 |
| 01 | 契约/无 Cursor 字段 | 旧路径冒烟 | — | — | 基线对照 |
| 02 | 原子写/崩溃 | Store API | Mailbox 隔离 | 崩溃恢复 | — |
| 03 | Registry/Legacy | 多 Host 登记 | — | — | typecheck+diff check |
| 04 | Cursor mapper | 行为对照 | — | — | 基线 Cursor |
| 05 | Binding/unbound | 映射 | — | — | 真实路径未变 |
| 06 | Shadow 记录 | 对齐旧路径 | **18766/18768 全矩阵** | Runtime 重启 | 无双投递 |
| 07 | policy | 旧 gate 对照 | — | — | — |
| 08 | Switchboard | Dispatcher 接入 | — | emergency stop | 双投递对抗 |
| 09 | Run 状态 | 多 Run/claim | — | Session 占用 | 兼容 SessionRecord |
| 10 | 登记/绑定 | register 兼容 | — | — | 身份分离 |
| 11 | FactReader | 投影 | — | **hot/warm/cold** | — |
| 12 | FIFO/去重 | 旧 queue 投影 | 多 Worker 并行 | — | API 兼容 |
| 13 | 字段 | ProjectGraph | — | — | Desktop=PWA |
| 14 | 健康检查 | **18 E2E** | 再跑隔离 | Session/进程/Shell/**整机** | 全量 |

### 5.2 18766 / 18768 时序与拓扑

1. **日常（D1～D6）**：仅 18766；Current Project=core-dev；**Gateway 已启用并保持在线**；禁止启动 18768。
2. **D7 WP-06**：OPS 按固定**源 commit SHA**重建 `D:\codeflowmu-core-candidate`（即使 当前目录不干净（含历史 .codeflowmu/.git/fcop 等））→ 验证独立 instance/data/registry/lock → **强制 Gateway=false** → 启 18768 冒烟 → 证与 18766 隔离 → 关 18768。
3. **Active 前**：两实例不得共享 Agent ID、Session、Registry、Data Root、Writer Lock；18768 始终 Gateway=false；不得关闭或干扰 18766 Gateway，除非 ADMIN 书面批准。
4. **Gate C 前**：再跑隔离与候选冒烟；仍不 push。

### 5.3 连续性验证

| 层级 | 验证 | 责任 | 时机 |
|---|---|---|---|
| Session | 丢 Session 后 cold 接手；claim 不互抢 | DEV+QA | WP-09/11/14 |
| 进程 | Runtime 进程杀后状态文件可恢复 | DEV+QA | WP-06/14 |
| Shell | codeflowmu-shell 重启后任务线枝干/叶子可从账本重建 | DEV+QA | WP-13/14 |
| 整机 | Windows 重启前后账本与投影一致 | PM 写安全检查点 + **ADMIN 执行** + QA 验 | WP-14；计入 Gate C |

### 5.4 完整实验数据方案

| 维度 | 规定 |
|---|---|
| 只追加路径 | `D:\codeflowmu-core-dev\research-evidence\YYYYMMDD\` 下 JSONL；禁止改写历史行；禁止写入稳定副本 |
| 采集粒度 | 每次 Run / Doorbell / DeliveryAttempt / Gate 检查 / 恢复演练各 1 条事件；WP 结束写汇总条 |
| 关联 ID | 必填：`thread_key`、`task_id`、`wp_id`、`run_id`、`session_id`、`delivery_attempt_id`、`commit_sha`、`instance_id` |
| 时间戳 | 一律 `YYYY-MM-DDTHH:mm:ss+08:00`（Asia/Shanghai）；另保留 `unix_ms` 便于排序 |
| 脱敏 | 禁止写入 API Key、Cookie、Authorization、用户隐私原文；路径可保留项目根相对路径；日志摘要截断 |
| 校验 | 写入前 schema 校验（必填字段）；每日抽样核对 JSONL 行数与 Gate 证据索引一致 |
| 留存 | 本任务周期内全量保留；Gate C 后至少保留至 ADMIN accept/terminate 决定后 30 日（或 ADMIN 另行指定） |
| 复现 | 凭 `commit_sha` + 事件 JSONL + TASK/REPORT 路径可离线复盘；复现步骤写入各 WP REPORT「复现」小节 |

## 6. 风险登记

| ID | 风险 | 责任人 | 触发条件 | 影响 | 处置 | 状态 |
|---|---|---|---|---|---|---|
| R1 | 污染稳定副本 | DEV/OPS | 误写 D:\codeflowmu | 稳定工具受损 | 禁写门禁；回滚到 commit SHA；ISSUE | open |
| R2 | 端口/根目录串线 | OPS | 错误绑定 18766/18768 | 数据串扰 | 隔离矩阵；停错实例 | open |
| R3 | Writer Lock 冲突 | OPS/DEV | 双 Runtime 同根 | 半写入 | 单写者；停一方 | open |
| R4 | 双投递 | DEV/QA | Shadow/Active 缺陷 | 用户重复执行 | emergency stop；切 off/shadow | open |
| R5 | 误用 DoorbellBuffer | DEV | 当队列实现 | 错误真相 | 代码评审拒绝 | open |
| R6 | 契约 Cursor 污染 | DEV/QA | WP-01/04 泄漏 | 多 Host 不可用 | 扫描+回滚 SHA | open |
| R7 | 继承失败 | DEV/QA | cold 材料不足 | 不可接手 | 补 Fact/Evidence；返工 WP-11 | open |
| R8 | 规划产物丢失/被缩减覆盖 | PM | 目录被清或缩减稿覆盖 | Gate 证据断或不完整 | Runtime 唯一路径；本 r5 强制自包含 | mitigated |
| R9 | claim 路径误解析 | Runtime/PM | workspace_dir 多一层 fcop | 无法 claim | ISSUE-20260803-001-PM | open |
| R10 | 子会话无法写根 Brief | Runtime/PM | Planning 重写落子任务 | 规划停摆 | ISSUE-20260803-002-PM；根会话/thread 写 Brief | mitigated |
| R11 | 未授权发布 | PM | 误 push/PR | 违规 | 流程禁止至 Gate C accept | open |
| R12 | 日程/预算再膨胀 | PM | 返工突破 D10 | Gate 滑落 | D7 体检；申请平移；禁假并行 | open |
| R13 | candidate 未按源 SHA 重建或配置不独立 | OPS | Git 干净仍直接开 18768 / Gateway 误开 | 假隔离或串线 | 强制重建+Gateway=false 校验 | open |
| R14 | 误关 18766 Gateway | OPS/DEV | 把「Gateway 关」套用到 18766 | 稳定工具中断 | 立即恢复；升级 ADMIN | open |

## 7. 恢复与回滚计划

### 7.1 保全优先（硬规则）

**禁止**在未完成下列保全前执行 `git checkout <SHA>` / `git reset` / 覆盖工作树 / 重建 candidate 目录：

1. **未提交工作保全**：`git status` + `git diff` / `git diff --staged` 输出存入 `fcop/attachments/YYYYMMDD/` 或 `docs/core-refactor-runtime/preservation/`；必要时 `git stash push -u` 并记录 stash 名与时间戳。
2. **正式账本保全**：确认 `D:\codeflowmu-core-dev\fcop\` 下 tasks/reports/issues/ledger 可读取；复制关键门禁索引（或生成路径清单）到 preservation 目录。
3. **实验数据保全**：确认 `research-evidence/` JSONL 只追加完好；复制当日文件哈希清单。
4. **标记目标 SHA**：在 REPORT 写明目标 commit SHA 与回滚原因。
5. 保全完成并经 PM（或该 WP 验收角色）勾选后，方可 checkout/重建。

### 7.2 标准恢复顺序

1. 确认 **18766** 进程与 **Gateway 在线启用**、Current Project=core-dev。  
2. 核正式账本可读（§7.1-2）。  
3. 读 Runtime STATE / 锁 / instance 身份。  
4. 保全未提交工作与实验数据（§7.1-1/3）。  
5. Writer Lock 校验（单写者）。  
6. 如需回代码：保全后 `git checkout <目标 SHA>`（仅 core-dev）。  
7. 如需 18768：按固定源 SHA **重建** candidate，验证独立配置且 **Gateway=false**。  
8. 跑最小冒烟；通过后才进入下一安全动作。  

任一步失败 → **停止**进入下一高风险动作，并按 §9 判断是否升级 ADMIN。

### 7.3 Gate 回滚点

| Gate/点 | 固定标记 | 责任角色 | 保全措施 | 验证步骤 | 停止条件 |
|---|---|---|---|---|---|
| 基线 WP-00 | **BASELINE commit SHA**（不打 tag） | DEV；PM | §7.1 全项 | 重跑基线可复现 | 稳定副本被改→停并升级 ADMIN |
| Gate A | **GATE-A commit SHA** | DEV；PM；QA | WP-00～03 SHA 清单 + §7.1 | 扫描+测试+diff check | fail→只返工，不进 Active |
| Gate B 前 | **PRE-ACTIVE SHA** + candidate **源 SHA** | DEV/OPS；PM | Shadow→off；candidate 快照 | 隔离+无双投递+冒烟；18768 Gateway=false | 未 approve→禁改真路径 |
| Active 异常 | 回 PRE-ACTIVE 或 off/shadow | PM；DEV；QA | 保留 delivery 证据 + §7.1 | 无双发；18766 Gateway 仍在线 | 18766 异常→停候选与 Active 并升级 ADMIN |
| Gate C 前 | **RC-CANDIDATE commit SHA** | PM/OPS | 清单不远程发布 | 全量+E2E+重启 | 证据缺→不交 Gate C |

## 8. 规划状态与变更记录

**status=`ready_for_review` · Planning Gate **待 ADMIN 批准** · **WP-00 only**.

| revision | 原因 | 提出者 | 审查者 | 时间 | 状态 |
|---|---|---|---|---|---|
| r1 | M0 从零重建 Brief | PM-01 | ADMIN | 2026-08-03 | **拒绝**（过简） |
| r2 | 按代码基线加深 | PM-01 | ADMIN | 2026-08-03 | **拒绝/要求修改** |
| r3 | 补齐逐 WP/绝对日期/Gate/测试/风险/回滚 | PM-01 | ADMIN | 2026-08-03 | **要求修改**（预算与日程矛盾；禁本地 tag） |
| r4 | 预算改 7～10；消重叠；仅 SHA；缩减稿 | PM-01 | ADMIN | 2026-08-03 | **要求改规划** |
| r5 | 自包含全文 | PM-01 | ADMIN | 2026-08-03 | **要求改规划**（硬缺口） |
| r6 | hard-gap fix（历史旧线） | PM-01 | ADMIN | 2026-08-03 | **历史** |
| r1 | T0=`2026-08-04T13:28:47+08:00`; D1=2026-08-04..D10=2026-08-13 | PM-01 | ADMIN | 2026-08-03 | **live** |

## 9. 必须立即停下并请求 ADMIN 决定的条件

出现下列任一情况，PM/DEV/QA/OPS **立即停止**当前高风险动作（含派单、18768、Active 切换、整机相关、破坏性 git），写 ISSUE + 阶段 REPORT（blocked），等待 ADMIN：

1. 需要 **Windows 整机重启**。
2. 需要停止、重启或改变 **18766 Gateway**，或任何可能影响 18766 稳定工具可用性的操作。
3. **首次 Active 接管**或改变真实投递路径（Gate B trigger）。
4. 修改稳定数据、共享 Gateway/Writer Lock/Registry/实例身份，或两实例出现共享冲突。
5. 破坏性、不可逆或跨项目操作（含未保全的强制 checkout/reset、删除正式账本/实验数据）。
6. 远程 **push / PR / tag / release**。
7. 任务范围、验收标准或产品方向发生实质变化；或总 AI 日将超过 7～10 需扩预算。
8. 无法由测试证据判断的业务选择。
9. **Gate C** 最终业务验收。
10. 发现稳定副本 `D:\codeflowmu` 被本任务写入或污染。
11. 确认或高度怀疑 **双投递** / 向 Cursor 重复真 send。
12. Planning Gate 未批准却有人要求派发 WP-00。


### 新执行线声明（TASK-20260804-001）

- 本根任务由 Runtime 新分配：TASK-20260804-001 · thread submission-submission-20260804-001 · submission SUBMISSION-20260804-001。
- 历史线 TASK-20260731-001（WP-00～03/Gate A 曾完成）与 TASK-20260803-001（账本曾清空）**不得**自动抵扣本线 WP/Gate 证据。
- 当前磁盘事实：core-dev 分支 codex/work-inheritance-core-dev @ 63ee3d220ccd719369c1651c2fc48e4c872aa3d5（Prepare V1.2.17-open）；工作树有 runtime/ledger 未提交项，产品源码改动需在 WP-00 冻结时另行核验。
- 18766 program/host root=D:\\codeflowmu；Current Project=D:\\codeflowmu-core-dev；candidate=D:\\codeflowmu-core-candidate **不干净**。
- 必读外部文档 01/02/03 绝对路径可读。
- 业务代码根为项目 root 模式；实验证据落 workspace/core-refactor-plan/research-evidence/（已存在，不另建业务 workspace）。
- **本轮仅提交 Planning Gate**；未获批准前禁止 write_task 派发 DEV/QA/OPS/EVAL。

### Planning Gate status

待 ADMIN 五选一：批准进入 WP-00 / 要求修改规划 / 暂停 / 退回重规划 / 终止。
