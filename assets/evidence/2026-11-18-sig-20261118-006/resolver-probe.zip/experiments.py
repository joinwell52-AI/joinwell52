# Publication companion: unchanged extracted function and the same eight Analysis controls.
# Prepared for inspection; not a new Production experiment run.
import json
def resolve_read(event, previous_state):
    found = bool((event.get("result") or {}).get("found"))
    return {
        "role": "acquire",
        "status": "success" if found else "partial",
        "milestones_added": ["record_read"] if found else [],
        "progress_token": "record_found" if found else None,
    }

for value in [True, False, None, "false", "true", 0, 1, []]:
    strict = "success" if value is True else ("partial" if value is False else "invalid-type")
    print(json.dumps({"input": value, "actualOutput": resolve_read({"result": {"found": value}}, {}), "strictBooleanControl": strict}))
