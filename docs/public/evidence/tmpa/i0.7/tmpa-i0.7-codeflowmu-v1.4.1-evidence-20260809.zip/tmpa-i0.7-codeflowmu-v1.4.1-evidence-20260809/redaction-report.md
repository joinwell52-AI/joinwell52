# Redaction Report

包只包含公开源码锁定信息、测试 Fixture、执行元数据、原始日志、报告和哈希。未包含 `.env`、API Key、Token、Cookie、密码、私钥、本地登录状态、生产数据或小典后台凭据。

封包前对全部文本执行敏感赋值、Authorization、私钥头和 `.env` 文件名扫描，结果记录于 `manifests/redaction-scan.json`。

作者生成文本均为 UTF-8。如果 FCoP stdout 含非 UTF-8 字节，则原始字节以 `.raw.bin` 保留，并生成明确标记替换方法的 UTF-8 可解码副本；不把规范化副本描述为原始字节无损文本。
