import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import { validate } from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-protocol/src/index.ts";
import type {
  TmpaGovernanceObject,
  TmpaLifecycleProfile,
  TmpaReaderResult,
} from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-protocol/src/index.ts";
import {
  canonicalBytes,
  finalizeTmpaObject,
  sha256Digest,
} from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-runtime/src/tmpa/canonical.ts";
import { projectFcopToTmpa } from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-runtime/src/tmpa/FcopSourceAdapter.ts";
import { createTmpaGovernanceReader } from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-runtime/src/tmpa/GovernanceReader.ts";
import { createCodeFlowMuTmpaProfile } from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-runtime/src/tmpa/profile.ts";
import type { TmpaSourceCandidate } from "./codeflowmu-local-clean-1cd40353-public/packages/codeflowmu-runtime/src/tmpa/types.ts";

function governanceObject(
  id: string,
  type: string,
  overrides: Partial<TmpaGovernanceObject> = {},
): TmpaGovernanceObject {
  const role = overrides.role ?? "DEV";
  const creator = overrides.creator ?? "dev-1";
  return finalizeTmpaObject({
    tmpa_version: "S0.5",
    id,
    type,
    governed_work: overrides.governed_work ?? {
      id: type === "TASK" ? id : "TASK-I07-001",
      primary_carrier_id: type === "TASK" ? id : "TASK-I07-001",
    },
    stream: overrides.stream ?? { id: `stream:${creator}:${type}`, sequence: 1 },
    creator,
    role,
    created_at: overrides.created_at ?? "2026-08-09T00:00:00.000Z",
    lifecycle: overrides.lifecycle ?? {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "inbox",
    },
    references: overrides.references ?? [],
    ...(overrides.claims ? { claims: overrides.claims } : {}),
    ...(overrides.risk ? { risk: overrides.risk } : {}),
    content: overrides.content ?? { media_type: "application/json", body: {} },
    extensions: overrides.extensions ?? {},
  });
}

function source(id: string, value: unknown): TmpaSourceCandidate {
  return {
    source_id: id,
    media_type: "application/json",
    bytes: canonicalBytes(value),
  };
}

function profile(): TmpaLifecycleProfile {
  return createCodeFlowMuTmpaProfile({
    assignments: [
      { identity: "dev-1", role: "DEV", actions: ["submit_review"] },
      {
        identity: "pm-1",
        role: "PM",
        actions: [
          "runtime_dispatch",
          "approve_review",
          "reject_review",
          "archive_task",
          "resolve_review_conflict",
        ],
      },
      {
        identity: "qa-1",
        role: "QA",
        actions: ["approve_review", "reject_review", "resolve_review_conflict"],
      },
      {
        identity: "qa-2",
        role: "QA",
        actions: ["approve_review", "reject_review", "resolve_review_conflict"],
      },
    ],
  });
}

function reader(customProfile = profile()) {
  return createTmpaGovernanceReader({ lifecycleProfile: customProfile });
}

function issueCodes(result: TmpaReaderResult): string[] {
  return result.issues.map((item) => item.code);
}

function summary(result: TmpaReaderResult) {
  return result.extensions?.summary as {
    work_state: Record<string, string>;
    acceptance_state: Record<string, string>;
    responsibility: Record<string, string>;
  };
}

function permutations<T>(values: readonly T[]): T[][] {
  if (values.length <= 1) return [[...values]];
  return values.flatMap((value, index) =>
    permutations([...values.slice(0, index), ...values.slice(index + 1)]).map(
      (tail) => [value, ...tail],
    ),
  );
}

function lifecycleFixture() {
  const task = governanceObject("TASK-I07-001", "TASK", {
    creator: "pm-1",
    role: "PM",
    stream: { id: "stream:task", sequence: 1 },
  });
  const report = governanceObject("REPORT-I07-001", "REPORT", {
    creator: "dev-1",
    role: "DEV",
    stream: { id: "stream:report", sequence: 1 },
    references: [{ relation: "reports", target: task.id }],
  });
  const dispatch = governanceObject("TRANSITION-I07-001", "TRANSITION", {
    creator: "CODEFLOWMU-RUNTIME",
    role: "SYSTEM",
    stream: { id: "stream:transition:1", sequence: 1 },
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "active",
      transition: { from: "inbox", action: "runtime_dispatch", to: "active" },
    },
  });
  const submit = governanceObject("TRANSITION-I07-002", "TRANSITION", {
    creator: "dev-1",
    role: "DEV",
    stream: { id: "stream:transition:2", sequence: 1 },
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "review",
      transition: { from: "active", action: "submit_review", to: "review" },
    },
    references: [
      { relation: "depends_on", target: dispatch.id },
      { relation: "reports", target: report.id },
    ],
  });
  return { task, report, dispatch, submit };
}

test("C01 rejects every mandatory malformed-schema class deterministically", async () => {
  const valid = governanceObject("TASK-I07-C01", "TASK");
  const malformed: Array<[string, unknown]> = [];

  const missing = structuredClone(valid) as Record<string, unknown>;
  delete missing.creator;
  malformed.push(["missing-required", missing]);

  const wrongVersion = structuredClone(valid) as Record<string, unknown>;
  wrongVersion.tmpa_version = "S0.4";
  malformed.push(["wrong-version", wrongVersion]);

  const wrongType = structuredClone(valid) as Record<string, unknown>;
  wrongType.type = 7;
  malformed.push(["wrong-type", wrongType]);

  const prohibited = structuredClone(valid) as Record<string, unknown>;
  prohibited.hidden_authority = true;
  malformed.push(["prohibited-field", prohibited]);

  const badTransition = structuredClone(valid) as Record<string, unknown>;
  badTransition.lifecycle = {
    profile: "codeflowmu-fcop-tmpa-s0.5",
    state: "active",
    transition: { from: "inbox", to: "active" },
  };
  malformed.push(["malformed-transition", badTransition]);

  const badSignature = structuredClone(valid) as Record<string, unknown>;
  (badSignature.integrity as Record<string, unknown>).signature_algorithm = "ed25519";
  malformed.push(["incomplete-signature", badSignature]);

  const badClaim = structuredClone(valid) as Record<string, unknown>;
  badClaim.claims = [{ id: "claim-1", predicate: "work.complete", subject: valid.id }];
  malformed.push(["malformed-claim", badClaim]);

  const badRisk = structuredClone(valid) as Record<string, unknown>;
  badRisk.risk = { level: "extreme", requires_human_approval: true };
  malformed.push(["invalid-risk", badRisk]);

  const badTime = structuredClone(valid) as Record<string, unknown>;
  badTime.created_at = "not-a-date";
  malformed.push(["invalid-date-time", badTime]);

  for (const [name, value] of malformed) {
    const first = await reader().read([source(name, value)]);
    const second = await reader().read([source(name, value)]);
    assert.deepEqual(first, second, name);
    assert.deepEqual(issueCodes(first), ["SCHEMA_INVALID"], name);
    assert.equal(first.nodes.length, 0, name);
    assert.equal(first.judgment, "invalid", name);
  }
});

test("C02 FCoP parent survives projection and appears in product reader", async () => {
  const root = await mkdtemp(join(tmpdir(), "codeflowmu-i07-c02-"));
  try {
    await mkdir(join(root, "fcop", "tasks"), { recursive: true });
    await writeFile(
      join(root, "codeflowmu.team.json"),
      JSON.stringify({ members: [{ agent_id: "dev-1", role: "DEV" }] }),
      "utf8",
    );
    await writeFile(
      join(root, "fcop", "tasks", "TASK-I07-PARENT.md"),
      ["---", "protocol: fcop", "task_id: TASK-I07-PARENT", "sender: DEV", "state: inbox", "---", "# Parent"].join("\n"),
      "utf8",
    );
    await writeFile(
      join(root, "fcop", "tasks", "TASK-I07-CHILD.md"),
      ["---", "protocol: fcop", "task_id: TASK-I07-CHILD", "parent: TASK-I07-PARENT", "sender: DEV", "state: inbox", "---", "# Child"].join("\n"),
      "utf8",
    );
    const projection = await projectFcopToTmpa(root);
    const child = projection.sources.find((item) => item.object.id === "TASK-I07-CHILD");
    assert.equal(child?.object.governed_work.parent_id, "TASK-I07-PARENT");
    const result = await createTmpaGovernanceReader({
      lifecycleProfile: projection.profile,
    }).read(projection.sources);
    assert.equal(
      result.nodes.find((node) => node.id === "TASK-I07-CHILD")?.parent_work_id,
      "TASK-I07-PARENT",
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("C03 conflicting same-ID candidates remain manifested and no node wins", async () => {
  const left = governanceObject("TASK-I07-C03", "TASK", {
    content: { media_type: "application/json", body: { value: "left" } },
  });
  const right = governanceObject("TASK-I07-C03", "TASK", {
    content: { media_type: "application/json", body: { value: "right" } },
  });
  const result = await reader().read([source("left", left), source("right", right)]);
  assert.equal(result.nodes.some((node) => node.id === left.id), false);
  assert.equal((result.extensions?.source_manifest as unknown[]).length, 2);
  const conflict = result.issues.find((issue) => issue.code === "DUPLICATE_ID_CONFLICT");
  assert.equal(conflict?.severity, "critical");
  assert.equal(result.view_state, "quarantined");
});

test("C04 reports duplicate and gap while unrelated streams still reconstruct", async () => {
  const duplicateA = governanceObject("TASK-I07-C04-A", "TASK", {
    stream: { id: "stream:duplicate", sequence: 1 },
  });
  const duplicateB = governanceObject("TASK-I07-C04-B", "TASK", {
    stream: { id: "stream:duplicate", sequence: 1 },
  });
  const unrelated = governanceObject("TASK-I07-C04-C", "TASK", {
    stream: { id: "stream:unrelated", sequence: 1 },
  });
  const duplicateResult = await reader().read([
    source("a", duplicateA),
    source("b", duplicateB),
    source("c", unrelated),
  ]);
  assert.ok(issueCodes(duplicateResult).includes("STREAM_DUPLICATE_SEQUENCE"));
  assert.equal(
    duplicateResult.nodes.find((node) => node.id === unrelated.id)?.judgment,
    "valid",
  );

  const first = governanceObject("TASK-I07-C04-D", "TASK", {
    stream: { id: "stream:gap", sequence: 1 },
  });
  const third = governanceObject("TASK-I07-C04-E", "TASK", {
    stream: { id: "stream:gap", sequence: 3 },
  });
  const inputs = [source("first", first), source("third", third), source("other", unrelated)];
  const forward = await reader().read(inputs);
  const reverse = await reader().read([...inputs].reverse());
  assert.deepEqual(forward, reverse);
  assert.ok(issueCodes(forward).includes("STREAM_GAP"));
  assert.deepEqual(forward.nodes.map((node) => node.id).sort(), [first.id, third.id, unrelated.id].sort());
});

test("C05 denied and unassigned actions are not applied", async () => {
  const task = governanceObject("TASK-I07-001", "TASK");
  const denied = governanceObject("TRANSITION-I07-C05-DENIED", "TRANSITION", {
    creator: "dev-1",
    role: "DEV",
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "active",
      transition: { from: "inbox", action: "runtime_dispatch", to: "active" },
    },
  });
  const deniedResult = await reader().read([source("task", task), source("denied", denied)]);
  assert.ok(issueCodes(deniedResult).includes("AUTHORITY_DENIED"));
  assert.equal(deniedResult.judgment, "invalid");
  assert.equal(summary(deniedResult).work_state[task.id], "inbox");

  const unassigned = governanceObject("TRANSITION-I07-C05-UNKNOWN", "TRANSITION", {
    creator: "unknown-actor",
    role: "PM",
    stream: { id: "stream:unknown", sequence: 1 },
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "active",
      transition: { from: "inbox", action: "runtime_dispatch", to: "active" },
    },
  });
  const unknownResult = await reader().read([source("task", task), source("unknown", unassigned)]);
  assert.ok(issueCodes(unknownResult).includes("AUTHORITY_UNDETERMINED"));
  assert.equal(unknownResult.judgment, "undetermined");
  assert.equal(summary(unknownResult).work_state[task.id], "inbox");
});

test("C06 illegal, missing-prerequisite, conflicting-state and missing-acceptance semantics", async () => {
  const task = governanceObject("TASK-I07-001", "TASK");
  const illegal = governanceObject("TRANSITION-I07-C06-ILLEGAL", "TRANSITION", {
    creator: "pm-1",
    role: "PM",
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "archive",
      transition: { from: "inbox", action: "archive_task", to: "archive" },
    },
  });
  const illegalResult = await reader().read([source("task", task), source("illegal", illegal)]);
  assert.ok(issueCodes(illegalResult).includes("ILLEGAL_TRANSITION"));
  assert.equal(summary(illegalResult).work_state[task.id], "inbox");

  const observation = governanceObject("OBSERVATION-I07-C06", "STATE_OBSERVATION", {
    content: { media_type: "application/json", body: { state: "active" } },
  });
  const observed = await reader().read([source("task", task), source("observation", observation)]);
  assert.ok(issueCodes(observed).includes("STATE_EVIDENCE_CONFLICT"));

  const fixture = lifecycleFixture();
  const missingAcceptance = governanceObject("TRANSITION-I07-C06-APPROVE", "TRANSITION", {
    creator: "pm-1",
    role: "PM",
    stream: { id: "stream:transition:3", sequence: 1 },
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "done",
      transition: { from: "review", action: "approve_review", to: "done" },
    },
    references: [{ relation: "depends_on", target: fixture.submit.id }],
  });
  const missingAcceptanceResult = await reader().read(
    [fixture.task, fixture.report, fixture.dispatch, fixture.submit, missingAcceptance].map(
      (value) => source(value.id, value),
    ),
  );
  assert.ok(issueCodes(missingAcceptanceResult).includes("LIFECYCLE_UNDETERMINED"));
  assert.ok(
    issueCodes(missingAcceptanceResult).includes("ACCEPTANCE_UNDETERMINED"),
    "S0.5 requires ACCEPTANCE_UNDETERMINED for completion without independent acceptance",
  );
  assert.equal(summary(missingAcceptanceResult).work_state[fixture.task.id], "review");
});

test("C07 identity-level SOD and human approval gate", async () => {
  const task = governanceObject("TASK-I07-001", "TASK");
  const report = governanceObject("REPORT-I07-C07", "REPORT", {
    creator: "dev-1",
    references: [{ relation: "reports", target: task.id }],
  });
  const review = governanceObject("REVIEW-I07-C07", "REVIEW", {
    creator: "dev-1",
    role: "QA",
    stream: { id: "stream:c07-review", sequence: 1 },
    references: [{ relation: "reviews", target: report.id }],
    content: { media_type: "application/json", body: { decision: "approved" } },
  });
  const sod = await reader().read([source("task", task), source("report", report), source("review", review)]);
  assert.ok(issueCodes(sod).includes("SOD_VIOLATION"));

  const highRisk = governanceObject("TASK-I07-C07-RISK", "TASK", {
    risk: { level: "high", requires_human_approval: true },
  });
  const pending = await reader().read([source("risk", highRisk)]);
  assert.ok(issueCodes(pending).includes("HUMAN_APPROVAL_REQUIRED"));
  assert.equal(pending.view_state, "pending_human");

  const approval = governanceObject("DECISION-I07-C07", "DECISION", {
    creator: "human:ADMIN",
    role: "ADMIN",
    stream: { id: "stream:admin-decision", sequence: 1 },
    governed_work: { id: highRisk.id, primary_carrier_id: highRisk.id },
    content: { media_type: "application/json", body: { decision: "approved" } },
  });
  const approvedTask = finalizeTmpaObject({
    ...highRisk,
    references: [{ relation: "human_approves", target: approval.id }],
    integrity: undefined,
  });
  const approved = await reader().read([source("risk", approvedTask), source("approval", approval)]);
  assert.equal(issueCodes(approved).includes("HUMAN_APPROVAL_REQUIRED"), false);
});

test("C08 covered bytes fail after tamper while excluded signature metadata is not claimed", async () => {
  const intact = governanceObject("TASK-I07-C08", "TASK");
  const intactResult = await reader().read([source("intact", intact)]);
  assert.equal(intactResult.judgment, "valid");

  const tampered = structuredClone(intact);
  tampered.content = { media_type: "application/json", body: { tampered: true } };
  const tamperedResult = await reader().read([source("tampered", tampered)]);
  assert.ok(issueCodes(tamperedResult).includes("INTEGRITY_MISMATCH"));
  assert.equal(tamperedResult.nodes.length, 0);
  assert.equal((tamperedResult.extensions?.source_manifest as unknown[]).length, 1);

  const signed = structuredClone(intact);
  signed.integrity.signature_algorithm = "ed25519";
  signed.integrity.key_id = "test-key";
  signed.integrity.signature = "test-signature";
  const signedResult = await reader().read([source("signed", signed)]);
  assert.equal(issueCodes(signedResult).includes("INTEGRITY_MISMATCH"), false);
  assert.ok(issueCodes(signedResult).includes("SIGNATURE_UNVERIFIED"));
});

test("C09 missing references and completion evidence stay unsatisfied", async () => {
  const task = governanceObject("TASK-I07-C09", "TASK", {
    references: [{ relation: "depends_on", target: "TASK-I07-MISSING" }],
    claims: [{
      id: "claim-i07",
      predicate: "work.complete",
      subject: "TASK-I07-C09",
      evidence: ["REPORT-I07-MISSING"],
    }],
  });
  const result = await reader().read([source("task", task)]);
  assert.ok(issueCodes(result).includes("MISSING_REFERENCE"));
  assert.ok(issueCodes(result).includes("CLAIM_EVIDENCE_MISSING"));
  assert.equal(result.nodes[0]?.judgment, "undetermined");
  assert.ok(result.edges.some((edge) => edge.target_id === "TASK-I07-MISSING"));
});

test("C10 only prohibited-cycle members are quarantined", async () => {
  const left = governanceObject("TASK-I07-C10-A", "TASK", {
    stream: { id: "stream:c10:left", sequence: 1 },
    references: [{ relation: "depends_on", target: "TASK-I07-C10-B" }],
  });
  const right = governanceObject("TASK-I07-C10-B", "TASK", {
    stream: { id: "stream:c10:right", sequence: 1 },
    references: [{ relation: "depends_on", target: "TASK-I07-C10-A" }],
  });
  const clear = governanceObject("TASK-I07-C10-C", "TASK", {
    stream: { id: "stream:c10:clear", sequence: 1 },
  });
  const result = await reader().read([source("left", left), source("right", right), source("clear", clear)]);
  assert.ok(issueCodes(result).includes("PROHIBITED_CYCLE"));
  assert.equal(result.nodes.find((node) => node.id === left.id)?.view_state, "quarantined");
  assert.equal(result.nodes.find((node) => node.id === right.id)?.view_state, "quarantined");
  assert.equal(result.nodes.find((node) => node.id === clear.id)?.view_state, "authoritative");
});

test("C11 all 24 source permutations are byte-equivalent", async () => {
  const task = governanceObject("TASK-I07-C11-A", "TASK", {
    references: [{ relation: "depends_on", target: "TASK-I07-C11-MISSING" }],
  });
  const report = governanceObject("REPORT-I07-C11", "REPORT", {
    governed_work: { id: task.id, primary_carrier_id: task.id },
    references: [{ relation: "reports", target: task.id }],
  });
  const unrelatedA = governanceObject("TASK-I07-C11-B", "TASK", {
    stream: { id: "stream:unrelated-b", sequence: 1 },
  });
  const unrelatedB = governanceObject("TASK-I07-C11-C", "TASK", {
    stream: { id: "stream:unrelated-c", sequence: 1 },
  });
  const inputs = [source("task", task), source("report", report), source("b", unrelatedA), source("c", unrelatedB)];
  const outputs: string[] = [];
  for (const order of permutations(inputs)) {
    outputs.push(Buffer.from(canonicalBytes(await reader().read(order))).toString("hex"));
  }
  assert.equal(outputs.length, 24);
  assert.equal(new Set(outputs).size, 1);
  const result = await reader().read(inputs);
  assert.equal(result.edges.some((edge) => edge.source_id === unrelatedA.id || edge.source_id === unrelatedB.id), false);
  process.stdout.write(`${JSON.stringify({ criterion: "C11", permutations: 24, canonical_sha256: sha256Digest(Buffer.from(outputs[0]!, "hex")) })}\n`);
});

test("C12 conflicts remain disputed until an authorized resolution", async () => {
  const task = governanceObject("TASK-I07-001", "TASK");
  const report = governanceObject("REPORT-I07-C12", "REPORT", {
    references: [{ relation: "reports", target: task.id }],
  });
  const approve = governanceObject("REVIEW-I07-C12-A", "REVIEW", {
    creator: "qa-1",
    role: "QA",
    stream: { id: "stream:c12:a", sequence: 1 },
    references: [{ relation: "reviews", target: report.id }],
    content: { media_type: "application/json", body: { decision: "approved" } },
  });
  const reject = governanceObject("REVIEW-I07-C12-B", "REVIEW", {
    creator: "qa-2",
    role: "QA",
    stream: { id: "stream:c12:b", sequence: 1 },
    references: [{ relation: "reviews", target: report.id }],
    content: { media_type: "application/json", body: { decision: "rejected" } },
  });
  const base = [task, report, approve, reject].map((value) => source(value.id, value));
  const disputed = await reader().read(base);
  assert.equal(disputed.view_state, "disputed");
  assert.ok(issueCodes(disputed).includes("UNRESOLVED_CONFLICT"));

  const unauthorized = governanceObject("DECISION-I07-C12-UNAUTHORIZED", "DECISION", {
    creator: "unassigned-dev",
    role: "DEV",
    stream: { id: "stream:c12:unauthorized", sequence: 1 },
    references: [
      { relation: "resolves", target: approve.id },
      { relation: "resolves", target: reject.id },
    ],
    content: { media_type: "application/json", body: { selects: approve.id } },
  });
  const unauthorizedResult = await reader().read([...base, source("unauthorized", unauthorized)]);
  assert.equal(
    unauthorizedResult.view_state,
    "disputed",
    "an unassigned DEV decision must not resolve a governance conflict",
  );

  const authorized = governanceObject("DECISION-I07-C12-AUTHORIZED", "DECISION", {
    creator: "pm-1",
    role: "PM",
    stream: { id: "stream:c12:authorized", sequence: 1 },
    references: [
      { relation: "resolves", target: approve.id },
      { relation: "resolves", target: reject.id },
    ],
    content: { media_type: "application/json", body: { selects: approve.id } },
  });
  const authorizedResult = await reader().read([...base, source("authorized", authorized)]);
  assert.equal(issueCodes(authorizedResult).includes("UNRESOLVED_CONFLICT"), false);
});

test("C13 fresh readers reconstruct lifecycle, responsibility, dependency, recovery and parent-child state", async () => {
  const root = await mkdtemp(join(tmpdir(), "codeflowmu-i07-c13-"));
  try {
    const fixture = lifecycleFixture();
    const review = governanceObject("REVIEW-I07-C13", "REVIEW", {
      creator: "qa-1",
      role: "QA",
      stream: { id: "stream:c13-review", sequence: 1 },
      references: [{ relation: "reviews", target: fixture.report.id }],
      content: { media_type: "application/json", body: { decision: "approved" } },
    });
    const approve = governanceObject("TRANSITION-I07-C13-APPROVE", "TRANSITION", {
      creator: "pm-1",
      role: "PM",
      stream: { id: "stream:c13-approve", sequence: 1 },
      lifecycle: {
        profile: "codeflowmu-fcop-tmpa-s0.5",
        state: "done",
        transition: { from: "review", action: "approve_review", to: "done" },
      },
      references: [
        { relation: "depends_on", target: fixture.submit.id },
        { relation: "accepts", target: fixture.report.id },
      ],
    });
    const child = governanceObject("TASK-I07-C13-CHILD", "TASK", {
      governed_work: {
        id: "TASK-I07-C13-CHILD",
        primary_carrier_id: "TASK-I07-C13-CHILD",
        parent_id: fixture.task.id,
      },
      references: [{ relation: "depends_on", target: "TASK-I07-C13-MISSING" }],
    });
    const failure = governanceObject("FAILURE-I07-C13", "FAILURE", {
      governed_work: { id: fixture.task.id, primary_carrier_id: fixture.task.id },
      content: { media_type: "application/json", body: { failure_type: "timeout" } },
    });
    const recovery = governanceObject("RECOVERY-I07-C13", "RECOVERY", {
      governed_work: { id: fixture.task.id, primary_carrier_id: fixture.task.id },
      references: [{ relation: "recovers", target: failure.id }],
      content: { media_type: "application/json", body: { action: "resume" } },
    });
    const values = [fixture.task, fixture.report, fixture.dispatch, fixture.submit, review, approve, child, failure, recovery];
    await Promise.all(values.map((value) => writeFile(join(root, `${value.id}.json`), canonicalBytes(value))));
    const load = async (order: readonly TmpaGovernanceObject[]) => Promise.all(order.map(async (value) => ({
      source_id: value.id,
      path: join(root, `${value.id}.json`),
      media_type: "application/json",
      bytes: await readFile(join(root, `${value.id}.json`)),
    })));
    const first = await createTmpaGovernanceReader({ lifecycleProfile: profile() }).read(await load(values));
    const fresh = await createTmpaGovernanceReader({ lifecycleProfile: profile() }).read(await load([...values].reverse()));
    assert.deepEqual(first, fresh);
    assert.equal(summary(first).work_state[fixture.task.id], "done");
    assert.equal(summary(first).responsibility[fixture.task.id], "PM");
    assert.ok(issueCodes(first).includes("MISSING_REFERENCE"));
    assert.ok(issueCodes(first).includes("CHILD_WORK_OPEN"));
    assert.equal(first.nodes.find((node) => node.id === child.id)?.parent_work_id, fixture.task.id);
    assert.ok(first.nodes.some((node) => node.type === "FAILURE"));
    assert.ok(first.nodes.some((node) => node.type === "RECOVERY"));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("C14 archive is gated by acceptance and preserves full history", async () => {
  const fixture = lifecycleFixture();
  const review = governanceObject("REVIEW-I07-C14", "REVIEW", {
    creator: "qa-1",
    role: "QA",
    stream: { id: "stream:c14-review", sequence: 1 },
    references: [{ relation: "reviews", target: fixture.report.id }],
    content: { media_type: "application/json", body: { decision: "approved" } },
  });
  const approve = governanceObject("TRANSITION-I07-C14-APPROVE", "TRANSITION", {
    creator: "pm-1",
    role: "PM",
    stream: { id: "stream:c14-approve", sequence: 1 },
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "done",
      transition: { from: "review", action: "approve_review", to: "done" },
    },
    references: [
      { relation: "depends_on", target: fixture.submit.id },
      { relation: "accepts", target: fixture.report.id },
    ],
  });
  const archive = governanceObject("TRANSITION-I07-C14-ARCHIVE", "TRANSITION", {
    creator: "pm-1",
    role: "PM",
    stream: { id: "stream:c14-archive", sequence: 1 },
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "archive",
      transition: { from: "done", action: "archive_task", to: "archive" },
    },
    references: [
      { relation: "depends_on", target: approve.id },
      { relation: "archives", target: fixture.task.id },
    ],
  });
  const values = [fixture.task, fixture.report, fixture.dispatch, fixture.submit, review, approve, archive];
  const result = await reader().read(values.map((value) => source(value.id, value)));
  assert.equal(summary(result).work_state[fixture.task.id], "archive");
  assert.equal(summary(result).acceptance_state[fixture.task.id], "accepted");
  assert.deepEqual(result.nodes.map((node) => node.id).sort(), values.map((value) => value.id).sort());

  const premature = governanceObject("TRANSITION-I07-C14-PREMATURE", "TRANSITION", {
    creator: "pm-1",
    role: "PM",
    lifecycle: {
      profile: "codeflowmu-fcop-tmpa-s0.5",
      state: "archive",
      transition: { from: "active", action: "force_archive_task", to: "archive" },
    },
  });
  const prematureResult = await reader().read([source("task", fixture.task), source("premature", premature)]);
  assert.equal(summary(prematureResult).work_state[fixture.task.id], "inbox");
  assert.notEqual(summary(prematureResult).acceptance_state[fixture.task.id], "accepted");
});

test("published TMPA schemas still compile after product-level execution", async () => {
  assert.equal((await validate("tmpa-governance-object", governanceObject("TASK-I07-SCHEMA", "TASK"))).valid, true);
});
