import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";

async function main(): Promise<void> {
  const root = resolve(process.argv[2] ?? "");
  const releaseSha = process.argv[3] ?? "UNKNOWN";
  if (!process.argv[2]) throw new Error("usage: init_codeflowmu_clean_instance.ts <root> <release-sha>");

  const moduleUrl = pathToFileURL(
    join(root, "codeflowmu-shell", "src", "fcop-bootstrap-transaction.ts"),
  ).href;
  const {
    buildFcopInitPlan,
    FcopInitTransaction,
    verifyFcopBootstrapManifest,
  } = await import(moduleUrl);

  const plan = buildFcopInitPlan({
    sourceRoot: root,
    targetRoot: root,
    sourceReleaseSha: releaseSha,
    initializationProfile: {
      mode: "project",
      team: "dev-team",
      workspaceMode: "multi",
    },
  });

  console.log(JSON.stringify({
    phase: "plan",
    plan_digest: plan.plan_digest,
    mode: plan.mode,
    create_count: plan.create.length,
    update_count: plan.update.length,
    preserve_count: plan.preserve.length,
    conflict_count: plan.conflict.length,
    conflicts: plan.conflict,
  }, null, 2));

  if (plan.conflict.length > 0) {
    throw new Error("clean initialization plan contains conflicts");
  }

  const result = await new FcopInitTransaction(plan).execute(plan.plan_digest);
  const verification = verifyFcopBootstrapManifest(root);
  console.log(JSON.stringify({
    phase: "result",
    plan_digest: result.plan_digest,
    changed: result.changed,
    rolled_back: result.rolled_back,
    verification,
  }, null, 2));

  if (!verification.ok) process.exitCode = 1;
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack ?? error.message : String(error));
  process.exitCode = 1;
});
