from __future__ import annotations

import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: run_fcop_local_tests.py <fcop-repo>")
    root = Path(sys.argv[1]).resolve()
    sys.path.insert(0, str(root / "src"))
    sys.path.insert(0, str(root / "mcp" / "src"))

    import fcop
    import fcop_mcp
    import pytest

    print(f"fcop_module={Path(fcop.__file__).resolve()}")
    print(f"fcop_mcp_module={Path(fcop_mcp.__file__).resolve()}")
    print(f"pytest_version={pytest.__version__}")
    return pytest.main([str(root / "tests"), "-c", str(root / "pyproject.toml")])


if __name__ == "__main__":
    raise SystemExit(main())
