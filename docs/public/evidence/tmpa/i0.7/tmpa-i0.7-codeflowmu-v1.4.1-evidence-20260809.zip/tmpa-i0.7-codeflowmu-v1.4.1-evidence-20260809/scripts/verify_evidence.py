from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SUMS = ROOT / "manifests" / "SHA256SUMS"
TEXT_SUFFIXES = {
    ".json",
    ".jsonl",
    ".log",
    ".md",
    ".py",
    ".txt",
    ".ts",
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> int:
    errors: list[str] = []
    files = sorted(path for path in ROOT.rglob("*") if path.is_file())
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        try:
            relative.encode("ascii")
        except UnicodeEncodeError:
            errors.append(f"non-ASCII filename: {relative}")
        if path.suffix.lower() in TEXT_SUFFIXES or path.name == "SHA256SUMS":
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError as exc:
                errors.append(f"invalid UTF-8: {relative}: {exc}")
                continue
            if path.suffix.lower() == ".json":
                try:
                    json.loads(text)
                except json.JSONDecodeError as exc:
                    errors.append(f"invalid JSON: {relative}: {exc}")
            if path.suffix.lower() == ".jsonl":
                for line_number, line in enumerate(text.splitlines(), 1):
                    if not line.strip():
                        continue
                    try:
                        json.loads(line)
                    except json.JSONDecodeError as exc:
                        errors.append(
                            f"invalid JSONL: {relative}:{line_number}: {exc}"
                        )

    if not SUMS.is_file():
        errors.append("missing manifests/SHA256SUMS")
    else:
        for line_number, line in enumerate(
            SUMS.read_text(encoding="utf-8").splitlines(), 1
        ):
            if not line.strip():
                continue
            try:
                expected, relative = line.split("  ", 1)
            except ValueError:
                errors.append(f"malformed SHA256SUMS line {line_number}")
                continue
            target = ROOT / Path(relative)
            if not target.is_file():
                errors.append(f"missing hashed file: {relative}")
                continue
            actual = digest(target)
            if actual != expected:
                errors.append(
                    f"hash mismatch: {relative}: expected {expected}, actual {actual}"
                )

    result = {
        "root": ROOT.name,
        "file_count": len(files),
        "errors": errors,
        "ok": not errors,
    }
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
