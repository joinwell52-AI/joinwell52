# V1.4.1 治理边界修复核验

## C06

产品现在在完成迁移缺少独立验收时同时产生：

- `LIFECYCLE_UNDETERMINED`；
- `ACCEPTANCE_UNDETERMINED`。

重建状态保持 `review`，验收摘要保持 `undetermined`。外部旧失败 Fixture 和新增内置回归均通过。

## C12

Profile 新增 `resolve_review_conflict` 动作。Reader 在用 DECISION 解决冲突前验证：

- 身份是否存在 Assignment；
- 声明角色是否匹配；
- Assignment 是否包含 `resolve_review_conflict`；
- 角色是否为允许裁定的 ADMIN、PM 或 QA。

未授权 DECISION 不被删除，仍作为治理证据出现；它不能清除 `UNRESOLVED_CONFLICT` 或 `disputed`。授权 PM 正例通过。

## 非目标边界

- C03 继续处理同 ID、不同规范内容的候选冲突；
- C10 继续处理禁止引用环；
- 本补丁没有把两者并入 C12，也没有放宽其判据。
