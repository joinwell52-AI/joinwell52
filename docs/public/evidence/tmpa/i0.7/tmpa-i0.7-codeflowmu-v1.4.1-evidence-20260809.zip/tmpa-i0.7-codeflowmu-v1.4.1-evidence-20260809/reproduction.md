# 复现说明

## 锁定源码

```text
git clone https://github.com/joinwell52-AI/codeflowmu.git codeflowmu
git -C codeflowmu checkout --detach 1cd403537136b3e915c4646cd306983eaca1d2ce
npm --prefix codeflowmu ci
```

## 产品测试

```text
npm --prefix codeflowmu run test:tmpa
npm --prefix codeflowmu/packages/codeflowmu-protocol test
npm --prefix codeflowmu/packages/codeflowmu-protocol run typecheck
npm --prefix codeflowmu/packages/codeflowmu-runtime test
npm --prefix codeflowmu/packages/codeflowmu-runtime run typecheck
npm --prefix codeflowmu/codeflowmu-shell run typecheck
```

Shell 全量测试需要先执行产品原生初始化事务；本次命令和结果见 `runs/initialization/`。初始化后执行：

```text
npm --prefix codeflowmu/codeflowmu-shell test
```

把 `fixtures/codeflowmu_i07_s05_conformance.test.ts` 放在源码目录同级并确认其相对 import 指向检出目录，然后执行：

```text
codeflowmu/packages/codeflowmu-runtime/node_modules/.bin/tsx --test codeflowmu_i07_s05_conformance.test.ts
```

预期：15 pass、0 fail。

## 核验证据包

```text
python scripts/verify_evidence.py
```

核验脚本检查 ASCII 文件名、UTF-8、JSON/JSONL 解析及 `manifests/SHA256SUMS`。
