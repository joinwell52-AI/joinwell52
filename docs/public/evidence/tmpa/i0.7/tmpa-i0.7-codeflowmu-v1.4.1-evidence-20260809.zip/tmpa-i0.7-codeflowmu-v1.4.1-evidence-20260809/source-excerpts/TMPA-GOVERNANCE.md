# CodeFlowMu V1.4.x TMPA × FCoP × 应用统一架构

## 定位

CodeFlowMu V1.4.0 不是把 TMPA 作为附加检查器接到产品旁边，而是完成理论、协议与应用的统一架构实现：

- TMPA 是理论与治理语义层，回答什么事实能够支持什么结论。
- FCoP 是现实协作协议与证据层，承载 Agent、角色、任务、报告、Review、Issue 和生命周期行为。
- CodeFlowMu 是应用执行与消费层，负责产生事实、运行 Adapter/Reader、展示治理图，并让恢复和门禁消费统一结论。

完整主链如下：

```text
Human intention / Agent action
    │ 由 CodeFlowMu 执行并写入协作事实
    ▼
FCoP TASK / REPORT / REVIEW / ISSUE / lifecycle
    │ 只读适配
    ▼
TMPA Governance Object candidates
    │ 确定性读取、验证、图重建
    ▼
judgment + view_state + issues + nodes + edges
    │ 投影
    ▼
CodeFlowMu Project Graph / API / 恢复 / 治理门禁
```

由此，理论不再停留在论文，现实文件也不再只是日志：FCoP 事实能够被 TMPA 确定性重建，再由 CodeFlowMu 作为统一治理视图消费。TMPA Reader 不修改 FCoP 文件，不替代 PM、QA、ADMIN 或其他 Agent 作业务决定。

## 实现组成

- `packages/codeflowmu-protocol/schemas/tmpa/s0.5/`：四类 TMPA S0.5 JSON Schema。
- `packages/codeflowmu-runtime/src/tmpa/FcopSourceAdapter.ts`：FCoP 文件与生命周期事实的只读适配。
- `packages/codeflowmu-runtime/src/tmpa/GovernanceReader.ts`：确定性验证、重建、issue 与 judgment 计算。
- `packages/codeflowmu-runtime/src/tmpa/profile.ts`：CodeFlowMu FCoP 生命周期、角色、验收和职责分离 Profile。
- `packages/codeflowmu-runtime/src/tmpa/SourceRevisionStore.ts`：内容寻址的不可变源修订存储。
- `codeflowmu-shell/src/project-graph-projection.ts`：TMPA 治理结果到项目图的投影。

## 判断与视图状态

### V1.4.1 的 C06/C12 边界

- C06：生命周期状态和业务验收分开计算。缺少独立验收时，`review → done` 不执行，同时产生 `LIFECYCLE_UNDETERMINED` 与 `ACCEPTANCE_UNDETERMINED`。
- C12：矛盾复核持续保留为 `UNRESOLVED_CONFLICT / disputed`，直到拥有 `resolve_review_conflict` 权限的 ADMIN、PM 或 QA 通过 `DECISION` 完整引用冲突复核并选择其中一份。
- 未授权 `DECISION` 不会被删除，但只能成为拒绝或权限不确定的证据，不能形成 `authoritative` 视图。
- C03 仍负责同 ID 异内容冲突，C10 仍负责禁止引用环；两者不并入 C12。

Reader 只输出三种判断：

- `valid`：证据完整且没有阻断性治理 issue。
- `invalid`：存在已经被证据确认的无效对象、无效行为或拒绝结果。
- `undetermined`：证据不足、冲突、隔离、权限或生命周期条件尚不能支持唯一结论。

视图状态独立于判断：

- `authoritative`：当前证据足以形成权威视图。
- `rejected`：证据支持拒绝或无效结论。
- `disputed`：存在互相矛盾的有效证据，尚无有效 resolution。
- `quarantined`：对象身份、完整性、Schema、引用环等问题使相关对象不能进入正常事实图。
- `partial`：只能形成部分视图，缺失项仍明确可见。
- `pending_human`：需要人类授权或验收才能继续形成权威结论。

`undetermined` 是正式结果，不是异常占位。旧项目缺少历史引用、签名或验收证据时出现 `undetermined`，表示 Reader 拒绝猜测。

工作验收状态属于 Reader 的摘要扩展，使用 `accepted / rejected / undetermined`；它不能替代顶层治理判断。

## 不可变历史与兼容性

当前 FCoP 生命周期仍可能更新 TASK frontmatter。V1.4.0 没有强行改变这套写入协议，而是在每次更新前后将原文写入：

```text
.codeflowmu/tmpa/source-revisions/<task-id>/<sha256>.json
```

文件名由内容摘要决定，使用原子 `wx` 写入且不覆盖既有内容。Adapter 将最早版本作为主 TASK，将后续版本投影为带 `supersedes` 的 CORRECTION，从而保留事实演化链。

## 确定性

Reader 对输入记录、治理对象、节点、边和 issue 统一稳定排序，Canonical JSON 递归排序对象键并固定换行。对同一事实集合进行排列后，输出字节和摘要必须一致。

## 验证命令

```powershell
npm run test:tmpa
npm --prefix packages/codeflowmu-protocol test
npm --prefix packages/codeflowmu-runtime run typecheck
npm --prefix codeflowmu-shell run typecheck
```

`test:tmpa` 是 CodeFlowMu 的 C01-C14 判据映射回归。正式 TMPA 符合性声明仍需同时固定以下要素：

- CodeFlowMu 源码提交和产品版本；
- TMPA 规范与 Lifecycle Profile 的版本和摘要；
- 输入证据包及其摘要；
- Reader 版本、Canonicalization ID 与运行环境；
- 完整 C01-C14 结果、原始输出和证据摘要。

因此，V1.4.0 可以声明“已经实现并回归 TMPA S0.5 治理路径”，但在完成上述固定证据评估前，不声明“已获得正式 TMPA 全符合认证”。
