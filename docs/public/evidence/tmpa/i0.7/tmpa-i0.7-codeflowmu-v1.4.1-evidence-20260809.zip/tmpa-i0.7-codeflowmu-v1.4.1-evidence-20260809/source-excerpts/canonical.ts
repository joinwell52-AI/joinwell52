import { createHash } from "node:crypto";

import type { TmpaGovernanceObject } from "@codeflowmu/protocol";

export const CODEFLOWMU_TMPA_CANONICALIZATION = "codeflowmu-tmpa-s0.5-json-v1";

export function stableValue<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => stableValue(item)) as T;
  }
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return Object.fromEntries(
      Object.keys(record)
        .sort((left, right) => left.localeCompare(right, "en"))
        .map((key) => [key, stableValue(record[key])]),
    ) as T;
  }
  return value;
}

export function canonicalJson(value: unknown): string {
  return `${JSON.stringify(stableValue(value))}\n`;
}

export function canonicalBytes(value: unknown): Buffer {
  return Buffer.from(canonicalJson(value), "utf8");
}

export function sha256Digest(value: Uint8Array | string): string {
  return `sha256:${createHash("sha256").update(value).digest("hex")}`;
}

export function tmpaObjectDigest(object: TmpaGovernanceObject): string {
  const covered = structuredClone(object);
  covered.integrity = { ...covered.integrity, digest: "" };
  delete covered.integrity.signature_algorithm;
  delete covered.integrity.key_id;
  delete covered.integrity.signature;
  return sha256Digest(canonicalBytes(covered));
}

export function finalizeTmpaObject(
  object: Omit<TmpaGovernanceObject, "integrity"> & {
    integrity?: Partial<TmpaGovernanceObject["integrity"]>;
  },
): TmpaGovernanceObject {
  const value = structuredClone(object) as TmpaGovernanceObject;
  const supplied = value.integrity ?? ({} as TmpaGovernanceObject["integrity"]);
  value.integrity = {
    ...supplied,
    canonicalization:
      supplied.canonicalization || CODEFLOWMU_TMPA_CANONICALIZATION,
    hash_algorithm: supplied.hash_algorithm || "sha256",
    digest: supplied.digest || "",
  };
  value.integrity.digest = tmpaObjectDigest(value);
  return value;
}
