# TMPA I0.6 本地工程证据报告

## 1. Executive Result

任务 `TMPA-I06-LOCAL-EVIDENCE-001` 已完成源码检查、正式测试发现与隔离复跑、WP-13 V3 验证、C01–C14 对照、脱敏清单和 ZIP 级验证。v2 修正了一项失败原因归属，没有重跑测试。没有修改 FCoP／CodeFlowMu 产品或测试源码，没有覆盖旧证据，没有 push 或发布。

工程结论是“有条件通过：有实质增量，但不可宣称完整符合”：S0.5 Reference Reader 14/14 PASS；FCoP v3.2.5 参考实现 1222 passed / 3 failed / 2 skipped；CodeFlowMu Protocol 8/8、Runtime 1420 passed / 1 failed / 1 skipped、Shell 770/770，三包 typecheck 通过。产品级 S0.5 结果为 PASS 1、FAIL 2、PARTIAL 8、NOT RUN 3。

## 2. Scope

范围仅含公开 TMPA 文档与 S0.5 corpus、FCoP v3.2.5 协议／参考实现、CodeFlowMu 当前本地未发布产品快照、安全正式测试、WP-13 V3 和可发现案例索引。没有论文写作、协议修订、代码修复、生产 Active、整机重启、XiaoDian 私有环境复跑或远程发布。

方法：先固定来源身份与可见性，再从 CI／package 配置发现入口；在干净标签 clone 或字节级隔离快照运行；保留命令、时序、环境、stdout、stderr 与 exit；最后按 S0.5 的强制断言规则裁决。

## 3. Source Inventory

主要来源如下，完整字段见 `source-inventory.md/json`：

- TMPA publication main @ `653e7ba0...`：A0.5、S0.5、I0.5、Schema、Reference Reader。
- FCoP tag `v3.2.5` @ `b3dc2343...`：协议 Profile、`fcop`、`fcop-mcp` 与测试。
- CodeFlowMu base `c4ebc146...` + 当前本地未发布改动：原工作树有 86 条 status，隔离快照运行。
- WP-13 V3：SHA-256 `5b5eda...131c`，与公开 artifact 相同。
- task003 仅索引；XiaoDian 仅发现私有／备份材料，NOT RUN。

## 4. FCoP Protocol Boundary

FCoP 是 TMPA 的文件系统协议／Profile，不是应用程序。S0.5 规范输入包括四类 JSON Schema、Profile、对象／关系／角色／生命周期／完整性注册表语义和 C01–C14 判据。安装 `fcop` 或 `fcop-mcp` 只安装参考实现包或桥接服务，不等于“安装协议”。

协议规定 `parent` 表达工作派生：子工作指向上游 TASK；它不同于 thread 相关性、普通 reference 或运行时 Session 父子。主载体仍要求每项 governed work 只有一个稳定 primary carrier。

## 5. Reference Implementation Boundary

Python `Project`、CLI、原子文件迁移、`write_task/read_task`、MCP tools/resources、package surface 快照都属于参考实现。固定 v3.2.5 复跑实际观察到 3 项失败：两个 surface snapshot 没有同步新增 `parent`，以及 `read_task` 详情未回读已写入的 `parent`。因此不能声称参考实现全绿，也不能把失败写成协议失败。

作者 S0.5 Reference Reader 是另一条轨道：它读取合成固定输入并输出 canonical Reader result。本次 14/14 PASS 只证明该 Reader/fixture 可执行，不代表 `fcop`/`fcop-mcp` 或 CodeFlowMu 产品通过。

## 6. CodeFlowMu Application Boundary

CodeFlowMu 是下游应用。当前本地快照实际采用了 FCoP 风格的 TASK/REPORT/REVIEW/ISSUE、角色门禁、生命周期桶、父子／项目图、人工等待、审批、恢复、审计和 archive guard。正式套件中 WorkFactReader 能只依赖 TASK/REPORT 文件事实，不读取隐藏思考；RecoveryPlanner 覆盖 hot/warm/cold，缺材料时返回 failed/needs_human 而非虚构。

但这些服务没有汇总成完整的 S0.5 产品 Reader Envelope，且快照不是公开 tag。应用功能测试通过不能自动成为 C01–C14 产品级 PASS。

## 7. Test Execution

### FCoP

短临时根的主复跑为 1222 passed、3 failed、2 skipped、1 warning，退出码 1；拆分 CI 入口分别为 library 907/1、MCP 78/2。长路径轮次多出 5 个原子 rename 临时文件路径失败，已用短路径复跑隔离，日志均保留。

`fcop-full-pytest-shorttmp.stdout.log` 与 `fcop-full-pytest.stdout.log` 已规范化为可解码 UTF-8，分别含 2 和 406 个 U+FFFD 替换字符。主要计数、退出码和已识别失败项未受影响，但本包不主张这两份日志保存了原始进程输出的全部字节。

### CodeFlowMu

- Protocol：5 个有效 fixture 接受、3 个无效 fixture 预期拒绝，全部通过。
- Runtime：1422 tests；1420 pass、1 fail、1 skip。唯一失败中，实际 Review 正文为可读中文“需 ADMIN/PM 人工裁定”，测试正则要求“需 ADMIN 人工裁定”或“需人工裁定”；结构化人工等待字段和不推进 lifecycle 的行为均正常。失败原因是提示语契约不一致，不是中文乱码。
- Shell：补齐测试所需只读根资产后，最终 770/770。
- Protocol、Runtime、Shell `tsc --noEmit` 均通过。

Node/tsx 在受限沙箱内最初加载失败，授权后从相同隔离副本复跑。Shell 的 69→12→3 个前序失败均由不完整快照资产造成；针对性复跑通过后最终完整套件全绿。详见 `test-summary.md/json`。

## 8. C01–C14 Results

产品级汇总：C14 PASS；C02、C07 FAIL；C01、C03、C04、C05、C06、C09、C10、C13 PARTIAL；C08、C11、C12 NOT RUN。

C02 的失败来自固定发布标签 `parent` 强制断言；C07 的失败来自当前 CodeFlowMu Runtime 人工裁决提示语契约强制断言。C07 的实际文本、结构化结果与中文编码均正常，但尚未裁定 `ADMIN/PM` 是产品契约变更还是测试期望过时；在裁定、对应变更和复测前继续记为 FAIL，不得直接提升。C10 相比已发布 corpus 的 NOT RUN 得到本地增量：Runtime 的异常 parent／cycle detection 测试实际通过，因此提升为 PARTIAL，但仍未证明 canonical 子图隔离。

完整矩阵见 `c01-c14-matrix.md/json`。

## 9. Case Evidence

WP-13 V3 验证通过：24 个 ASCII 路径文件；23/23 内部 SHA-256；22 个文本严格 UTF-8；6 个 JSON、301 行 JSONL 可解析；原始子执行结果与可读 JSON 语义相等；Patch 由 `git apply --numstat` 成功解析 12 个文件。

案例保留了失败工具通道、退出状态未知、子执行未确认测试／SHA，以及后续同一工作继续、DEV commit/测试、角色分离 QA 的链条。终点仍为 review/pending，Gate C 未终态、Active off、未远程发布、`runtime_bound: False`。它是作者工程案例，不是模型可靠性理论证明。

## 10. Failures and Gaps

1. FCoP v3.2.5 `parent` 回读与 surface snapshots 不闭合。
2. CodeFlowMu REVIEW-GATE 人工裁决中文正文出现编码错误，导致 1 项完整 Runtime 断言失败。
3. 产品缺完整 S0.5 Reader Envelope；C08、C11、C12 未执行。
4. C01/C03–C06/C09/C10/C13 只有部分产品断言或相邻机制。
5. 当前 CodeFlowMu 是 dirty、未发布快照；XiaoDian 没有固定公开复现包。
6. 没有第三方复现、真实身份验证、生产 Active、整机恢复或远程发布证据。

## 11. Claim Boundary

### 必须回答的 12 个问题

1. **FCoP 协议与 S0.5 提供哪些规范输入？** FCoP 提供文件系统对象／流／生命周期 Profile；S0.5 提供治理对象、Reader、conformance、lifecycle Schema 与 C01–C14 的确定性判据、注册表和结果语义。
2. **哪些能力只存在于参考实现？** Python Project API/CLI、MCP 工具、原子 rename、部署／迁移、package 与 surface snapshots；它们不是协议条款本身。
3. **CodeFlowMu 实际采用哪些能力？** 文件型任务／报告／评审、角色和操作门禁、父子／项目树、生命周期与业务态分离、人工等待、恢复、审计、归档与文件事实重建。
4. **哪些由本次测试 demonstrated？** 上述 Protocol fixtures、Runtime/Shell 正式套件、typecheck、FCoP 固定标签结果、Reference Reader fixtures 和 WP-13 包完整性；具体失败同样是 demonstrated。
5. **`parent` 三层是否一致？** 语义目标一致：正式工作派生，不等于 thread/session；但 FCoP v3.2.5 回读和公开 surface 不一致，CodeFlowMu 下游父子测试通过不能修复该发布标签缺口。
6. **Lifecycle State 与 Business Acceptance 是否分离？** 规范、CodeFlowMu 测试和 WP-13 边界均明确分离。
7. **`done`、Gate C、archive 分别是什么？** `done` 是生命周期桶／工作执行状态；Gate C 是 ADMIN 最终业务裁决点；archive 是获得所需验收／归档授权后的历史保存动作。三者不等价。
8. **QA/PM/ADMIN/DEV 的分离是声明还是身份强制？** 角色／工具／操作门禁在实现中可执行，但现场证据主要是角色标签与作者侧角色分离；没有完整的外部身份认证和第三方身份验证，故只能说“部分强制、非独立身份保证”。
9. **Recovery 是否保留原始失败？** 是。WP-13 原始事件与未确认结果保留；Runtime recovery/append-only 机制测试也运行。恢复不应覆盖原失败。
10. **Reader 能否无隐藏 Session 重建？** Reference Reader 可以由固定持久输入重建；CodeFlowMu WorkFactReader/cold recovery 已证明可从文件事实重建部分工作并在材料不足时失败，但没有统一产品 S0.5 Reader 输出，所以产品级为 PARTIAL。
11. **哪些 C01–C14 仍不能执行？** 产品级 C08、C11、C12 为 NOT RUN；其余除 C14 外均有失败或缺失断言。
12. **当前证据支持 I0.6 到什么程度？** 支持“作者运行、本地未发布的工程证据增量与已知失败清单”，支持对 I0.5/S0.5 基线进行更精确裁决；不支持完整符合、独立采用、理论证明或发布完成。

## 12. Recommended I0.6 Statements

- “在 Windows 作者环境对 FCoP v3.2.5 进行固定标签复跑，得到 1222 passed、2 skipped、3 failed；失败与 `parent` 回读及 API/MCP surface snapshot 有关。”
- “CodeFlowMu 带本地未发布修改的作者工作树隔离快照展示了生命周期、人工门禁、恢复、审计、归档和无隐藏 Session 文件事实重建机制；完整 Runtime 套件仍保留 1 项人工裁决提示语契约失败，责任归属待裁定。”
- “S0.5 Reference Reader 的 14 个合成 fixture 全部通过；该结果与产品级结论分离。”
- “产品级对照为 PASS 1、FAIL 2、PARTIAL 8、NOT RUN 3；没有独立采用证据。”
- “WP-13 V3 展示失败可见、同任务继续和角色分离 QA 复核，同时保留 Gate C/Active/未发布边界。”

## 13. Statements That Must Not Be Made

不得写成：FCoP 全绿／已安装；CodeFlowMu 完整符合 S0.5；产品 C01–C14 全 PASS；WP-13 消除幻觉；`done`=验收；Gate C=发布；作者复跑=独立验证；测试存在=已执行；工程案例=理论证明。

## 14. Next Engineering Actions

1. 在新补丁中修复并测试 FCoP `read_task` 的 `parent` 回读，更新公共 API 与 MCP surface snapshots／CHANGELOG；本任务不实施。
2. 由产品与测试维护者裁定人工提示语契约：确认“ADMIN/PM”是预期产品变更，还是测试应继续要求“ADMIN”；按裁定修改产品或测试后，复跑完整 Runtime acceptance test。在完成前保持 C07 FAIL。
3. 为 CodeFlowMu 构建只读 S0.5 product Reader，优先补 C08 控制篡改、C11 全排列字节确定性和 C12 disputed→authorized resolution。
4. 把当前 dirty CodeFlowMu 状态冻结为可检出的公开或审计 commit 后重跑，消除“未发布混合快照”限制。
5. 为 XiaoDian 建立脱敏、固定 commit、正式入口、命令／日志／哈希齐全的独立包；在此之前保持 NOT RUN。
6. 邀请非作者主体按 manifest 复现并签署结果；只有届时才评估 independently adopted。
