# TMPA Core S0.5 C01–C14 对照矩阵

裁决主体是 FCoP–CodeFlowMu 产品证据；`Ref` 列仅列作者 Reference Reader，对产品不作抬升。

| ID | 要求摘要 | Ref | 产品裁决 | 最高产品证据 | 关键依据／缺口 |
|---|---|---|---|---|---|
| C01 | Schema 与负例拒绝 | PASS | PARTIAL | demonstrated | CodeFlowMu 5 正 + 3 负 fixture 通过；非完整 S0.5 对象面 |
| C02 | 主载体、parent、单写者 | PASS | FAIL | demonstrated | FCoP parent 回读与 API/MCP snapshot 三项失败 |
| C03 | 重复 ID 冲突隔离 | PASS | PARTIAL | demonstrated | 去重机制运行；无 canonical quarantine 输出 |
| C04 | 流连续与异步推进 | PASS | PARTIAL | demonstrated | FIFO/多 worker/dispatch 运行；无 canonical gap/duplicate 输出 |
| C05 | 角色授权三值判断 | PASS | PARTIAL | demonstrated | 角色与操作门禁运行；无 denied/undetermined 成对输出 |
| C06 | 生命周期合法性与验收分离 | PASS | PARTIAL | demonstrated | 生命周期／业务态分离运行；无完整三值 Envelope |
| C07 | 职责分离与人工控制 | PASS | FAIL | demonstrated | 结构化结果与中文均正常；“ADMIN/PM”未命中测试要求“ADMIN”，提示语契约归属待裁定并复测 |
| C08 | 篡改与摘要重算 | PASS | NOT RUN | implemented | 仅有相邻完整性机制与 WP-13 包哈希；产品控制篡改未跑 |
| C09 | 缺失引用传播 | PASS | PARTIAL | demonstrated | 缺失事实→UNKNOWN/阻断运行；无 canonical MISSING_REFERENCE |
| C10 | 禁止环隔离 | PASS | PARTIAL | demonstrated | 本地 Runtime 环检测通过；未证明只隔离受影响子图 |
| C11 | 全排列字节确定性 | PASS | NOT RUN | specified | 24 排列仅 Reference Reader 运行 |
| C12 | disputed 与授权 resolution | PASS | NOT RUN | implemented | 有追加式纠正机制；未跑完整产品断言 |
| C13 | 恢复、子工作闭包、无 Session 重建 | PASS | PARTIAL | demonstrated | WorkFactReader/cold recovery 通过；无统一产品 Reader |
| C14 | 授权终态历史保留 | PASS | PASS | demonstrated | archive/history/guard 运行并保留前序对象 |

## 汇总

- PASS：1（C14）
- FAIL：2（C02、C07）
- PARTIAL：8（C01、C03、C04、C05、C06、C09、C10、C13）
- NOT RUN：3（C08、C11、C12）
- Independently Adopted：0

C07 保留 FAIL 的原因是原始强制断言确实失败，不是编码损坏。未经确认产品提示语契约、实施相应产品或测试变更并复测，不得直接提升为 PASS 或 PARTIAL。

详细断言、证据数组和限制见 `c01-c14-matrix.json`。
