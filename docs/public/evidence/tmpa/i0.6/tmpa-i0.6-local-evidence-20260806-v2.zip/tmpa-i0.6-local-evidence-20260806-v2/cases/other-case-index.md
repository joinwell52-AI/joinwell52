# 其他案例索引

| 案例 | 可用性 | 可见性 | 本次处置 | 边界 |
|---|---|---|---|---|
| WP-13 多 Agent 事实复核 | 固定 V3 ZIP 与公开镜像可用 | public author package | 完整验证 | author-demonstrated，不是独立采用 |
| task003 governance dispatch stall | 本地 observer-case 目录可用，含 current-state、timeline、raw/derived Runtime excerpts、bug register 与 technical report | local-only | 仅索引，未作为 S0.5 产品 Reader 运行 | 不能抬升 C01–C14 |
| XiaoDian AI | 发现本地私有／备份应用材料，但无固定公开 evidence bundle、commit 与正式测试入口 | private/local-only | NOT RUN；不复制源码 | 仅可作为待补现场案例 |
| I0.5 旧 CodeFlowMu 证据 | S0.5 corpus 中有重新裁决的保留证据 | public author corpus | 作为历史对照 | 旧证据不自动改标 S0.5 PASS |

未发现可证明第三方独立采用或复现的材料。
