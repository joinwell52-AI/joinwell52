# 协议、参考实现与应用边界

## 固定分层

| 层级 | 本包中的含义 | 不应混淆为 |
|---|---|---|
| TMPA | 文本持久对象、单写者串流、多异步流、Reader 重建偏序治理图的架构与 Core S0.5 规范 | 某个 Python/Node 程序 |
| FCoP Protocol/Profile | TMPA 的文件系统协议剖面、对象与生命周期规则 | 已安装的软件包 |
| `fcop` / `fcop-mcp` | FCoP 的 Python 参考实现与 MCP 桥 | FCoP 协议本身 |
| CodeFlowMu | 采用 FCoP 文件流的下游应用 | TMPA Core S0.5 Reader |
| WP-13 / XiaoDian / 其他案例 | 工程观察或现场案例 | 理论证明或独立采用证明 |

## S0.5 的规范输入

S0.5 提供治理对象 Schema、生命周期 Profile、Reader result Schema、conformance result Schema，以及对象标识、单写者归属、父子派生、流序列、角色授权、生命周期／验收分离、人工控制、完整性、缺失引用、环、确定性、冲突、恢复和终态历史的 C01–C14 断言。

## 仅属于参考实现的能力

CLI、Python `Project` API、`write_task`/`read_task`、文件迁移、原子 rename、MCP 工具／资源列表、安装包与公开 surface 快照属于 `fcop`/`fcop-mcp` 实现选择，不是协议本体。`pip` 或 `uv` 安装的是这些包，不是“安装 FCoP 协议”。

## CodeFlowMu 实际采用

本次运行证明当前本地快照实际包含并执行了任务／报告／Review Gate、角色与操作门禁、父子与项目树、生命周期转换、归档门禁、重试／恢复、审计、人工等待、文件事实读取和 cold reconstruction 等路径。它没有输出完整的 S0.5 canonical Envelope，因此不能据此宣称完整产品符合。

## Reference Reader 边界

作者提供的 S0.5 Reader 对合成固定 fixture 的 14/14 PASS 证明规范示例与实现可执行。它不是 FCoP v3.2.5 产品结果，也不是 CodeFlowMu 产品结果；其通过不能覆盖参考实现与下游测试中的真实失败。
