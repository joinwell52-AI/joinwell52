# TMPA I0.6 本地工程证据包

任务编号：`TMPA-I06-LOCAL-EVIDENCE-001`  
采集日期：2026-08-07（Asia/Shanghai）  
状态：Conditionally accepted after attribution correction；保留全部原始失败

本包是 TMPA–FCoP–CodeFlowMu Implementation Case I0.6 的本地工程取证结果，不是论文正文、协议修订、产品发布或独立第三方验证。

本目录是未覆盖原包的 v2 勘误版。它修正 CodeFlowMu 唯一 Runtime 失败的原因归属，并补充 FCoP 日志编码边界；没有重跑测试。详见 `revision-notes.md`。

## 一眼结论

- S0.5 作者 Reference Reader 固定输入重放：C01–C14 为 14/14 PASS。
- FCoP `v3.2.5` 参考实现复跑：1222 passed、3 failed、2 skipped、1 warning；失败集中于 `parent` 回读与 API/MCP surface 快照。
- CodeFlowMu 带本地未发布修改的作者工作树隔离快照：Protocol fixtures 8/8；Runtime 1420 passed、1 failed、1 skipped；Shell 最终 770/770；三个 TypeScript typecheck 均通过。该结果不是稳定公开版本或独立采用证据。
- Runtime 唯一失败是人工裁决提示语契约不一致：实际为“需 ADMIN/PM 人工裁定”，测试期望匹配“需 ADMIN 人工裁定”或“需人工裁定”；中文与结构化字段均正常。产品实现和测试期望谁应调整尚未裁定。
- 产品级 S0.5 对照：PASS 1、FAIL 2、PARTIAL 8、NOT RUN 3。Reference Reader 通过不抬升产品结论。
- WP-13 V3：ZIP、哈希、编码、JSON/JSONL、Patch 与语义一致性验证通过；仍为作者生成、角色分离 QA 案例，不是外部独立采用。

## 阅读顺序

1. `executive-summary.md`
2. `report.md`
3. `c01-c14-matrix.md`
4. `revision-notes.md`
5. `test-summary.md`
6. `claim-boundary.md` 与 `limitations.md`

机器可读结果位于同名 JSON、`commands/commands.json`、`manifests/` 和 `package-validation.json`。原始 stdout/stderr 位于 `logs/`；本地绝对路径已替换为逻辑占位符，测试计数、失败正文与退出码未改变。

## 完整性验证

从包根目录按 `manifests/files.sha256` 复核 SHA-256；`package-validation.json` 记录 ZIP、ASCII 文件名、UTF-8、JSON/JSONL、路径／凭据扫描及 C01–C14 数量检查。

## 不包含

不包含产品源码、私有案例源码、凭据、Token、Cookie、API Key、用户绝对路径、远程 push、Release 或论文正文修改。
