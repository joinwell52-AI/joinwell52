# 声明边界

## 可以声明

- 已在固定 FCoP v3.2.5 标签上复跑参考实现测试，并保留 3 项失败。
- 已在 CodeFlowMu 当前未发布本地快照的隔离副本上运行 Protocol、Runtime、Shell 和 typecheck。
- S0.5 Reference Reader 的作者固定 fixture 在本环境 14/14 PASS。
- CodeFlowMu 展示了多种文件原生治理、恢复与无隐藏 Session 事实读取机制。
- WP-13 V3 是可审计的作者工程案例，包含角色分离 QA 证据和明确的 Gate／发布边界。
- 当前产品级对照为 PASS 1、FAIL 2、PARTIAL 8、NOT RUN 3。
- C07 的原始 Runtime 测试确实失败；实际中文和结构化结果正常，失败归因为提示语契约不一致。产品实现与测试期望的责任归属尚未裁定，因此保持 FAIL。

## 不得声明

- FCoP 协议“测试全部通过”或“已经安装”。
- CodeFlowMu 完整符合 TMPA Core S0.5。
- C01–C14 全部产品级 PASS。
- 未经提示语契约裁定、相应变更和复测，将 C07 提升为 PASS 或 PARTIAL。
- `done` 等于业务验收，Gate C 等于发布完成，或 archive 可由执行者自行触发。
- WP-13 消除了模型幻觉。
- 作者运行等于独立验证或第三方采用。
- 测试源码存在等于测试已经执行。
- 工程实现等于 TMPA 理论证明。

## 证据成熟度

S0.5 为 specified；Reference Reader 为 implemented + author-demonstrated；FCoP/CodeFlowMu 为混合 implemented + author-demonstrated；independently adopted 未建立。
