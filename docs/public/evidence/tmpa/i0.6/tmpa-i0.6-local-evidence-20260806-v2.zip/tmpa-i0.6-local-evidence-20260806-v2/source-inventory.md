# 来源清单

公开包中使用逻辑路径代替本机绝对路径。

| 来源 | 逻辑路径 | 可见性 | Remote / 分支 | Commit / Tag | Worktree | 角色与可用性 |
|---|---|---|---|---|---|---|
| TMPA publication | `source://tmpa-publication` | public | `joinwell52-AI/joinwell52`, main | `653e7ba0ac788cb7745f127d03fd23610a58d4e2` | 初始 clean；Reader 重放只改生成 artifacts | A0.5、S0.5、I0.5、Schema、Reader/fixtures，可用 |
| FCoP v3.2.5 | `source://fcop-v3.2.5` | public | `joinwell52-AI/FCoP`, detached | `b3dc23439c6aaa6a6b3765655b87e5924e0257f9`, `v3.2.5` | clean；`.venv` ignored | 协议 Profile、参考实现与测试，可用 |
| FCoP 本地历史副本 | `source://fcop-local-historical` | mixed/local-only | public origin, main | `da79dfefd99f597c9e422ce9edec22157f915a21`, describe `v3.2.4-5-g...-dirty` | dirty，含本地环境与旧证据 | 仅库存，不作为目标测试源 |
| CodeFlowMu | `source://codeflowmu-local-snapshot` | mixed; current snapshot local-only | public remote declared, main | base `c4ebc146cb8ef0409a4c9eb571a8f2432ade3bd0`; packages `0.3.0-alpha` | 原工作树 86 条：39 modified、47 untracked | 下游应用；按字节构造隔离测试副本，可用但未发布 |
| WP-13 V3 | `case://wp13-v3` | public author package | publication artifact | SHA-256 `5b5eda...131c` | immutable ZIP | 工程案例，可用 |
| task003 observer case | `case://task003-dispatch-stall` | local-only | none recorded | no fixed commit | local evidence directory | 仅索引 |
| XiaoDian AI | `case://xiaodian-local` | private/local-only | 未建立 | 未建立 | 非固定、不可公开复现 | NOT RUN |

`dirty files` 的具体私有路径不进入出版包；数量与对结论的影响已保留。
