# v2 修订说明

## 修订状态

本包是 `tmpa-i0.6-local-evidence-20260806` 的不覆盖勘误版，结论为“有条件通过”。原目录与原 ZIP 保留不变；v2 没有重跑 FCoP、CodeFlowMu、Reference Reader 或 WP-13 测试。

## P0 归因修正

CodeFlowMu Runtime 唯一失败原先被错误归因为中文乱码。原始日志显示：

- 实际输出：`需 ADMIN/PM 人工裁定`
- 测试期望：`需 ADMIN 人工裁定` 或 `需人工裁定`
- 结构化字段：`decision=needs_human`、`fact_check_verdict=needs_admin`、`awaiting_pm_decision=true`
- 中文文本：完整、可读

正确归因是“人类裁决提示语契约不一致”。尚需产品与测试维护者确认 `ADMIN/PM` 是预期产品变更，还是测试期望已经过时。原始强制断言确实失败，因此 C07 继续为 FAIL；未经裁定、对应修改和复测，不得提升为 PASS 或 PARTIAL。

## 编码说明修正

`logs/fcop/fcop-full-pytest-shorttmp.stdout.log` 和 `logs/fcop/fcop-full-pytest.stdout.log` 已被规范化为可解码 UTF-8，分别含 2 和 406 个 U+FFFD 替换字符。主要计数、退出码与已识别失败项未受影响，但不得表述为原始进程输出字节无损保存。

## 证据边界重申

CodeFlowMu 来源是带有本地未发布修改的作者工作树隔离快照，只能作为作者本地运行证据；不是稳定公开版本，不是独立验证，也不是独立采用证据。

## 未改变事项

- Reference Reader：14/14 PASS。
- FCoP：1222 passed、3 failed、2 skipped。
- CodeFlowMu Runtime：1420 passed、1 failed、1 skipped。
- CodeFlowMu Shell：770/770。
- C01–C14：1 PASS、2 FAIL、8 PARTIAL、3 NOT RUN。
- WP-13：23/23 内部哈希通过，JSON、JSONL 与 Patch 可复核。
