# 测试汇总

## 主结果

| 运行 | PASS | FAIL | SKIP | WARNING | Exit | 解释 |
|---|---:|---:|---:|---:|---:|---|
| S0.5 Reference Reader | 14 | 0 | 0 | 0 | 0 | 作者 fixture；不代表产品 |
| FCoP full（短 temp） | 1222 | 3 | 2 | 1 | 1 | 主 FCoP 结果 |
| FCoP library CI | 907 | 1 | 0 | 1 | 1 | public surface snapshot |
| FCoP MCP CI | 78 | 2 | 0 | 1 | 1 | parent 回读 + MCP surface |
| CodeFlowMu Protocol | 8 | 0 | 0 | 0 | 0 | 5 正例、3 预期负例 |
| CodeFlowMu Runtime | 1420 | 1 | 1 | 0 | 1 | REVIEW-GATE 可读中文断言 |
| CodeFlowMu Shell（最终） | 770 | 0 | 0 | 0 | 0 | 完整只读依赖快照 |
| Protocol typecheck | 1 | 0 | 0 | 0 | 0 | `tsc --noEmit` |
| Runtime typecheck | 1 | 0 | 0 | 0 | 0 | `tsc --noEmit` |
| Shell typecheck | 1 | 0 | 0 | 0 | 0 | `tsc --noEmit` |
| WP-13 V3 validation | 1 | 0 | 0 | 0 | 0 | 包级验证 |

## FCoP 三项失败

1. `test_public_surface_matches_snapshot`：观察到 `write_task(..., parent=...)`，锁定的公共 API snapshot 未包含该可选参数。
2. `TestReportsAndIssues::test_report_lifecycle`：`write_task(parent=...)` 后 `read_task` 可读详情未保留 `parent`。
3. `test_tool_surface_matches_snapshot`：MCP tool surface snapshot 未包含新增 `parent` 参数。

所以 `parent` 问题不是预设，而是本次在固定标签上重新观察到。失败属于参考实现，不是 FCoP 协议规范失败。

## CodeFlowMu 唯一 Runtime 失败

`e2e-log-report-review-eval.acceptance.test.ts` 的 needs-admin 场景要求 Review 正文匹配“需 ADMIN 人工裁定”或“需人工裁定”。实际正文是完整可读的“需 ADMIN/PM 人工裁定”，因此正则不匹配；这不是中文乱码。结构化字段仍为 `decision: needs_human`、`fact_check_verdict: needs_admin`、`awaiting_pm_decision: true`，且没有推进 lifecycle。原始测试确实失败，故该强制断言继续映射 C07 FAIL。需要先确认 `ADMIN/PM` 是产品契约变更，还是测试期望已经过时；未经裁定、对应变更和复测，不能把 C07 改为 PASS 或 PARTIAL。

## 日志编码边界

两份 FCoP 全量 stdout 日志经过 UTF-8 规范化后均可解码：短临时根日志含 2 个 U+FFFD，长路径日志含 406 个 U+FFFD。主要计数、退出码与失败项未受影响，但这不代表原始字节无损保存。

## 保留的非主轮次

- FCoP 长路径：1217 passed、8 failed、2 skipped、1 warning；其中 5 项是临时路径过长导致的 `FileNotFoundError`，短路径复跑证明不是产品断言。
- Runtime 沙箱轮次：测试文件加载前统一 `os.userInfo` 失败，不计产品断言结果。
- Shell 不完整快照轮次：先后 69、12、3 fail，均由缺失根级只读资产导致；补齐并用针对性测试确认后，最终全套 770/770。

这些失败日志没有删除，也没有改写为 PASS；主结果采用可归因的最终隔离轮次。
