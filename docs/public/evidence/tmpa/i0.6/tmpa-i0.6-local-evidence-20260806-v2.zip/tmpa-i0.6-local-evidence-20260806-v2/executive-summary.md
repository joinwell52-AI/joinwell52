# 执行摘要

## 结论

当前证据包为“有条件通过”，足以支持 I0.6 作为“作者运行的本地工程验证增量”：S0.5 Reference Reader 的 14 项固定 fixture 可复现通过；FCoP v3.2.5 的参考实现基线可复现出 3 项 `parent` 相关失败；CodeFlowMu 带本地未发布修改的作者工作树隔离快照展示了广泛的生命周期、角色门禁、恢复、审计、归档与无隐藏 Session 重建机制，但仍有 1 项 REVIEW-GATE 人工裁决提示语契约断言失败，且没有产品级 S0.5 统一 Reader 输出。该快照不是稳定公开版本或独立采用证据。

因此，产品级裁决不是“完整符合 S0.5”，而是：C14 PASS；C02、C07 FAIL；C01、C03–C06、C09、C10、C13 PARTIAL；C08、C11、C12 NOT RUN。

## 最重要发现

1. `parent` 在 S0.5、FCoP API/MCP 与 CodeFlowMu 下游用途之间概念一致，但 FCoP v3.2.5 发布标签的 `read_task` 回读和 surface 快照没有闭合，故 C02 必须 FAIL。
2. CodeFlowMu Shell 最终 770/770，Protocol fixtures 8/8，Runtime 1420/1422；Runtime 唯一失败的实际文本是“需 ADMIN/PM 人工裁定”，测试期望匹配“需 ADMIN 人工裁定”或“需人工裁定”。中文文本和 `decision=needs_human` 等结构化字段均正常；这是未裁定的产品／测试提示语契约不一致，不是编码损坏。原始测试确实失败，故 C07 暂保 FAIL；未经契约裁定、对应变更和复测，不得提升为 PASS 或 PARTIAL。
3. 生命周期位置、业务验收和发布互不等价：`done` 是生命周期事实，Gate C 是 ADMIN 业务裁决点，archive 是获授权后的历史保存动作。
4. WP-13 V3 证明一次“失败可见、继续同一任务、角色分离 QA 复核”的作者工程案例；它不证明消除幻觉，也不等于第三方独立验证。

## 运行摘要

| 层级 | 结果 |
|---|---|
| S0.5 Reference Reader | 14 PASS，退出码 0 |
| FCoP v3.2.5 全量 | 1222 passed / 3 failed / 2 skipped / 1 warning，退出码 1 |
| CodeFlowMu Protocol | 5 个正例 + 3 个预期负例全部符合，退出码 0 |
| CodeFlowMu Runtime | 1420 passed / 1 failed / 1 skipped，退出码 1 |
| CodeFlowMu Shell | 770 passed / 0 failed，退出码 0 |
| Runtime/Shell/Protocol typecheck | 全部退出码 0 |
| WP-13 V3 | 24 文件；23/23 内部哈希；JSON/JSONL 与 Patch 验证通过 |

所有运行均为作者环境本地执行；独立采用或独立验证尚未建立。

两份 FCoP 全量运行日志经过 UTF-8 规范化后可解码，其中保留 U+FFFD 替换字符；这不代表原始进程输出字节得到无损保存。主要计数和已识别失败项不受影响。
