# 限制与未执行项

1. CodeFlowMu 证据来自包含 86 个 Git status 条目的未发布本地工作树，隔离快照不是公开 tag 或单一可检出的 commit。
2. FCoP、Reference Reader、CodeFlowMu 与 WP-13 均由同一作者侧环境复跑，不构成独立验证。
3. 产品没有输出完整 S0.5 canonical Reader Envelope；C08、C11、C12 的产品级强制断言未执行。
4. C02 的 FCoP v3.2.5 `parent` 回读与 surface 快照失败仍存在；本任务未修改代码或测试。
5. CodeFlowMu Runtime 的 REVIEW-GATE 中文可读文本断言失败；结构化人工等待字段存在不等于可读文本断言通过。
6. 首轮 FCoP 长路径运行额外产生 5 项 Windows 路径长度失败，短路径复跑将其隔离为环境噪声；两轮日志均保留。
7. CodeFlowMu 初始隔离快照缺少 UI／规则／版本资产，Shell 先后出现 69、12、3 项缺件失败；补齐只读依赖后的最终完整套件为 770/770。前序日志保留为快照构造限制。
8. Node/tsx 在受限沙箱内无法调用 `os.userInfo`，正式 Node 测试经授权在同一隔离副本中复跑。
9. XiaoDian AI 仅发现本地私有／备份材料，没有可公开复现的固定 commit、测试入口与证据包，故 NOT RUN。
10. WP-13 的内部 SHA-256 清单未签名，只证明包内一致性；`runtime_bound: False`、review/pending、Gate C 未终态与未远程发布边界仍有效。
11. 本任务没有执行整机重启、真实生产 Active 接管、远程发布或第三方复现。
12. 两份 FCoP 全量 stdout 日志经过 UTF-8 规范化并可解码，但含 U+FFFD 替换字符；主要计数和失败项可复核，不代表原始字节无损保存。
12. 原始日志为避免泄露本地路径进行了确定性路径脱敏；退出码、计数、失败断言和相对测试路径保持不变。
