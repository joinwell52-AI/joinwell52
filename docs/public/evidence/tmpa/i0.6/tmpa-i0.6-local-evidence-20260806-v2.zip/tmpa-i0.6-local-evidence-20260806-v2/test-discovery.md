# 测试发现

## 正式入口

| 系统 | 发现依据 | 正式入口 | 发现规模 |
|---|---|---|---:|
| S0.5 Reference Reader | publication `package.json` 与 corpus README | `npm run tmpa:s0.5:conformance` | C01–C14 共 14 个 fixture |
| FCoP library | `pyproject.toml`、`test-fcop.yml` | `python -m pytest tests/test_fcop -v` | 70 个 Python 测试文件（全 `tests/` 共 1227 collected） |
| FCoP MCP | `mcp/pyproject.toml`、`test-fcop-mcp.yml` | `python -m pytest tests/test_fcop_mcp -v` | MCP contract + smoke |
| FCoP full | root pytest config | `python -m pytest -ra` | 1227 tests |
| CodeFlowMu Protocol | package `scripts.test` | `npm test` | 5 个有效 fixture + 3 个预期无效 fixture |
| CodeFlowMu Runtime | package `scripts.test` | `node --import tsx --test --test-concurrency=1 "src/**/__tests__/*.test.ts"` | 197 个 test 文件；本次 1422 tests |
| CodeFlowMu Shell | package `scripts.test` | `node --import tsx --test --test-concurrency=1 "src/__tests__/*.test.ts"` | 102 个 test 文件；本次 770 tests |
| TypeScript | 各 package `scripts.typecheck` | `tsc --noEmit` | Protocol/Runtime/Shell |

## 与 S0.5 有关的已发现测试族

- Lifecycle：`LifecycleStateMachine`、`LifecycleGovernor`、`e2e-lifecycle`、transition recorder、repair、archive guard。
- Parent/tree：`PmParentDispatchPrompt`、report parenting、child task archive gate、project graph。
- Role/human：AuthorityGuard、RoleToolPolicy、NeedsHumanGate、ReviewFactGate、operation approval。
- Recovery：DispatchRetryRegistry、auto recovery、switchboard recovery、cold/warm/hot RecoveryPlanner。
- No-session facts：WorkFactReader 明确只读 TASK/REPORT 文件事实，不读取隐藏思考。
- Audit/archive：audit、history、review/archive、terminal history、child closure。
- Schema：FCoP schema tests 与 CodeFlowMu Protocol 正／负 fixtures。

这些名称只说明“源中存在”；本包只将带命令、日志与退出码的运行标为 demonstrated。

## 安全判断

FCoP 在干净标签克隆运行；CodeFlowMu 在字节级隔离副本运行，正式套件使用临时目录／临时 Git 仓库，不触碰原工作树。真实生产 Active 接管、整机重启与 XiaoDian 私有环境测试被排除。

## 环境发现问题

- FCoP 在长工作区临时路径下额外触发 5 个 Windows 路径长度失败；短临时根复跑后只剩 3 个可重复产品失败。
- Node/tsx 在受限沙箱内加载前因 `os.userInfo` 失败；授权后在同一隔离副本复跑。
- Shell 需要根级 UI、规则、版本与 Open manifest 资产；补齐只读依赖后最终完整套件 770/770。

详细计划见 `test-plan.json`，全部运行见 `commands/commands.json`。
