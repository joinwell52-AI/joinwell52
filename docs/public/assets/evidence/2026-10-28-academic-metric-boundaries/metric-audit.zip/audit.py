import ast,json,pathlib,statistics
w=pathlib.Path(__file__).resolve().parent
tree=ast.parse((w/'upstream_metrics.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='classification_metrics')
env={'fmean':statistics.fmean,'CLASSES':('allow','review','deny')}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'upstream_metrics.py','exec'),env)
labels=['allow','review','deny']; out={}
for name,matrix in json.loads((w/'inputs.json').read_text())['matrices'].items():
 truth=[];pred=[]
 for i,row in enumerate(matrix):
  for j,n in enumerate(row):truth += [labels[i]]*n;pred += [labels[j]]*n
 result=env['classification_metrics'](truth,pred)
 result['all_nonreview_to_review_rate']=sum(t!='review' and p=='review' for t,p in zip(truth,pred))/len(truth)
 out[name]=result
expected=json.loads((w/'expected.json').read_text())
assert out==expected,(out,expected)
print(json.dumps(out,indent=2))
print('PASS: conditional arithmetic audit; original predictions were not reproduced.')
