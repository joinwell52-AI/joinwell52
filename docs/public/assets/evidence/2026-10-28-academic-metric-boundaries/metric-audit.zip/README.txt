Conditional classification-metric audit, 2026-10-28
Run: python audit.py (Python 3.12+, standard library only).
Inputs are reconstructed from arXiv:2609.37457v1 Table 5 and section 5.4.
Rows: reference class; columns: prediction; class order allow, review, deny.
The code executes the unchanged upstream classification_metrics function.
The all-review control is intentionally constructed and is not an observed system.
Matching aggregates do not recover original rows or establish a replication.
A table, narrative or historical metric-version discrepancy remains unresolved.
